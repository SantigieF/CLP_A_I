---
title: "SDS auditor — ECHA v4.0 source-grounded review index"
source: "ECHA Guidance on the compilation of safety data sheets, Version 4.0 (December 2020)"
reference: "ECHA-20-H-25-EN"
type: "interpretive audit checklist, NOT legal requirements"
legal_status: "Guidance is non-binding and historical. Verify current REACH Annex II before issuing legal findings."
---

# ECHA SDS guidance — auditor's review and correction index

> **Use with caution.** This index is an **analyst-created retrieval aid** based on the uploaded **ECHA Guidance on the Compilation of Safety Data Sheets, Version 4.0 (December 2020)**. The linked `references/` files contain source-derived guidance text. This index is **not a quotation of the legislation**, does **not** establish that any particular SDS is non-compliant and is **not a replacement for REACH Annex II as legally applicable on the relevant date**.
>
> **Law/guidance distinction:** REACH **Annex II** addresses SDS compilation. CLP **Annex I** addresses classification criteria; CLP Annex II concerns special labelling/packaging requirements. Do not conflate these annexes. Always check the applicable, effective legal text, including amendments and transitions.

## Workflow for an SDS auditor

1. **Confirm scope and source quality:** jurisdiction, SDS revision date, substance vs mixture, product use, distribution market, supplied pages and legibility. If OCR is uncertain, inspect page images before alleging an omission.
2. **Review legal basis:** obtain legally applicable REACH Annex II / Article 31 and other relevant regulations, including national rules and current harmonised classifications. This **2020 ECHA guidance** is secondary interpretation only.
3. **Audit 16 sections:** retrieve the matching `SDS_Section_NN.md` reference for each SDS section; evaluate completeness, quality, specificity, internal consistency and date relevance.
4. **Cross-check consequences:** compare hazard classification and composition with Sections 4–15 where relevant, and check exposure scenario consistency.
5. **Register each finding:** record current SDS wording, exactly what is wrong, section/page, regulatory authority (or clearly labelled guidance), confidence/status, correction steps, verification evidence, downstream changes and closure condition.
6. **Propose corrected wording only from verified facts:** otherwise write `[SUPPLIER TO VERIFY]`, not an invented hazard statement, concentration, test result, exposure limit or transport classification.
7. **Human technical sign-off:** route classification changes and complex interpretation for competent-person review. No automatic approval or certification.

## Section-by-section audit routing table

The checklist below identifies **topics to review**, not unconditional legal duties. Whether an item is mandatory depends on the applicable REACH Annex II and the facts of the product. When guidance contains an example structure, treat it as *illustrative*, not prescribed.

| SDS section | ECHA guidance | Review questions grounded in the chapter | Correction and evidence route |
|---|---|---|---|
| **1 — Identification** | [§3.1](references/SDS_Section_01.md), pp. 33–40 | Are product identifiers, relevant identified uses / uses advised against, supplier details and emergency contact information complete and appropriate? Is UFI included where the relevant rules call for it? | Request registration / product identifier details, local supplier contact and supported emergency number. Verify UFI applicability, then correct exactly the affected fields. |
| **2 — Hazards identification** | [§3.2](references/SDS_Section_02.md), pp. 41–46 | Is classification stated appropriately and consistent with label elements? Are additional hazards, including PBT/vPvB and endocrine-disruption information, addressed as applicable? Do H/P/EUH statements match the verified classification and label? | Confirm classification from underlying evidence and applicable CLP. Only then amend classification, signal words, pictograms and statement wording; check Sections 3, 9, 11, 12 and label. |
| **3 — Composition/information on ingredients** | [§3.3](references/SDS_Section_03.md), pp. 46–57 | Is the appropriate substances **3.1** or mixtures **3.2** route used? Are necessary ingredient identities, concentration ranges, classifications and applicable SCLs/M-factors/ATEs disclosed? Are nanoforms addressed when relevant? | Verify formulation, supplier ingredient classifications, identifiers and concentration data. Do **not** infer undisclosed confidential ingredients, use invented CAS numbers or equate example disclosure tables with mandatory formatting. |
| **4 — First aid measures** | [§3.4](references/SDS_Section_04.md), pp. 57–59 | Are instructions usable for relevant exposure routes? Are immediate and delayed symptoms and any indication of medical attention appropriately described? | Match first-aid advice to verified hazards and toxicological evidence; obtain clinical / product-specific advice where necessary. |
| **5 — Firefighting measures** | [§3.5](references/SDS_Section_05.md), pp. 59–60 | Are suitable/unsuitable extinguishing media, special hazards and advice for firefighters appropriate? | Validate extinguishing recommendations, combustion/decomposition hazards and necessary protection against verified physical properties and Section 10. |
| **6 — Accidental release measures** | [§3.6](references/SDS_Section_06.md), pp. 61–63 | Does the SDS address responder/non-responder precautions, environmental precautions, containment, cleanup and necessary cross-references? | Request product-specific spill response, exposure controls, environmental controls and disposal measures. Check consistency with Sections 8 and 13. |
| **7 — Handling and storage** | [§3.7](references/SDS_Section_07.md), pp. 63–67 | Are precautions for safe handling, conditions for safe storage and specific end uses coherent with physical hazards, incompatibilities and exposure scenarios? | Correct only using evidenced process constraints, incompatibility, environmental and storage requirements; check Sections 5, 8 and 10. |
| **8 — Exposure controls/personal protection** | [§3.8](references/SDS_Section_08.md), pp. 68–77 | Are available relevant occupational exposure limits, DNELs/PNECs, exposure controls and PPE specifications addressed? Are controls specific enough to be useful? | Verify current jurisdictional OELs and substance-specific data. Request exact PPE material, performance and breakthrough details when relevant; check corresponding exposure scenarios. |
| **9 — Physical and chemical properties** | [§3.9](references/SDS_Section_09.md), pp. 77–93 | Are relevant core physical/chemical properties supplied with units, conditions and data-availability explanations where required? Are properties consistent with hazard classifications? Are extra hazard-class properties addressed when appropriate? | Request measured/supported data, test methodology and relevance. Never replace `no data` with an invented number; check classification consequences against Section 2. Inspect the original PDF for any formulas in the guidance. |
| **10 — Stability and reactivity** | [§3.10](references/SDS_Section_10.md), pp. 93–97 | Do reactivity, stability, hazardous reaction potential, avoidable conditions, incompatible materials and hazardous decomposition products align? | Verify experimentally or from reliable supplier evidence; reconcile with safe storage, firefighting and spill measures (Sections 5–7). |
| **11 — Toxicological information** | [§3.11](references/SDS_Section_11.md), pp. 97–103 | Are relevant toxicological effects and hazard-class information stated sufficiently, clearly indicating whether data refer to the whole mixture or constituent substances? | Request robust study summaries, exposure route, reliability, classification support and justified data gaps; do not manufacture ATE/LD50/LC50 values. |
| **12 — Ecological information** | [§3.12](references/SDS_Section_12.md), pp. 103–108 | Is available evidence addressed for ecotoxicity, degradability, bioaccumulation, mobility, PBT/vPvB, endocrine properties and other adverse effects? | Request validated environmental studies and assessment conclusions, reconcile with aquatic hazard classification and spill/disposal advice. |
| **13 — Disposal considerations** | [§3.13](references/SDS_Section_13.md), pp. 109–111 | Are waste treatment, product and container disposal, and relevant practical precautions explained? | Verify local waste route/code only when legally and factually supportable; reconcile with Sections 6 and 8. |
| **14 — Transport information** | [§3.14](references/SDS_Section_14.md), pp. 111–115 | Does transport classification reflect applicable modal transport regimes and the appropriate headings for UN/ID number, shipping name, class, packing group, environmental hazards, precautions and bulk maritime transport? | Independently verify ADR/RID/ADN/IMDG/ICAO/IATA as applicable and the product state/packaging; **never derive a UN number from CLP category alone**. |
| **15 — Regulatory information** | [§3.15](references/SDS_Section_15.md), pp. 115–118 | Are relevant EU/national safety, health and environmental provisions and the chemical safety assessment status appropriately communicated? | Verify real authorisation, restriction, sector-specific and national obligations; cite current legal instrument and article rather than relying on the 2020 example list. |
| **16 — Other information** | [§3.16](references/SDS_Section_16.md), pp. 118–120 | Are revision changes, glossary, classification methods, statement text and training advice addressed as applicable? | Confirm source data and the verified Sections 2–3 classifications before entering complete H-statement text or calculation-method explanations. |

## General SDS issues — use ECHA Chapter 2

| Audit topic | ECHA guidance location | How to apply it in a correction register |
|---|---|---|
| Responsibility, competence, training | [Chapter 2](references/CH2_Source.md), §§2.2, 2.5, pp. 13–16 | Identify the responsible supplier/competent reviewer. Do not assume a legally prescribed course/certificate: the guide says no specific qualification course is set in REACH. |
| Section format and non-applicable fields | Chapter 2, §§2.6–2.7, pp. 16–17 | Confirm required headings/subheadings against current Annex II **Part B**; don't mistakenly make every numbered point in Part A a mandatory subheading. Distinguish `not applicable`, `not available` and content lost by extraction. |
| Updates, revision history and communication | Chapter 2, §§2.8–2.10, pp. 17–19 | Verify triggers and communication duties under applicable Article 31(9) and REACH Annex II. A document's age alone is not automatically proof of a breach. |
| SDS supply, language and exposure scenarios | Chapter 2, §§2.13–2.23, pp. 20–29 | Consider language obligations, supply timing, customer type, Article 31(1)/(3) triggers and whether an exposure scenario is required and consistent. |
| Consistency and test data | Chapter 2, §§2.11–2.12, 2.27, pp. 19–20 and 31–32 | Use the compilation sequence and cross-section checks; never demand new animal testing simply to fill SDS fields (the guide explicitly warns against that). |

## Exposure scenarios, special mixtures and recovered substances

- [Appendix 1](references/APP1_Source.md), pp. 121–127: how exposure scenario information may be communicated and aligned with Sections 7 and 8. Table 1 on pp. 124–125 is **layout-sensitive** and should be read from original page images.
- [Appendix 2](references/APP2_Source.md), pp. 128–129: special mixtures where constituent behaviour may be influenced by the matrix, such as alloys. Do not turn these interpretive notes into an automatic exemption.
- [Appendix 3](references/APP3_Source.md), pp. 130–132: considerations for recovered substances/mixtures and their transition from waste status. Review applicability case by case.
- [Appendix 4](references/APP4_Source.md), pp. 133–136: acronym glossary; abbreviations and definitions reflect the 2020 document.

## Expected structure of an actionable SDS finding

Use this schema for each material finding. Do not fill brackets using model invention.

```yaml
finding_id: SDS-001
jurisdiction: "EU / specified Member State [verify]"
SDS_section: "[e.g. 8.1]"
SDS_page: "[page]"
observed_wording: "[exact SDS quotation or 'Information not provided']"
issue: "[specific inconsistency/omission/possible error]"
status: "confirmed | probable | insufficient_evidence | parsing_issue"
severity: "critical | major | minor | informational"
confidence: "high | moderate | low"
authority:
  binding_law: "[current REACH/CLP article or Annex II paragraph, verified]"
  explanatory_guidance: "ECHA v4.0 (2020), §[source chapter], p.[number]"
proposed_action: "[what supplier must review, add, verify, remove or correct]"
replacement_text: "[copy-ready ONLY if all facts and wording verified; otherwise placeholder]"
supporting_evidence_needed: "[test report, formulation, classification record, etc.]"
knock_on_sections: ["[other SDS section requiring consequential review]"]
closure_criteria: "[what documents and checks would close the finding]"
```

### Non-negotiable quality checks

- A disagreement with an ECHA **example** is not, by itself, legal non-compliance.
- Original 2020 quotations of Annex II are not proof of the currently effective legal wording. Confirm the current regulation and application date.
- If the SDS omits a datum, check whether that datum is required and applicable before alleging a breach.
- Cross-check all numerical limits, units, hazard categories and legal thresholds against current primary sources.
- Do not propose corrected hazard classes or transport entries without independent supporting evidence.
- Every reported *confirmed legal* violation needs a **primary-law citation**, not just an ECHA guidance page reference.
