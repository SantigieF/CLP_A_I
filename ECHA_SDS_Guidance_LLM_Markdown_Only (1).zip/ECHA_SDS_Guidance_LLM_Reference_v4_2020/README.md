# ECHA SDS Guidance v4.0 (December 2020) — LLM reference package

**Document:** *Guidance on the compilation of safety data sheets*, Version 4.0, December 2020. **Reference:** ECHA-20-H-25-EN. **DOI:** 10.2823/77155.

## Start here

- `SDS_AUDIT_QUICK_REFERENCE.md` — primary navigation and correction-oriented audit playbook (an analyst-created summary, not an ECHA or legislative text).
- `ECHA_SDS_Guidance_2020_FULL_Reference.md` — a searchable master Markdown transcription of the source, grouped by sections and page references.
- `references/SDS_Section_01.md` through `references/SDS_Section_16.md` — chapter 3, one document per SDS section.
- `references/CH1_Source.md`, `CH2_Source.md` and `CH3INTRO_Source.md` — ECHA's introduction, general SDS compilation guidance, chapter 3 overview.
- `references/APP1_Source.md` through `APP4_Source.md` — exposure scenarios; special mixtures; recovered substances; glossary.
- `references/FRONT_Source.md` — title, legal notice, history and contents.
- `page_images/` — visual source pages flagged because of tables, graphics, boxed quotations, formulas or sample SDS layouts.
- `source_pages/` — unmodified PDF text-layer extraction for all 137 pages for comparison.
- `original_source/ECHA_SDS_Guidance_v4_2020.pdf` — complete original PDF with all page images and visuals.
- `source_manifest.json` and `QUALITY_AUDIT.md` — provenance, coverage and transcription limitations.

## Important legal boundary

This publication **is ECHA guidance from December 2020, not a current legal consolidation or legal advice**. Its legal notice expressly states that REACH is the authentic legal reference. The guidance references amendments up to that period, including Commission Regulation (EU) 2020/878; verify all current legal requirements, transition dates and classifications independently before asserting SDS non-compliance.

The document describes **REACH Annex II** (SDS compilation). **CLP Annex II** is different (special labelling and packaging). CLP Annex I provides hazard classification criteria, and Annex VI includes harmonised classification entries. Do not substitute one annex for another.

## Recommended implementation in an SDS audit skill

1. Add `SDS_AUDIT_QUICK_REFERENCE.md` to the skill's reference-routing instructions.
2. Store the 16 individual section files as separate retrievable knowledge documents, with the 2020 date and explanatory status in metadata.
3. Keep the underlying PDF available as the arbiter of exact quoted wording and complex layouts.
4. Load the relevant source section when the skill detects a candidate problem. Then verify the **current binding legal requirement** independently using applicable REACH Annex II.
5. Produce a structured finding with observed wording, why it is problematic, supporting legal reference, safe correction, necessary evidence and impacted sections.
6. If primary law or technical data cannot be checked, output `Unverified — evidence required`, not a confirmed violation or fabricated corrected SDS entry.

## Conversion details

The source PDF includes 137 pages, all retained in original form. The converter maps ECHA chapter headings to subsection documents by the actual PDF heading positions, not approximate page spans alone. Source text blocks are converted to Markdown paragraphs without intentional substantive paraphrasing. Page references are inserted before each page's content.

A PDF text layer is **not** a perfect replacement for layout-sensitive material: column associations, table footnotes, selected chemical notation and equations may need visual review. Page images and the original PDF are included for that reason. A lower-page footnote near a chapter transition may refer to the preceding chapter; those are labelled explicitly in the transcription when detected. Do not treat chapter-level example text as mandatory legislative wording.

## Lightweight Markdown-only bundle

The lightweight ZIP deliberately excludes `original_source/`, `source_pages/` and `page_images/` to reduce upload size. **Its source-page and image links cannot work without the full package**, and it must not be used alone when an audit depends on tables, formulas or diagram geometry. For regulatory review use the full package, or upload the original ECHA PDF separately alongside the Markdown references.
