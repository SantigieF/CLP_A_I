# ECHA Guidance on the Compilation of Safety Data Sheets — LLM Reference

**Source:** ECHA Guidance on the compilation of safety data sheets, Version 4.0, December 2020; reference ECHA-20-H-25-EN; DOI: 10.2823/77155.

**Important:** Guidance from **2020**, not current binding REACH legislation. Apply original legal sources for compliance decisions. The guidance includes extracts from the law as it stood for this edition; amendments and applicability must be verified independently.

**Navigation:** Each individual SDS section has a dedicated, smaller reference file for retrieval. Original page images accompany visually complex source pages.

## Contents

- [1. General introduction](references/CH1_Source.md) — ECHA pp. 8–12
- [2. Issues to consider when compiling an SDS](references/CH2_Source.md) — ECHA pp. 13–32
- [3. Detailed information — overview](references/CH3INTRO_Source.md) — ECHA pp. 33–33
- [3.1 SDS SECTION 1 — Identification of the substance/mixture and of the company/undertaking](references/SDS_Section_01.md) — ECHA pp. 33–40
- [3.2 SDS SECTION 2 — Hazards identification](references/SDS_Section_02.md) — ECHA pp. 41–46
- [3.3 SDS SECTION 3 — Composition/information on ingredients](references/SDS_Section_03.md) — ECHA pp. 46–57
- [3.4 SDS SECTION 4 — First aid measures](references/SDS_Section_04.md) — ECHA pp. 57–59
- [3.5 SDS SECTION 5 — Firefighting measures](references/SDS_Section_05.md) — ECHA pp. 59–60
- [3.6 SDS SECTION 6 — Accidental release measures](references/SDS_Section_06.md) — ECHA pp. 61–63
- [3.7 SDS SECTION 7 — Handling and storage](references/SDS_Section_07.md) — ECHA pp. 63–67
- [3.8 SDS SECTION 8 — Exposure controls/personal protection](references/SDS_Section_08.md) — ECHA pp. 68–77
- [3.9 SDS SECTION 9 — Physical and chemical properties](references/SDS_Section_09.md) — ECHA pp. 77–93
- [3.10 SDS SECTION 10 — Stability and reactivity](references/SDS_Section_10.md) — ECHA pp. 93–97
- [3.11 SDS SECTION 11 — Toxicological information](references/SDS_Section_11.md) — ECHA pp. 97–103
- [3.12 SDS SECTION 12 — Ecological information](references/SDS_Section_12.md) — ECHA pp. 103–108
- [3.13 SDS SECTION 13 — Disposal considerations](references/SDS_Section_13.md) — ECHA pp. 109–111
- [3.14 SDS SECTION 14 — Transport information](references/SDS_Section_14.md) — ECHA pp. 111–115
- [3.15 SDS SECTION 15 — Regulatory information](references/SDS_Section_15.md) — ECHA pp. 115–118
- [3.16 SDS SECTION 16 — Other information](references/SDS_Section_16.md) — ECHA pp. 118–120
- [Appendix 1 — Exposure scenario information](references/APP1_Source.md) — ECHA pp. 121–127
- [Appendix 2 — SDS for special mixtures](references/APP2_Source.md) — ECHA pp. 128–129
- [Appendix 3 — Recovered substances and mixtures](references/APP3_Source.md) — ECHA pp. 130–132
- [Appendix 4 — Glossary and acronyms](references/APP4_Source.md) — ECHA pp. 133–136

---



---

<a id="ch1"></a>


# 1. General introduction

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-ch1-page-8"></a>
**ECHA printed page 8** — [original PDF page 8](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=8)

1 General Introduction

1.1 The safety data sheet

Safety data sheets (SDSs) have been a well-accepted and effective method for the provision of information to recipients of substances and mixtures in the EU. These have been made an integral part of the system of Regulation (EC) No 1907/2006 (REACH)1. The original requirements of REACH for SDSs have been further adapted to take into account the rules for safety data sheets of the Globally Harmonized System (GHS)2 and the implementation of other elements of the GHS into EU legislation that were introduced by Regulation (EC) No 1272/2008 (CLP)3 via amendments to Annex II of REACH4.

The SDS provides a mechanism for transmitting appropriate safety information on substances and mixtures where:

- a substance or a mixture meets the criteria for classification as hazardous according to CLP; or

- a substance is persistent, bioaccumulative and toxic (PBT) or very persistent and very bioaccumulative (vPvB), according to the criteria given in Annex XIII of REACH, or;

- a substance is included in the candidate list for eventual authorisation according to Article 59 (1) of REACH for any other reasons.  (See Article 31(1) of REACH).

Under certain conditions some mixtures which do not meet the criteria for classification as hazardous according to CLP also require an SDS to be prepared or be made available on request (See Article 31(3) of REACH, and notes to tables 3.4.6, 3.6.2, 3.7.2, 3.8.3 and 3.9.4 of Annex I of CLP extracted below):

Skin Sensitiser:  Table 3.4.6 Concentration limits for elicitation of components of a mixture  Note 1: This concentration limit for elicitation is used for the application of the special labelling requirements of section 2.8 of Annex II to protect already sensitised individuals. A SDS is required for the mixture containing a component at or above this concentration. For sensitising substances with specific concentration limit lower than 0,1 %, the concentration limit for elicitation should be set at one tenth of the specific concentration limit.  Carcinogenicity: Table 3.6.2 Generic concentration limits of ingredients of a mixture classification as carcinogen that trigger classification of a mixture

1 Regulation (EC) No 1907/2006 of the European Parliament and of the Council of 18 December 2006 concerning the Registration, Evaluation, Authorisation and Restriction of Chemicals (REACH), establishing a European Chemicals Agency, amending Directive 1999/45/EC and repealing Council Regulation (EEC) No 793/93 and Commission Regulation (EC) No 1488/94 as well as Council Directive 76/769/EEC and Commission Directives 91/155/EEC, 93/67/EEC, 93/105/EC and 2000/21/EC (OJ L 396, 30.12.2006, corrected version in OJ L136, 29.5.2007, p.3).

2 All editions of the GHS are accessible at: https://www.unece.org/trans/danger/publi/ghs/ghs_welcome_e.html

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 3 Regulation (EC) No 1272/2008 of the European Parliament and of the Council of 16 December 2008 on classification, labelling and packaging of substances and mixtures amending and repealing Directives 67/548/EEC and 1999/45/EC, and amending Regulation (EC) No 1907/2006 (OJ L 353, 31.12.2008, p.1).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 4 Commission Regulation (EU) No 453/2010 of 20 May 2010 amending Regulation (EC) No 1907/2006 of the European Parliament and of the Council on the Registration, Evaluation, Authorisation and Restriction of Chemicals (REACH) (O.J. L133 31.05.2010, p1-43) and Commission Regulation (EU) 2015/830 amending Regulation (EC) No 1907/2006 of the European Parliament and of the Council on the Registration, Evaluation, Authorisation and Restriction of Chemicals  (REACH).


<a id="echa-ch1-page-9"></a>
**ECHA printed page 9** — [original PDF page 9](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=9)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 9](page_images/ECHA_2020_page_009.jpg)

Note 1:   If a Category 2 carcinogen is present in the mixture as an ingredient at a concentration ≥ 0,1 % a SDS shall be available for the mixture upon request

Reproductive Toxicity Table 3.7.2 : Generic concentration limits of ingredients of a mixture classified as reproduction toxicants or for effects on or via lactation that trigger classification of the mixture

Note 1: If a Category 1 or Category 2 reproductive toxicant or a substance classified for effects on or via lactation is present in the mixture as an ingredient at a concentration at or above 0,1 %, a SDS shall be available for the mixture upon request.

Specific target organ toxicity-single exposure : Table 3.8.3 : Generic concentration limits of ingredients of a mixture classified as a specific target organ toxicant that trigger classification of the mixture as Category 1 or 2

Note 1: If a Category 2 specific target organ toxicant is present in the mixture as an ingredient at a concentration ≥ 1,0 % a SDS shall be available for the mixture upon request.

Specific target organ toxicity-repeated exposure :  Table 3.9.4 : Generic concentration limits of ingredients of a mixture classified as a specific target organ toxicant that trigger classification of the mixture

Note1: If a Category 2 specific target organ toxicant is present in the mixture as an ingredient at a concentration ≥ 1,0 % a SDS shall be available for the mixture upon request.

SDSs do not have to be provided for articles. Although the SDS format may, for a few specific articles, be used to convey safety information down the supply chain, it is not adapted to most articles5.

The SDS follows a 16-section format which is internationally agreed. The SDS must be supplied in an official language of the Member State(s) where the substance or mixture is placed on the market, unless the Member State(s) concerned provide(s) otherwise (Article 31(5) of REACH)6.

Where a Chemical Safety Report (CSR) is required to be prepared for a substance, the information in the SDS for the substance must be consistent with that provided in the CSR, as well as with that provided in the registration dossier (when the CSR is prepared according to Article 14). In addition, according to Article 31(7) of REACH, registrants and downstream users that are required to prepare a CSR, must place the relevant exposure scenario(s) into an annex to the safety data sheet. Also, according to Article 62(4)(d) as part of the application for authorisation, the applicant has to prepare a CSR, including an exposure scenario for the use that is being applied for (Annex I, section 5.1.2). According to Annex I section 0.7 if the substance is placed on the market, the relevant exposure scenario(s), including the risk management measures and operational conditions shall be included in an annex to the safety

5 Although according to Article 4(8) and Section 2.1 of Annex I of CLP certain objects described in CLP using the word “article” (specifically in the combinations “explosive articles”, “pyrotechnic article”  or “substances, mixtures and articles … …  which are manufactured with a view to producing a practical, explosive or pyrotechnic effect” as defined via point 2.1.1.1 (b) or (c) and 2.1.1.2 of Annex I to CLP) should be classified and labelled according to CLP, the usage of the word “article” in this combined context differs from the stand-alone definition of an “article” both under REACH (Article 3 (3)) and under CLP (Article 2 (9)). For the purposes of REACH these are more likely to be considered as a combination of an article (the container/packaging) and a substance/mixture (see ECHA Guidance on requirements for substances in articles). If appropriate, in such cases the SDS would be supplied for the corresponding substance/mixture. Note that Directive 2013/29/EU requires an SDS for the pyrotechnic article for vehicles: https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32013L0029

6 ECHA has published the table “Languages required for labels and safety data sheets” which is available on the SDSs webpage of the ECHA website at:  https://echa.europa.eu/safety-data-sheets


<a id="echa-ch1-page-10"></a>
**ECHA printed page 10** — [original PDF page 10](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=10)

data sheet. Downstream users have to consider relevant exposure information received from suppliers when compiling their safety data sheets. For mixtures, there are several options for placing relevant exposure scenarios into an annex or for including relevant exposure information in the core Sections 1 – 16 of the SDS. If however, a downstream user is required to prepare his own CSR under Article 37 of REACH and this results in the generation of an exposure scenario, this exposure scenario must be placed in an annex to the SDS7.

1.2 Aim of this guidance

The aim of this guidance is to assist industry in determining which tasks and requirements have to be complied with in order to fulfil their obligations under Article 31 of REACH (Requirements for safety data sheets) and Annex II of REACH, as replaced by:

- Commission Regulation (EU) 2020/878: amending Annex II by introducing specific requirements regarding nanoforms of substances, adapting to the 6th and 7th revision of the GHS, and adding requirements regarding the Unique Formula Identifier (as set by Annex VIII to Regulation (EC) 1272/2008), endocrine disrupting properties, specific concentration limits, M-factors and acute toxicity estimates.

This guidance provides information especially on:

- issues to consider when compiling an SDS;

- details of the requirements for information to be included in each Section of an SDS;

- who should compile the SDS and what competences the author should have.

The references to the legal text have been updated to reflect the latest version of Annex II (i.e. the Annex to Regulation (EU)  2020/878).  Furthermore, as of 1 June 2017, substances and mixtures must be classified and labelled according to CLP only, and this has to be reflected in the appropriate sections of the SDS. Therefore, references and advice related to the obsolete DSD/DPD classification system have been removed from this Guidance.

1.3 Transitional provision to implement the latest version of Annex II to REACH

In accordance with Article 2 of Regulation (EU)  2020/878, safety data sheets compiled in accordance with Regulation (EC) No 1907/2006, as amended by Commission Regulation (EU) 2015/830, can continue to be used until 31 December 2022. This is without prejudice to the obligation to update the safety data sheets in accordance with Article 31(9) of Regulation (EC) No 1907/2006, and to the cases where the Unique Formula Identifier (UFI) is added to safety data sheets as provided for in section 5 of Part A of Annex VIII to Regulation (EC) No 1272/2008 (CLP).  In other words, until 31 December 2022, all safety data sheets provided after 1st January 2021, including new and updated safety data sheets, can be provided in the current format according to Regulation (EU) 2015/830 or in the new format according to Regulation (EU) 2020/878, including the following scenarios:

- No change to safety data sheet

7 Detailed information on how downstream users can fulfil their obligations under REACH is provided in the Guidance for downstream users available at echa.europa.eu/guidance-documents/guidance-on-reach.


<a id="echa-ch1-page-11"></a>
**ECHA printed page 11** — [original PDF page 11](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=11)

•
Small change to safety data sheets not within scope of Article 31(9)
•
Update to safety data sheets within the scope of Article 31(9) or introducing the UFI
•
New safety data sheets authored for the first time after 1st January 2021

All safety data sheets provided after 31 December 2022 have to be in the format according to
Regulation (EU) 2020/878. It is recommended that the new format, as set out in Regulation
(EU) 2020/878,  is adopted, as soon as practicable, to ensure that all SDSs comply by the 31
December 2022 deadline.

1.4 Target audience of this guidance

The main target audience of this guidance is those compiling SDSs for use by suppliers of substances and mixtures for which SDSs are required by Article 31 of REACH. While the REACH requirements regarding SDSs are directed at suppliers of substances and mixtures, this document also provides useful information for recipients of an SDS. It is noted in this context that the information provided by SDS will also help employers to meet their obligations under Directive 98/24/EC8 on the protection of the health and safety of workers from the risks related to chemical agents at work.

The SDS should enable users to take the necessary measures relating to protection of human health and safety at the workplace, and protection of the environment.

1.5 Relation with CLP and GHS

Regulation (EC) No 1272/2008 on classification, labelling and packaging of substances and mixtures (CLP) harmonises the provisions and criteria for the classification and labelling of substances and mixtures within the Union9, taking into account the classification criteria and labelling rules of the UN Globally Harmonised System of Classification and Labelling of Chemicals (GHS). The CLP Regulation contributes to the UN GHS aim of describing and communicating the same hazards in the same way around the world. The CLP Regulation entered into force on the 20th of January 2009.

On 12 April 2017, Commission Regulation (EU) 2017/54210 entered into force, adding a new Annex VIII to the CLP Regulation. It harmonises the information relating to emergency health response that companies placing certain hazardous mixtures on the EU market are required to submit to the national appointed bodies. The information submitted needs to be consistent with the information in the SDS. Furthermore, the Unique Formula Identifier (UFI) required by the same Annex may need to be indicated in the SDS of certain hazardous mixtures11.

In the EEA, the required SDS format and content are defined by Article 31 and Annex II to REACH. These have been adapted to align them with the GHS requirements, in particular with

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   8 Council Directive 98/24/EC of 7 April 1998 on the protection of the health and safety of workers from the risks related to chemical agents at work (fourteenth individual Directive within the meaning of Article 16(1) of Directive 89/391/EEC), OJ L131, 5..5.1998, p.11).

9 With the entry into force of the Treaty of Lisbon in 2009, the term “Community” was  replaced by “Union”. Please, note that the CLP Regulation had not been amended to implement this change and therefore the term “Community” is still used in some quotes from the legal text made within this document.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 10 Commission Regulation (EU) 2017/542 of 22 March 2017 amending Regulation (EC) No 1272/2008 of the European Parliament and of the Council on classification, labelling and packaging of substances and mixtures by adding an Annex on harmonised information relating to emergency health response.

11 See Guidance on harmonised information relating to emergency health response – Annex VIII to CLP: https://echa.europa.eu/documents/10162/13643/guidance_on_annex_viii_to_clp_en.pdf/


<a id="echa-ch1-page-12"></a>
**ECHA printed page 12** — [original PDF page 12](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=12)

the “guidance on the preparation of safety data sheets (SDS)” given in Annex 4 of the GHS12, as well as to be fully in line with the CLP Regulation. This version of the Guidance on the compilation of SDSs reflects the text of the revision of Annex II to REACH, as replaced by the Annex to Regulation (EU)  2020/878 (amending REACH) with effect from 1 January 2021.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   12 The current version of the GHS and all previous versions are available at: https://www.unece.org/trans/danger/publi/ghs/ghs_welcome_e.html


---

<a id="ch2"></a>


# 2. Issues to consider when compiling an SDS

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-ch2-page-13"></a>
**ECHA printed page 13** — [original PDF page 13](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=13)

2 Issues to consider when compiling an SDS

2.1 Definition of a safety data sheet (an SDS)

An SDS is a document for which the purpose and role within the harmonised system can be described as follows (based on the text in chapter 1.5 of the UN GHS revision 713):

The SDS should provide comprehensive information about a substance or mixture for use in workplace chemical control regulatory frameworks. Both employers and workers14 use it as a source of information about hazards, and to obtain advice on safety precautions. The SDS is product related and usually [in the absence of relevant attached exposure scenario(s)] is not able to provide specific information that is relevant for any given workplace where the product may finally be used, although where products have specialized end uses the SDS information may be more worker-specific. The information therefore enables the employer (a) to develop an active programme of worker protection measures, including training, which is specific to the individual workplace; and (b) to consider any measures which may be necessary to protect the environment.

In addition, the SDS provides an important source of information for other target audiences. So certain elements of information may be used by those involved with the transport of dangerous goods, emergency responders including poison centres, those involved in the professional use of pesticides and consumers. However, these audiences receive additional information from a variety of other sources such as the UN Recommendations on the Transport of Dangerous Goods, Model Regulations and package inserts for consumers and will continue to do so. The introduction of a harmonised labelling system therefore, is not intended to affect the primary use of the SDS which is for workplace users.

Furthermore, the content of the SDS is an important source of information for the preparation of the submission required under Annex VIII to Regulation (EC) 1272/2008 (CLP).

The required format and content of an SDS within the EU Member States in which the REACH Regulation directly applies (and in other countries which have adopted the REACH Regulation) is defined in Annex II of REACH.

All information contained in the SDS must be written in a clear and concise manner.

2.2 Responsibility for the content of an SDS

Where there is a chain of supply, the requirements of REACH in relation to the provision of safety data sheets apply at each stage of the supply chain. The initial responsibility for drawing up the safety data sheet falls on the first supplier of the substance onto the EU market. In practice, this can be the manufacturer, importer or – in some cases – the only representative who should anticipate, so far as it is reasonably practicable, the uses to which the substance or mixture may be put. Actors further down the supply chain should also provide a safety data sheet, drawing on, checking the adequacy of, and adding to, the information provided by their suppliers to cater for the specific needs of their customers. In all cases, suppliers of a

13 http://www.unece.org/trans/danger/publi/ghs/ghs_rev07/07files_e.html; Globally Harmonized system of Classification and Labelling of Chemicals (GHS). Seventh Revised Edition, 2017.United Nations.

14 It should be noted that in the European Union regulatory framework the SDS is clearly targeted at the employer who should use it as the basis of information and instructions which he transmits to the employee under Article 8.1 4th indent of Directive 98/24/EC. However, the employee is NOT the primary target of the document and its provision to the employee does not release the employer from his obligations under Directive 98/24/EC.


<a id="echa-ch2-page-14"></a>
**ECHA printed page 14** — [original PDF page 14](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=14)

substance or a mixture which requires a safety data sheet have the responsibility for its contents, even though they may not have prepared the safety data sheet themselves. In such cases, the information provided by their suppliers is clearly a useful and relevant source of information for them to use when compiling their own safety data sheets. However, they will remain responsible for the accuracy of the information on the safety data sheets they provide (this also applies to SDSs distributed in languages other than the original language of compilation). It should be noted that the supplier always needs to add their contact details in Section 1.3 of the SDS, even when they use the SDS from their supplier without changing any content (see section 3.1 of this guidance document for more details).

2.3 Claiming an SDS as confidential

The information that is required to appear in an SDS cannot be claimed as confidential.

2.4 Possibility of charging for supply of an SDS

According to Article 31(8) and 31(9) of REACH, the SDS and any required updates to it must be provided free of charge.

2.5 Who should compile an SDS

The text of Annex II specifies in point 0.2.3 that:

“[…] The safety data sheet shall be prepared by a competent person who shall take into account the specific needs and knowledge of the user audience, as far as they are known. Suppliers of substances and mixtures shall ensure that such competent persons have received appropriate training, including refresher training.”

2.5.1 Definition of a competent person

No specific definition of the “competent person” is given in the Regulation. However the term may usefully be defined in this context as meaning a person (or combination of persons) – or a coordinator of a group of people - who has or have, as a result of their training, experience and continued education, sufficient knowledge for the compilation of the respective sections of the SDS or of the entire SDS.

The supplier of the SDS can delegate this function to his own staff or to third parties. It is not necessary that the expert knowledge be provided in full by one single competent person.

It is understood that a single person very rarely has extensive knowledge in all the fields covered by an SDS. It is thus necessary that the competent person rely upon additional competences, either internal or external. The competent person should ensure the consistency of the SDS, especially if he acts as the coordinator of a group of people.

2.5.2 Training and continued education of competent persons

It should be noted (from the text quoted above) that there is a specific duty on the supplier of the substances and mixtures to ensure that the competent persons have received appropriate training and refresher training. There is no specific indication in the REACH Regulation of the training which the competent person should have or that he should attend a special course or pass an official examination. However attendance at such courses and any examination and certification may be useful in demonstrating the required competence.


<a id="echa-ch2-page-15"></a>
**ECHA printed page 15** — [original PDF page 15](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=15)

Training and continued education for these persons may be given internally or externally. It is recommended to document the organisational flow in the compilation and update of SDSs within a company, e.g. by way of internal guidelines or operating procedures.

If SDSs are to be compiled for explosives, biocides, plant protection products15, or surfactants, additional knowledge on specific product legislation applicable to them is needed.

The following (non-exhaustive) list gives an indication of various fields, a knowledge of which a person wishing to demonstrate their competence could refer to:

1. Chemical nomenclature

2. European Regulations and Directives relevant to chemicals and their implementations into MS national legislation, applicable national legislation (in their valid current versions), to the extent that these are relevant in the compilation of SDSs, for instance (non-exhaustive list, shortened titles):

- REACH: Regulation (EC) No 1907/2006 (in particular as amended by Commission Regulation (EU) 2020/878with respect to SDSs)

- CLP: Regulation (EC) No 1272/2008

- Chemical Agents Directive: Directive 98/24/EC

- Indicative Occupational exposure limits: Directives 2000/39/EC, 2006/15/EC, 2009/161/EU, 2017/164/EU and  2019/1831/EU

- Protection of workers from the risks related to exposure to carcinogens or mutagens at work: Directive 2004/37/EC

- Improvements in the safety and health of pregnant workers, workers who have recently given birth and women who are breastfeeding: Directive 92/85/EEC

- Personal protective equipment: Regulation (EU) 2016/425

- Inland transport of dangerous goods: Directive 2008/68/EC

- Detergent Regulation: Regulation(EC) No 648/2004

- Protection of young people at work: Directive 94/33/EC

- Waste: Directive 2008/98/EC

3. Relevant national or international guidelines of the respective sector association

4. First aid measures

- (See chapter 3.4 of this document)

5. Accident prevention

- Fire and explosion prevention, fire fighting, extinguishing media

- Measures in the event of accidental release

- (See chapter 3.6 of this document)

6. Measures for safe handling and storage

- (See in particular chapter 3.7 of this document)

7. Physical and chemical properties:

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   15 For a list of relevant legislation on plant protection and biocidal products see Article 15 of REACH.


<a id="echa-ch2-page-16"></a>
**ECHA printed page 16** — [original PDF page 16](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=16)

- Particularly properties as listed and discussed in the legal text below under Subsection 9.1 of Annex II (see chapter 3.9 of this document).

8. Toxicology/eco-toxicology:

- Particularly properties as listed and discussed in the legal text below under Section 11 and 12 of Annex II (see chapter 3.11 and 3.12 of this document).

9. Transport provisions

- Particularly as listed and discussed in the legal text below under Section 14 of Annex II (see chapter 3.14 of this document).

10. National provisions

- Relevant national provisions, such as (this is a non-exhaustive list)

In Germany:

- Water hazard classes (Wassergefährdungsklassen)

- Technical instruction air (TA-Luft)

- Technical rules for hazardous substances (Technische Regeln für Gefahrstoffe)

In France:

- Tableaux de maladies professionnelles

- Nomenclature des installations classées pour la protection de l‘environnement

In the Netherlands:

- De Algemene Beoordelingsmethodiek Water (ABM)

- National product registers (for example Denmark, Finland, Italy, Sweden etc.)

2.6 The sequence, naming and numbering of sections and subsections which must be used in an SDS

The name of each section and subsection heading, of individual headings and sub-headings in the SDS is specified in Annex II. In particular Part B of the Annex II requires that:

“The safety data sheet shall include the following 16 headings in accordance with Article 31(6) and in addition the subheadings also listed except Section 3, where only subsection 3.1 or 3.2 need to be included as appropriate:”

(See legal text for the full list of headings and sub-headings).

It should be noted that for the Section headings themselves the word “SECTION” is a part of the heading specified as being required. For example, the full heading for Section 1 of the SDS is:

“SECTION 1: Identification of the substance/mixture and of the company/undertaking”

No numbering at a level lower than the sub-heading is legally required, but this may be introduced by the supplier in the interest of clarity (e.g. in Section 14 to differentiate between different modes of transport).

In particular, the numbering of the sub-paragraphs and points in Part A of the Annex II legal text should not be confused with the required numbering of sections and subsections according


<a id="echa-ch2-page-17"></a>
**ECHA printed page 17** — [original PDF page 17](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=17)

to Part B.

Thus, for example in the case of SECTION 11 toxicological information, according to Part B the following heading and sub-headings must be used:

“SECTION 11: Toxicological information

11.1. Information on hazard classes as defined in Regulation (EC) No 1272/2008”

The presence of points (”sub-sub-paragraphs”) numbered 11.1.1, 11.1.2, … …  11.1.12.2, … … etc in Part A under the heading of SECTION 11 to facilitate distinguishing of the individual elements does not mean that the information required under these points needs to be included under an identical description or heading to that given in Part A at any level below the subsection level. The structure of the SDS, as defined by the section and subsection headings is only pre-defined to the extent given in Part B.

This also applies to all the examples given for the structuring of data within any sections and subsections of an SDS contained in this document. Any sub-structuring or titles of further subsections of data given beyond the parent SECTION and the first subsection numbering is only an example of a possible structure.

The information that the SDS must contain within each of these headings and sub-headings is discussed in more detail in chapter 3 of this document. With the exception of subsections 3.1 and 3.2 (where either one or the other should contain information) some information must be entered in every subsection, even if this “information” is only an explanation of why data is not available or confirmation of non-applicability etc. Information should be inserted into subsections, not directly under the parent section heading.

Where a document using the format of an SDS is produced for a substance or mixture that does not require an SDS according to Article 31 of REACH (e.g. as a convenient way of supplying information required by Article 32 or based on a commercial decision to supply “SDS-like” documents for all substances and mixtures supplied by an actor) the requirements for content in each of the sections would not apply. In such cases it may be advisable to explain that the document is outside the scope of Article 31 of REACH for the convenience of recipients and enforcing authorities.

2.7 Necessary degree of completeness when providing information in an SDS

The information requirements are explained in detail in chapter 3. It should be noted that where specific data are not applicable or where data are not available, this must be clearly stated. Where the legal text states “if available”, this means not only that the information exists but that it is accessible to the safety data sheet provider.

2.8 Need to update SDSs

The conditions under which an SDS must be updated and re-issued are given in Article 31(9) of REACH as follows:

“9. Suppliers shall update the safety data sheet without delay on the following occasions:

(a) as soon as new information which may affect the risk management measures, or new information on hazards becomes available;

(b) once an authorisation has been granted or refused;

(c) once a restriction has been imposed.


<a id="echa-ch2-page-18"></a>
**ECHA printed page 18** — [original PDF page 18](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=18)

The new, dated version of the information, identified as ‘Revision: (date)’, shall be provided free of charge on paper or electronically to all former recipients to whom they have supplied the substance or mixture within the preceding 12 months. Any updates following registration shall include the registration number.”

Thus, although there are industry documents available which give recommendations on when a change in an SDS is considered a “major” or a “minor” change, this terminology is not used in the REACH Regulation. Only the changes according to Article 31 (9) of REACH give rise to a legal obligation to provide updated versions to all recipients to whom the substance or mixture has been supplied within the preceding 12 months. Paragraph 42 of the general court ruling T- 268/10 RENV16 from 2015 (confirmed by the court case C-650/15-P in 2017), provides that the addition of a substance to the candidate list (Article 59 of REACH) fulfils Article 31(9)(a) and requires an update of the SDS, with specific additional advice for the recipient of the SDS (for the substance as such or in a mixture) related to the new candidate list status of the substance. Sector and branch organisations may provide their own guidance on when it is desirable to additionally send updated versions of SDSs which are not specifically required by Article 31(9) of REACH, but such additional updates are not a legal requirement.

According to Article 31(9)(b) an SDS shall be updated without delay, once an authorisation has been granted. Authorisations, granted according to Article 60 of REACH, impose conditions on the use of the authorised substance. These conditions include not only the risk management measures and operational conditions, described in the exposure scenarios of the chemical safety report, referred to in the authorisation decision, but also any monitoring arrangements or additional conditions affecting risk management measures indicated in the authorisation decision. In line with Article 31(9)(a) the new information which affects risk management measures by downstream users has to be provided in the update of the SDS without delay (see also the clarification in section 3.15 of this guidance, on authorisation decisions containing obligations for downstream users).

Nevertheless, it is recommended to review the totality of the contents of an SDS at regular intervals. It might be expected that the frequency of such reviews would be commensurate with the hazards of the substance or mixture and that the review would be carried out by a competent person.  In addition to the update requirements outlined in Article 31(9), an SDS will need to be updated due to a legislative change in the new Annex II to REACH, following the timelines provided in the amending regulation.

2.9 Need to communicate changes in the SDS

The text of point 0.2.5 of Annex II to REACH specifies that:

“0.2.5. The date of compilation of the safety data sheet shall be given on the first page. When a safety data sheet has been revised and the new, revised version is provided to recipients, the changes shall be brought to the attention of the recipient in Section 16 of the safety data sheet, unless they have been indicated elsewhere. For the revised safety data sheets, the date of compilation, identified as ‘Revision: (date)’, shall appear on the first page, as well as one or more indications of which version is replaced, such as version number, revision number, or supersedes date.”

Thus, revisions must be identified as such on the first page and information on the changes must be given either in Section 16 or elsewhere in the SDS.

As indicated in 2.8 above, for any revision to an SDS according to Article 31(9) of REACH or

16 https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:62010TJ0268&from=EN


<a id="echa-ch2-page-19"></a>
**ECHA printed page 19** — [original PDF page 19](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=19)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 19](page_images/ECHA_2020_page_019.jpg)

due to a legislative change in Annex II to REACH, the revised SDS must be provided to all former recipients who received the substance or mixture within the preceding 12 months. A supplier may also choose to (additionally) re-issue SDSs retrospectively for other revisions which he may consider warrant such additional action. It is suggested that an incremental numbering system be used to identify new versions of an SDS. In such a system, changes to versions requiring provision of updates according to Article 31(9) could be identified by an increment by an integer, while other changes could be identified by an increment by a decimal, e.g.:

Version 1.0: initial issue

Version 1.1: first change(s) not requiring update and re-issue to former recipients

Version 1.2: second change(s) not requiring update and re-issue to former recipients

Version 2.0: first change requiring provision of update according to Article 31(9) to former recipients.

Etc.

This is just an example of how to facilitate traceability of versions. There are many other systems.

2.10 Potential need to keep records of SDSs and their amendments

The first sentence of Article 36(1) of REACH requires that:

“1. Each manufacturer, importer, downstream user and distributor shall assemble and keep available all the information he requires to carry out his duties under this Regulation for a period of at least 10 years after he last manufactured, imported, supplied or used the substance or mixture”.

As the compilation and supply of safety data sheets, as well as taking into account the information from the SDS in using substances and mixtures, are obligations under REACH, SDSs are for both the suppliers of SDSs and their recipients “information he requires to carry out his duties under this Regulation”, which is to be retained for a minimum period of 10 years. Furthermore, the information used in the compilation of the SDS is itself likely to constitute information required to carry out duties under REACH and may in any case be required to be kept independently of its relation to the content of the SDS. Holders of both SDSs and other information may in any case decide that it should be retained for product liability and other legal requirements and it might be considered appropriate (for example for substances and mixtures with chronic effects) to keep this information for a period of more than 10 years, depending on the applicable national laws and regulations.

2.11 Example of sequence for collecting and collating information for compiling the SDS

A suggestion for a step-wise approach to the creation of an SDS to ensure its internal consistency is given in Figure 1 below (the numbers refer to the sections of the SDS):

Figure 1 below shows the process as a linear one to stress that, for example, the final identification of hazards in Section 2 of the SDS is not likely to be possible until the inputs to other sections have been considered. In reality the process is likely to be an iterative one involving consideration of some aspects in different sequences to that shown or even in parallel.


<a id="echa-ch2-page-20"></a>
**ECHA printed page 20** — [original PDF page 20](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=20)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 20](page_images/ECHA_2020_page_020.jpg)

9. Physical and chemical
properties incl.
classification
10. Stability and reactivity
11. Toxicological
information incl.
classification
12. Ecological information
incl. classification

3. Composition and determination of hazard classification of components

1. Identification

14. Transport 15. Regulatory information 8. Exposure controls 7. Handling and storage

4. First aid 5. Fire-fighting 6. Accidental release

13. Disposal 16. Other information

2. Hazard identification

Figure 1: Example sequence for compiling an SDS

2.12 How to help to ensure consistency and completeness of the SDS

The SDS gives information on a very wide range of aspects of occupational health and safety, transport safety and environmental protection. As SDSs are frequently not compiled by just one person but rather by several members of staff, unintended gaps or overlaps cannot be ruled out. Consequently, it is useful to subject the finished SDS and its annex (if applicable) to a consistency and plausibility check before providing it to recipients. It may be desirable for the final review to be carried out by a single competent person rather than separate individuals to allow an overview of the document as a whole. As part of a completeness check, it is recommended to also verify that the information in the SDS is consistent with the information on the label and with the REACH registration dossier in the case of compilation made by a manufacturer or importer of registered substances.

2.13 Ways in which, and by when, the SDS must be provided

According to Article 31 (8) of REACH “A safety data sheet shall be provided free of charge on paper or electronically no later than the date on which the substance or mixture is first supplied.”


<a id="echa-ch2-page-21"></a>
**ECHA printed page 21** — [original PDF page 21](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=21)

Thus, the safety data sheet can be provided on paper, for example by letter, by fax or electronically, for example by email.

It should be noted however that in this context the wording “shall be provided” is to be understood as a proactive duty on the supplier to actually deliver the SDS (and every required update) rather than just make it available passively, for example on the internet or reactively by delivering it on request. Therefore, ECHA’s Forum comprising national enforcement representatives agreed that, for example, simply posting a copy of an SDS (or an update to one) on a web site alone would not be considered as having complied with the duty to “provide”. In the case of electronic “provision”, supply of the SDS (and any corresponding exposure scenario attachments) as an attachment to an e-mail in a format which is generally accessible to all recipients would therefore be acceptable. By contrast, sending an e-mail with a link to a general web-site where the SDS (or latest updated SDS) needs to be found and downloaded from would not be acceptable. Most national enforcement authorities agree that supplying an SDS by providing a link must fulfil the following pre-conditions (indicative list of requirements):

1) The link is direct and leads to the specific SDS for the chemical supplied 2) The link is reliable and functioning, and should remain active continuously and, preferably, permanently 3) If permanent activity cannot be ensured, supplier should warn the customer about temporary accessibility and its duration to allow the customer to download the SDS 4) Updates to the link (e.g. due to changes in the website) should be actively sent to the customer 5) Updates to the SDS itself must also be actively communicated to the customer 6) There should be no hindrance in accessing the SDS when using the link – e.g., no login or registration can be required.

Once an SDS has been supplied for a first delivery of a substance or mixture to a particular recipient, there is no need to supply a further copy of the SDS with subsequent deliveries to the same recipient unless the SDS is revised. Further information on communication of changes resulting from revisions is given in chapter 2.9 above.

2.14 Language(s) in which the SDS must be provided

According to REACH Article 31(5), “The safety data sheet shall be supplied in an official language of the Member State(s) where the substance or mixture is placed on the market, unless the Member State(s) concerned provide otherwise”. It should be noted that it is for the recipient Member State (MS) to provide otherwise – i.e. for example the existence of an exemption in the MS of manufacture does not give an exemption in a different MS where the substance or mixture is placed on the market. Even if the MS provides otherwise, it may be desirable to always provide (potentially in addition) the SDS in the language of the country.

It should be noted that certain Member States require that the SDS be provided in additional official MS languages (of that MS, where there is more than one official language)17.

It should also be noted that as the annexed exposure scenario is considered to be an integral part of the SDS it is subject to the same translation requirements as the SDS itself – i.e. it must be supplied in an official language of the Member State(s) where the substance or mixture is placed on the market, unless the recipient Member State(s) concerned provide

17 ECHA has published the table “Languages required for labels and safety data sheets”, and it is available at: http://echa.europa.eu/safety-data-sheets


<a id="echa-ch2-page-22"></a>
**ECHA printed page 22** — [original PDF page 22](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=22)

otherwise.

It is important to highlight that in Section 2 of the SDS, either the full wording of the hazard classification and of the hazard statements or the “Hazard Class and Category Code(s)” (listed in Table 1.1 of Annex VI to CLP and appearing in Table 3 of Annex VI to CLP) and hazard statement codes18 may be used. If the full wording is used, it needs to be in the language of the SDS. If the Hazard Class and Category code(s) are used, the abbreviations given for each hazard class must not be translated (these are language-independent codes based on [abbreviated] English words, but not “English-language text”). The codes must thus remain as these are given in Annex VI to CLP. If codes, other abbreviations or acronyms are used, their full text and explanation must be given in Section 16 of the SDS, in the language of the SDS.

For example, for a flammable substance, if the Hazard Class and Category Code “Flam.Liq.1, H224” (corresponding to Flammable liquid, Category 1) is used, this must not be translated. The full text corresponding to that code, however, has to be given in the language of the SDS, in Section 16. If, however, the classification, including the hazard statements, is written out in full, then further explanation in Section 16 is not required.

It should be further noted that according to the provisions of Article 17 (4) of the Prior Informed Consent (PIC) Regulation19, for substances for which an SDS is required (in the format of Annex II to REACH) according to Article 17 (3) of the same regulation: “The information on the label and on the safety data sheet shall as far as practicable be given in the official languages, or in one or more of the principal languages, of the country of destination or of the area of intended use” i.e. in such cases the language(s) in which the SDS is to be supplied may include (where practicable) languages which are not official languages of any EU Member State.

2.15 Substances and mixtures for which an SDS must be provided without prior request

According to Article 31 (1) of REACH (as amended by Article 59(2)(a) of CLP), the criteria for when an SDS must be provided (even without request) are:

“(a) where a substance or mixture meets the criteria for classification as hazardous in accordance with Regulation (EC) No 1272/2008; or

(b) where a substance is persistent, bioaccumulative and toxic or very persistent and very bioaccumulative in accordance with the criteria set out in Annex XIII; or

(c) where a substance is included in the list established in accordance with Article 59(1) for reasons other than those referred to in points (a) and (b).” (where the latter list corresponds to the so called “candidate list”20 for authorisation (list published on ECHA website, see link in the footnote).

2.16 Certain mixtures for which an SDS must be provided on request

Article 31(3) of REACH (as amended by Article 59(2)(b) of CLP) specifies the conditions under which an SDS must be supplied on request (for certain mixtures). The text specifying these

18 It is important to underline that in CLP different types of codes are used. Thus, “Hazard Class and Category Codes” (e.g. ‘Acute Tox.4’) should not be confused with “Hazard statement codes” (e.g. H312). 19 Regulation (EU) No 649/2012 of the European Parliament and of the Council of 4 July 2012 concerning the export and import of hazardous chemicals (recast); OJ L 201 27.07.2012 p 60. Available at https://eur- lex.europa.eu/legal-content/EN/ALL/?uri=CELEX%3A32012R0649  20 https://echa.europa.eu/candidate-list-table


<a id="echa-ch2-page-23"></a>
**ECHA printed page 23** — [original PDF page 23](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=23)

conditions is the following:

“3. The supplier shall provide the recipient at his request with a safety data sheet compiled in accordance with Annex II, where a mixture does not meet the criteria for classification as hazardous in accordance with Titles I and II of Regulation (EC) No 1272/2008, but contains:

(a) in an individual concentration of ≥ 1 % by weight for non-gaseous mixtures and ≥ 0,2 % by volume for gaseous mixtures at least one substance posing human health or environmental hazards; or

(b) in an individual concentration of ≥ 0,1 % by weight for non-gaseous mixtures at least one substance that is carcinogenic category 2 or toxic to reproduction category 1A, 1B and 2, skin sensitiser category 1, respiratory sensitiser category 1, or has effects on or via lactation or is persistent, bioaccumulative and toxic (PBT) in accordance with the criteria set out in Annex XIII or very persistent and very bioaccumulative (vPvB) in accordance with the criteria set out in Annex XIII or has been included for reasons other than those referred to in point (a) in the list established in accordance with Article 59(1); or

(c) a substance for which there are Community workplace exposure limits.”

It is important to note that the obligation triggered by point (c) is not dependent on the concentration of the substance in the mixture. The obligation to supply an SDS on request applies to a mixture containing a substance for which there is an EU-level workplace exposure limit21, present at any concentration. It is recommended to always indicate in the SDS for the mixture which substance triggers the requirement (even if the substance only needs to be stated and its precise concentration indicated if it is present in a concentration equal or greater than the threshold indicated in point 3.2.2 of Annex II, see chapter 3.2).

On the obligation triggered by point (b), suppliers will need to provide, upon request, a safety data sheet for a non-classified mixture that contains certain hazardous substances in concentrations above or equal to the specified value but will not be obliged to indicate the substances present nor the concentrations in which they are present if no limits are specified in subsection 3.2.2. of Annex II to REACH or if any specified limits are not reached.

The obligation to provide an SDS on request is also laid down in the CLP Regulation. According to Note 1 in tables 3.4.6, 3.6.2, 3.7.2, 3.8.3 and 3.9.4 of Annex I to the CLP Regulation, this requirement applies to mixtures not classified but containing at least one substance classified as skin sensitiser category 1, sub-category 1A or 1B, respiratory sensitiser category 1, sub-category 1A or 1B, carcinogenic category 2, reproductive toxicant category 1 or 2 or for effects on/via lactation and specific target organ toxicant category 2 (single or repeated exposure) above the threshold defined in the Notes to the same tables.

2.17 Labelling required for a mixture not classified as hazardous and not intended for the general public for which an SDS must be available and supplied on request

For mixtures not classified as hazardous under CLP and not intended for the general public but which contain certain specified classified components at and above specified limits, for which an SDS must be provided on request, the label on the packaging must bear information indicating the availability of such SDSs.

The text required to indicate the availability of an SDS is the statement EUH210: “Safety data sheet available on request”.

The concentration limits specified in CLP Annex II, point 2.10, are the following:

For mixtures not classified as hazardous but which contain:

21 https://osha.europa.eu/en/legislation/directive/directive20191831-indicative-occupational-exposure-limit-values


<a id="echa-ch2-page-24"></a>
**ECHA printed page 24** — [original PDF page 24](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=24)

≥ 0,1 % of a substance classified as skin sensitiser category 1, 1B, respiratory sensitiser category 1, 1B, or carcinogenic category 2, or

≥ 0,01 % of a substance classified as skin sensitiser category 1A, respiratory sensitiser category 1A, or

≥ one tenth of the specific concentration limit for a substance classified as skin sensitiser or respiratory sensitiser with specific concentration limit lower than 0,1 %, or

≥ 0,1  % of a substance classified as toxic to reproduction categories 1A, 1B or 2, or with effects on or via lactation; or

at least one substance in an individual concentration of ≥ 1 % by weight for non-gaseous mixtures and ≥ 0,2  % by volume for gaseous mixtures either:

classified with other health or environmental hazards; or

for which there are Community workplace exposure limits

2.18 SDSs for hazardous substances and mixtures made available to the general public

Article 31 (4) of REACH states for substances and mixtures sold to the general public:

“The safety data sheet need not be supplied where hazardous substances or mixtures offered or sold to the general public are provided with sufficient information to enable users to take the necessary measures as regards the protection of human health, safety and the environment, unless requested by a downstream user or distributor.”

Thus, it is not mandatory for a safety data sheet to be supplied for a hazardous substance or mixture made available to the general public22 if the above conditions are complied with. However, if the product is also supplied to a downstream user or distributor and he requests an SDS, it must be supplied to him. It may be recommendable for the distributor (e.g. retailer) offering or selling these substances or mixtures to be in possession of an SDS for each hazardous substance or mixture which he sells. These SDSs also contain important information for him as he has to store the substance or mixture and can give important information e.g. on measures in case of an accident (or fire etc.). If the downstream user or distributor feels that he needs an SDS for these or other purposes he can request one.

It should be noted that the actor who is specifically allowed to request the SDS by this provision is the downstream user or distributor – it is not the member of the public (“consumer”). The question of whether a particular customer for such a substance or mixture is entitled to request and receive an SDS for it can therefore be addressed on the basis of whether he qualifies as either a ‘downstream user’ or a ‘distributor’ under the definitions given in Article 3 (13) and 3 (14) of the REACH regulation respectively. A “consumer” is specifically excluded from the definition of a downstream user. Whether a recipient qualifies as a downstream user with respect to use of the substance or mixture “in the course of his industrial or professional activities” may be determined for example on the basis of his professional background. A reliable proof of the right to request an SDS could be an excerpt from the trade register/register of companies or other professional accreditation or potentially

22 There are no provisions in REACH under which an SDS ever has to be supplied to a member of the general public (a “consumer”); there is also no provision to stop this being done on a voluntary basis by any actor in the supply chain.


<a id="echa-ch2-page-25"></a>
**ECHA printed page 25** — [original PDF page 25](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=25)

a VAT number (or holding of an account with the supplier), rather than depending solely on quantities (which itself may serve as a first indicator).

2.19 Access to information in the SDS by workers

According to Article 35 of REACH:

“Workers and their representatives shall be granted access by their employer to the information provided in accordance with Articles 31 and 32 in relation to substances or mixtures that they use or may be exposed to in the course of their work.”

The SDS (in the EU) is aimed at the employer and the self-employed. The employer has a responsibility to transform the information into suitable formats to manage risks at the specific workplace. Nonetheless access must be given to relevant SDS information to workers and their representatives according to Article 35 of REACH (as well as according to Article 8 of Directive 98/24/EC).

2.20 Products for which an SDS is not required

The requirements to provide an SDS arise from Article 31 of the REACH Regulation.

Certain general exemptions from the need to supply information according to Title IV (therefore including SDSs according to Article 31) are given in Article 2 (6):

“The provisions of Title IV shall not apply to the following mixtures in the finished state, intended for the final user:

(a) medicinal products for human or veterinary use, within the scope of Regulation (EC) No 726/2004 and Directive 2001/82/EC and as defined in Directive 2001/83/EC;

(b) cosmetic products as defined in Directive 76/768/EEC;

(c) medical devices which are invasive or used in direct physical contact with the human body in so far as Community measures lay down provisions for the classification and labelling of dangerous substances and mixtures which ensure the same level of information provision and protection as Directive 1999/45/EC;

(d) food or feedingstuffs in accordance with Regulation (EC) No 178/2002 including use:

(i) as a food additive in foodstuffs within the scope of Directive 89/107/EEC;

(ii) as a flavouring in foodstuffs within the scope of Directive 88/388/EEC and Decision 1999/217/EC;

(iii) as an additive in feedingstuffs within the scope of Regulation (EC) No 1831/2003;

(iv) in animal nutrition within the scope of Directive 82/471/EEC.”

Even more general exemptions from the whole of the REACH apply to other classes of products via Article 2(1) (radioactive substances, substances under customs supervision, non-isolated intermediates, products during carriage by rail, road, inland waterway, sea or air).

Waste as defined in Directive 2008/98/EC 23 is also exempted in general by virtue of being excluded by Article 2(2) from being defined as a substance, mixture or article within the meaning of Article 3 of the REACH Regulation.

SDSs are also of course not required for products that do not conform either to the criteria

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   23 Directive 2006/12/EC - repealed by Directive 2008/98/EC of the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (Waste Framework Directive).


<a id="echa-ch2-page-26"></a>
**ECHA printed page 26** — [original PDF page 26](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=26)

given in Article 31(1) (a), (b) and (c) or to those in Article 31(3) for when SDSs are required (see Section 1.1 of the General Introduction above and the text of REACH for more detail on what the criteria are).

2.21 Possible compilation of an SDS for substances and mixtures even when not legally required

From marketing and/or logistical aspects it may in certain cases be useful for suppliers to have SDS available for all substances and mixtures, including those for which there is no legal obligation to provide an SDS. In such cases, it may be desirable to indicate in the document that the substance or mixture does not legally require an SDS to avoid unnecessary compliance and conformity issues arising. It is not generally desirable to compile SDSs for articles.

It may also be useful to supply information required according to Article 32 of REACH concerning the duty to communicate information down the supply chain for substances on their own or in mixtures for which a SDS is not required in the SDS format. However, it should be noted that this is not required by the REACH Regulation, and again in these cases it may be desirable to indicate in the document that the substance or mixture does not legally require an SDS, to avoid unnecessary compliance and conformity issues arising. Similarly, it may be specifically indicated when such a document is being used to communicate information according to Article 32.

2.22 When attachment of Exposure Scenarios to the SDS is required

According to the first paragraph of Article 31(7) of REACH:

“Any actor in the supply chain who is required to prepare a chemical safety report according to Articles 14 or 37 shall place the relevant exposure scenarios (including use and exposure categories where appropriate) in an annex to the safety data sheet covering identified uses and including specific conditions resulting from the application of Section 3 of Annex XI.”

Thus, whenever there is a requirement for an actor (e.g. a registrant or a downstream user preparing a CSR according to Articles 14 or 37(4) of REACH) to include exposure scenarios in their CSR, the actor has an obligation to place the relevant exposure scenarios in an Annex to the SDS. It should be noted however that not all registrants who are required to carry out a CSA and prepare a CSR24 are necessarily required to prepare an exposure scenario. Thus, for example, although a CSA and a CSR are generally required for all substances subject to registration in quantities of 10 tonnes or more, an exposure scenario is only required for those for which the further criteria given in Article 14 (4) also apply (i.e. those fulfilling the PBT/vPvB criteria or the criteria for any of the listed hazard classes in Article 14(4) of REACH as amended by Article 58 of CLP). These criteria are25:

24 Note that  there are cases where no CSA/CSR is needed at all (and thereby no ESs are to be provided), for instance in the case of substances exempted from registration under annex IV or V or for recovered substances exempted from presenting a registration dossier under art 2(7) (d).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 25 The hazard classes or categories corresponding to the listing (where not already named in full in the text above) are: (a) explosives (2.1), flammable gases (2.2), aerosols (2.3), oxidising gases (2.4), flammable liquids (2.6), flammable solids (2.7), self-reactive substances and mixtures types A and B (2.8 A + B), pyrophoric liquids (2.9), pyrophoric solids (2.10), substances and mixtures which in contact with water emit flammable gases (2.12), oxidising liquids categories 1 and 2 (2.13  1 + 2), oxidising solids categories 1 and 2 (2.14 1 + 2), organic peroxides types A to


<a id="echa-ch2-page-27"></a>
**ECHA printed page 27** — [original PDF page 27](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=27)

“4. If, as a result of carrying out steps (a) to (d) of paragraph 3, the registrant concludes that the substance fulfils the criteria for any of the following hazard classes or categories set out in Annex I to Regulation (EC) No 1272/2008:

(a) hazard classes 2.1 to 2.4, 2.6 and 2.7, 2.8 types A and B, 2.9, 2.10, 2.12, 2.13 categories 1 and 2, 2.14 categories 1 and 2, 2.15 types A to F;

(b) hazard classes 3.1 to 3.6, 3.7 adverse effects on sexual function and fertility or on development, 3.8 effects other than narcotic effects, 3.9 and 3.10;

(c) hazard class 4.1;

(d) hazard class 5.1

or is assessed to be a PBT or vPvB, … …”

Hence, if the substance does not fulfil any of the criteria of Article 14(4) (hazard classes, categories or properties) an exposure assessment is not needed and the registrant can directly document the hazard assessment and PBT/vPvB assessment in the chemical safety report without the need to generate an exposure scenario. Furthermore, the CSA and CSR would normally be carried out as part of the preparations for a registration. Exposure scenarios for particular substances on their own or in mixtures will therefore normally only be attached to SDSs after the respective substance has been registered.

Articles 60(7), 62(4)(d) and sections 0.7, 5.1.1 and 5.1.2 of Annex I of REACH, describe chemical safety report and exposure scenario related obligations. These aspects form an integral part of the application for authorisation process. Granted authorisations based on either Article 60(2) or Article 60(4) include consideration of the risk management measures proposed in the exposure scenarios of the authorisation chemical safety report.

Once prepared, the exposure scenario should be attached to SDS, and its attachment would then constitute a revision to the SDS. Where the exposure scenario results in new risk management measures, the SDS must be updated without delay and the revised version provided to former recipients who have received the substance or mixture within the preceding 12 months, in accordance with the provisions of Article 31(9)(a)  of REACH (see also chapter 2.8 above).

2.23 Alternative ways to include26 the Exposure Scenario information into the SDS for substance and mixtures

For the cases described in 2.21 above, Article 31(7) of REACH specifies that the exposure scenario must be placed in an annex to the SDS.

However, the second and third subparagraphs of Article 31(7) further state that:

“Any downstream user shall include relevant exposure scenarios, and use other relevant information, from the safety data sheet supplied to him when compiling his own safety data sheet for identified uses.

Any distributor shall pass on relevant exposure scenarios, and use other relevant information, from the safety data sheet supplied to him when compiling his own safety data sheet for uses for which he

F (2.15 A to F inclusive); (b) acute toxicity (3.1), skin corrosion/irritation (3.2), serious eye damage/eye irritation (3.3) respiratory or skin sensitisation (3.4), germ cell mutagenicity (3.5), carcinogenicity (3.6), [3,7, 3.8 as above], specific target organ toxicity – repeated exposure (3.9), aspiration hazard (3.10); (c) hazardous to the aquatic environment (4.1); (d) hazardous to the ozone layer (5.1).

26 “Include” is used here to mean either attach the exposure scenario (s) as a whole to the SDS (as an annex) and/or integrate information from the exposure scenario into the main body (Sections 1 to 16 inclusive) of the SDS and/or append to the SDS safe use information for the mixture.


<a id="echa-ch2-page-28"></a>
**ECHA printed page 28** — [original PDF page 28](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=28)

has passed on information according to Article 37(2).”

For downstream users who are not required to carry out their own CSA for a particular

(component) substance27 there are therefore alternative options for inclusion of the exposure

scenario information28.

In the case of a mixture containing substances for which an exposure scenario was required, the inclusion of exposure scenario information in the SDS for the mixture must take into account at least those substances present above the thresholds given in Article 14 of REACH.

The result is the following possible cases for inclusion of exposure scenario(s) information (carried out by a manufacturer/importer or by a downstream user) into SDSs:

1. attachment of the actual exposure scenario (s) resulting from a CSA for a substance as such or exposure scenario resulting from the CSA for a substance in a mixture in concentrations above the thresholds given in Article 14. In this case, at least a summary of the relevant key information from the attached exposure scenario must be included into the core sections of the SDS, with a cross-reference to the details in the exposure scenario;

2. integration of exposure scenario information for a substance or resulting from consolidation of various exposure scenarios for substances used in a mixture into the core Sections 1-16 of the SDS;

3. attachment of exposure scenario resulting from the CSA for a special mixture29;

4. (potentially) attachment of exposure scenario resulting from a CSA for a mixture under Article 31(2) of REACH30.

5. append safe use information for the mixture derived from the exposure scenarios of the component substances.

It should be noted that for a component of a mixture for which the downstream user is required to carry out a CSA option 2 above is not available.

It should further be noted that although all of the options above are allowed under the specified conditions, these may not all be equally suitable in practice as a means of forwarding the relevant information – for example further downstream users may prefer to receive forwarded exposure scenarios for component substances in the mixtures that they receive rather than consolidated documentation. In this way, when they then formulate these mixtures into further mixtures the component substances can be reconsidered together with the new components. Option 2 may be more appropriate e.g. when supplying professional end-users. Likewise, it is strongly recommended to use option 2 if the attachment of exposure scenarios for component substances in mixtures would otherwise lead to SDSs of such inordinate length that their recipients further down the supply chain would no longer be able to cope with the

27 These alternative options are only available to such downstream users.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 28 The change in wording from “shall place” in the first paragraph of Article 31(7) with respect to those required both to carry out a CSA/CSR and prepare an exposure scenario to “shall include relevant exposure scenarios” in the second paragraph with respect to downstream users is significant. The latter wording is to be interpreted as allowing (if the SDS compiler so chooses) “inclusion” of the relevant information from received exposure scenarios by methods other than attachment as an Annex to the SDS.

29 See Appendix 2 for more information on “special mixtures”.

30 At present there is no guidance available on how to carry out such a CSA. Such a CSA for a mixture is foreseen by Article 31(2) of REACH for the purposes of generating consolidated information for an SDS.  Neither Article 14 nor Article 37 of REACH generate a requirement for such a CSA to be prepared as part of a registration.


<a id="echa-ch2-page-29"></a>
**ECHA printed page 29** — [original PDF page 29](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=29)

amount of information contained within them.

The actor compiling the SDS should keep in mind that recommendations from exposure scenarios give rise to specific obligations upon downstream users (Article 37(4)). In order for downstream users to be able to recognise such obligations (such as RMMs to be implemented), it is recommended that information originating from exposure scenario(s) – either incorporated in the body of the SDS or appended to the SDS - is indicated as such.

Appendix 1 provides more guidance to downstream users who need to “include” the exposure scenario information for a substance into a SDS.

Detailed guidance on options for downstream users on how to forward downstream information received from supplier(s) on the substance(s) as such or in a mixture(s) is provided in the Guidance for Downstream users31.

Furthermore, a specific network has been established by ECHA and some sector organisations with the aim to develop and provide methodologies and tools to improve effective communication along the supply chain. More information is available on the ENES page of the ECHA website32.

Appendix 1 to this guidance and, in more detail, Appendix 1 to the Guidance for downstream users, provide more information on the roles and obligations of distributors. They play an important role in the communication flow up and down the supply chain.

2.24 Forms of assistance available in the compilation of SDSs

Suppliers may use an external service provider to access the services of competent persons for the compilation of SDSs, but of course it is still the supplier’s responsibility to provide SDSs that comply with the legal requirements.

Parties compiling and issuing SDSs may be supported by relevant software applications. These applications generally have a database function. These databases contain substance lists and libraries of standard phrases. Many software products include options for generating SDSs in several languages. Such software products may also support the management and consistency of information between the registration dossier (including the CSR) and the SDS.

An example of a source of standard phrases is the European Phrase Catalogue, which is available (at no charge) in German and English via https://www.esdscom.eu/english/euphrac- phrases/. Other service providers also offer libraries of standard phrases. The correct use of standard phrases can help to improve quality and comprehensibility, however care should be taken when using these phrases, as the content may not always be sufficiently clear. Software products do not release the supplier from his obligation to have the safety data sheet prepared by a competent person.

Some industry or trade associations offer support (e.g. via their internet homepages) with information regarding their specific sector.

31 Available at:  https://echa.europa.eu/guidance-documents/guidance-on-reach

32 Exchange Network on Exposure Scenarios, see: https://echa.europa.eu/about-us/exchange-network-on-exposure- scenarios


<a id="echa-ch2-page-30"></a>
**ECHA printed page 30** — [original PDF page 30](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=30)

2.25 Selected sources of substance data useful for the compilation of SDSs

A large part of the information necessary in order to compile the SDS should already be available to the supplier, as it will have been necessary to gather it for the purposes of other chemicals control legislation, notably in order to determine e.g. the classification, labelling and packaging requirements according to CLP and according to international transport legislation, and to comply with occupational health and safety legislation.

If the substance is subject to Registration under REACH and the supplier is a member of joint submission or a consortium33, if one exists for that substance, he may have shared access to additional information on the substance.

For downstream users of substances (and all formulators of mixtures), the key source of information is that provided by the supplier in the SDS for the specific (component) substance(s) or mixture(s).

Where it becomes apparent during compilation of the SDS that some data are not readily available to the compiler, there are also publicly available databases with relevant information. These may be consulted either to seek data that is not otherwise available or to check data provided from upstream, which seems inconsistent or implausible, for example:

The ECHA database on registered substances: (https://echa.europa.eu/information-on-chemicals/registered-substances)

This gives a variety of information on the substances which companies manufacture or import: their hazardous properties, their classification and labelling and how to use the substances safely, for example. Information in the database is that provided by companies in their registration dossiers.

The ECHA classification and labelling inventory: (https://echa.europa.eu/information-on-chemicals/cl-inventory-database)

The Classification & Labelling (C&L) Inventory is a database that will contain basic classification and labelling information on notified and registered substances received from manufacturers and importers. It will also contain the list of harmonised classifications (Table 3 of Annex VI to CLP). The Inventory will be established and maintained by ECHA.

GESTIS (http://gestis-en.itrust.de)

This database of the German Berufsgenossenschaften includes more than 7,000 hazardous substances alphabetically by name, with classification, labelling, limit values, measuring methods, information on personal protection equipment, workplace limit values and occupational medicine.

eChemPortal (http://www.echemportal.org/echemportal/)

The eChemPortal is an effort of the Organisation for Economic Co-operation and Development (OECD) in collaboration with the European Commission (EC), the European Chemicals Agency (ECHA), the United States, Canada, Japan, the International Council of Chemical Associations (ICCA), the Business and Industry Advisory Committee (BIAC), the World Health Organization's (WHO) International Program on Chemical Safety (IPCS), the United Nations Environment Programme (UNEP) and environmental non-governmental organisations. eChemPortal provides free public access to

33 Note that participation in a consortium is not mandatory.


<a id="echa-ch2-page-31"></a>
**ECHA printed page 31** — [original PDF page 31](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=31)

information on properties of chemicals (including physical and chemical properties, environmental fate and behaviour, ecotoxicity and toxicity) via simultaneous searching of reports and datasets.

IPCS INCHEM (http://www.inchem.org/)

The International Programme on Chemical Safety (IPCS) INCHEM website gives Rapid access to internationally peer reviewed information on chemicals commonly used throughout the world, which may also occur as contaminants in the environment and food. It consolidates information from a number of intergovernmental organizations whose goal it is to assist in the sound management of chemicals.

TOXNET (http://toxnet.nlm.nih.gov/index.html)

Toxnet is the United States of America’s National Library of Medicine’s toxicology data network. It gives access to databases on toxicology, hazardous chemicals, environmental health, and toxic releases.

Attention should be paid to the potential variation in reliability of information from such sources.

It should be noted that in all cases (including when the information on component substances has been obtained from SDSs of suppliers of these substances – see chapter 2 paragraph 2.2 above) it is the supplier of the SDS that retains responsibility for the accuracy of its content.

2.26 How to compile an SDS for a recovered substance or mixtures containing such a substance

Appendix 3 of this document discusses specific issues relevant to the compilation of SDSs for recovered substances and mixtures. The ECHA Guidance on waste and recovered substances34 contains additional information on issues that are specific to SDSs for recovered substances.

2.27 Testing for the purposes of generation of information for an SDS

The SDS is designed to provide comprehensive information about a substance or mixture for use in workplace chemical control regulatory frameworks (see paragraph 2.1 above). It consolidates this information into one document. The information required to be given in an SDS should either be available (because it is needed, for example, as part of the data set required for a registration under REACH or for classification purposes) or a reason for it not being available should be given in the appropriate subsection of the SDS.

The process of compilation of the SDS may of course reveal that data which is required (for example to correctly classify under CLP) is unavailable.

In such cases, before any testing is initiated, the applicable “driver” legislation for compliance with which data are missing and additional testing is proposed should be consulted. Testing should not be initiated on the basis of a need to “fill-in empty fields” in an SDS.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   34 The Guidance on waste and recovered substances is available at: echa.europa.eu/guidance-documents/guidance- on-reach.


<a id="echa-ch2-page-32"></a>
**ECHA printed page 32** — [original PDF page 32](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=32)

In particular reference should be made to Title III of the REACH Regulation on Data Sharing and Avoidance of Unnecessary Testing and to Articles 7 and 8 of the CLP Regulation on Animal and human testing and Generating new information for substances and mixtures, respectively.

In particular, no animal testing should be initiated solely for the purposes of generating content for an SDS. The provisions of Council Directive 86/609/EEC35and 2010/63/EU36 of the EP and Council must be complied with. There is also no requirement arising directly from Annex II to REACH to generate non-animal test data (including that for physical hazards) solely for the purpose of completing fields of an SDS.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   35 Council Directive 86/609/EEC of 24 November 1986 on the approximation of laws, regulations and administrative provisions of the Member States regarding the protection of animals used for experimental and other scientific purposes, (OJ L358, 18.12.1986 p.1).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 36 Directive 2010/63/EU of the European Parliament and of the Council of 22 September 2010 on the protection of animals used for scientific purposes (OJ L276, 20.10.2010 p33).


---

<a id="ch3intro"></a>


# 3. Detailed information — overview

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-ch3intro-page-33"></a>
**ECHA printed page 33** — [original PDF page 33](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=33)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 33](page_images/ECHA_2020_page_033.jpg)

3 Detailed information, section by section

In this chapter of this guidance a quotation of the text relating to the relevant subsection in Part A of Annex II is given before it is further discussed.

It should be noted that although there may be text in Annex II, which precedes the subsections, discussing the content of certain sections as a whole, there is no requirement to insert that text in the actual SDS except in the subsections. However, the title of the sections must be quoted as listed in the regulation – i.e. including the section number as explained above. Thus, for example, the correct heading for Section 10 of an SDS is “SECTION 10: Stability and reactivity”, i.e. including the words “SECTION 10”.

It should further be noted that although the full text of Annex II concerning specific sections and subsections is quoted in full below, other parts of Annex II (e.g. the introductory paragraphs to Part A, all of Part B) are not quoted in full below and neither is the full text of the rest of Commission Regulations (EU) 2015/830 and (EU) 2020/878.

There may be places in the SDS where information will not be completed because of e.g. a data gap, or application can be questioned, etc. However, the SDS must contain an explanation or a justification of why the section has not been completed.


---

<a id="s1"></a>


# 3.1 SDS SECTION 1 — Identification of the substance/mixture and of the company/undertaking

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s1-page-33"></a>
**ECHA printed page 33** — [original PDF page 33](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=33)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 33](page_images/ECHA_2020_page_033.jpg)

3.1 SDS SECTION 1: Identification of the substance/mixture and of the company/undertaking

Text Annex II

This section of the safety data sheet shall prescribe how the substance or mixture shall be identified and how the identified relevant uses, the name of the supplier of the substance or mixture and the contact detail information of the supplier of the substance or mixture, including an emergency contact, shall be provided in the safety data sheet.

<a id="echa-sds-1-1"></a>
### 1.1 Product identifier

Text Annex II

The product identifier shall be provided in accordance with Article 18(2) of Regulation (EC) No 1272/2008 in the case of a substance and in accordance with Article 18(3)(a) of Regulation (EC) No 1272/2008 in the case of a mixture, and as provided on the label in the official language(s) of the Member State(s) where the substance or mixture is placed on the market, unless the Member State(s) concerned provide(s) otherwise.

For substances subject to registration, the product identifier shall be consistent with that provided in the registration and the registration number assigned under Article 20(3) of this Regulation shall also be indicated. Additional identifiers may be provided even if they have not been used in the registration.

Without affecting the obligations of downstream users laid down in Article 39 of this Regulation, the part of the registration number referring to the individual registrant of a joint submission may be omitted by a supplier who is a distributor or a downstream user provided that:

(a) this supplier assumes the responsibility to provide the full registration number upon request for enforcement purposes or, if the full registration number is not available to him, to forward the


<a id="echa-s1-page-34"></a>
**ECHA printed page 34** — [original PDF page 34](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=34)

request to his supplier, in line with point (b); and

(b) this supplier provides the full registration number to the Member State authority responsible for enforcement (the enforcement authority) within 7 days upon request, received either directly from the enforcement authority or forwarded by his recipient, or, if the full registration number is not available to him, this supplier shall forward the request to his supplier within 7 days upon request and at the same time inform the enforcement authority thereof.

A single safety data sheet may be provided to cover more than one substance or mixture where the information in that safety data sheet fulfils the requirements of this Annex for each of those substances or mixtures.

Where different forms of a substance are covered by one safety data sheet, relevant information shall be included, clearly indicating which information is related to which form. Alternatively, a separate safety data sheet may be prepared per form or group of forms.

If the safety data sheet pertains to one or more nanoforms, or substances that include nanoforms, this shall be indicated by using the word ‘nanoform’.

Other means of identification

Other names or synonyms by which the substance or mixture is labelled or commonly known, such as alternative names, numbers, company product codes, or other unique identifiers may be provided.

Where a mixture has a Unique Formula Identifier (UFI) in accordance with section 5 of Part A of Annex VIII to Regulation (EC) No 1272/2008 and that UFI is indicated in the safety data sheet, then the UFI shall be provided in this subsection.

For substances, the product identifier requirements according to the CLP Regulation Article 18(2) are:

“The product identifier for a substance shall consist of at least the following:

(a) if the substance is included in Part 3 of Annex VI, a name and an identification number as given therein;

(b) if the substance is not included in Part 3 of Annex VI, but appears in the classification and labelling inventory, a name and an identification number as given therein;

(c) if the substance is not included in Part 3 of Annex VI nor in the classification and labelling inventory, the number provided by the CAS (hereinafter referred to as ‘the CAS number’), together with the name set out in the nomenclature provided by the IUPAC (hereinafter referred to as ‘the IUPAC Nomenclature’), or the CAS number together with another international chemical name(s); or

(d) if the CAS number is not available, the name set out in the IUPAC Nomenclature or another international chemical name(s).

Where the name in the IUPAC nomenclature exceeds 100 characters, one of the other names (usual name, trade name, abbreviation) referred to in section 2.1.2 of Annex VI to REACH may be used provided that the notification in accordance with Article 40 of CLP includes both the name set out in the IUPAC Nomenclature and the other name used.”

The identification numbers should be given according to the hierarchy given above (i.e. (a) before (b), before (c)). However no further indication is given of which of the identification numbers allowed is to be used when choosing within the 3 (a) and (b) options. For instance, if option (b) applies, any of the identification numbers given within the classification and labelling inventory can be used, as long as in all cases the number quoted matches the identification number used on the label and is consistent with the identifier provided in the registration, if applicable.

Thus, for example, whereas for beryllium compounds covered by index number 004-002-00-2 in part 3 of Annex VI of CLP, the index number itself would be used as the identifier according to (a) (since there is no EC number or CAS number “given therein” for this entry), in the specific case of beryllium oxide (index number 004-003-00-8) either this index number or the EC number (215-133-1) or the CAS number (1304-56-9) could be used as long as the same


<a id="echa-s1-page-35"></a>
**ECHA printed page 35** — [original PDF page 35](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=35)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 35](page_images/ECHA_2020_page_035.jpg)

identification number appears on the label.

In the case where scenario (b) applies it should be noted that again “an identification number” as given therein refers to any of the allowed identifiers which are included in the notification to the inventory. In particular it should be noted that in practice it is unlikely to be convenient to choose the reference number attributed during (or as a result of) the process of a CLP notification as this will be unavailable in advance of its assignment. Choice of an alternative identifier such as (where applicable) EC number or CAS number that will also be included as identifiers in the CLP notification may be advisable in order to minimise the need for revision of the SDS.

It should further be noted that when a name from Annex VI is used it is subject to the same translation requirements as apply to the rest of an SDS37.

If no registration number is given, an explanation as to why this is the case may be added to avoid questioning of the reason for its absence, for example:

“No registration number is given for this substance since it is exempted from the registration requirements according to REACH Title II and also exempted from titles V and VI as it is a recovered substance and fulfils the criteria of Article 2(7)(d) of REACH.”

“This substance is exempted from Registration according to the provisions of Article 2(7)(a) and Annex IV of REACH.

However such an explanation is not mandatory.

In the case of re-imported substances, it is recommended that the full registration number of the European registrant of the substance, from whom the re-imported substance was obtained, is indicated here, along with an explanation.

An example of how the structure of this section may look for a substance is given below.

SECTION 1: Identification of the substance/mixture and of the company/undertaking

1.1 Product identifier:

Substance name:

EC No.:

CAS No.:

Index No.:

REACH Registration No.: XX-XXXXXXXXXX-XX-XXXX

Regarding nanoforms, the revised Annex VI of REACH introduces the concepts of “nanoform” and “sets of nanoforms”. A “set of similar nanoforms” can be created, when it is possible to conclude that the hazard assessment, exposure assessment and risk assessment of these

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   37 The translations of the names of the harmonised substances are included in the C&L Inventory on the ECHA website at: http://echa.europa.eu/regulations/clp/cl-inventory.


<a id="echa-s1-page-36"></a>
**ECHA printed page 36** — [original PDF page 36](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=36)

nanoforms (with clearly defined boundaries in the Annex VI parameters) can be performed jointly for all endpoints. The Appendix for nanoforms to the Guidance on Registration and the Guidance on substance identification explains how to create sets of different nanoforms.

According to Annex VI “The term “nanoform”, when it is referred to in the other Annexes, shall refer to a nanoform or a set of similar nanoforms, when one has been defined, as defined in this Annex”. Consequently, in this guidance the term nanoform can refer to an individual nanoform or to a set of nanoforms (e.g. as they have been registered following Annex VI).

For mixtures, the product identifier requirements according to Article 18(3)(a) of CLP are:

“3. The product identifier for a mixture shall consist of both of the following:

(a) the trade name or the designation of the mixture; … … …”

(For further requirements concerning information on the components of mixtures, including requirements for registration numbers see the discussion of Section 3 of the SDS below.)

Annex VIII to CLP has introduced an additional element which facilitates the identification of the product and the mixture contained in it, the Unique Formula Identifier (UFI). This is part of the information to be submitted according to Article 45 and Annex VIII to CLP for emergency response reasons. Generation of UFI and submission of information is mandatory for mixtures classified for physical and/or health hazards and placed on the EU market. The UFI code allows a unique link to the information on the mixture submitted by the company and eventually available to emergency responders. A UFI normally corresponds to one mixture composition only, however, a single UFI can also cover mixtures whose compositions vary within certain limits. This can be the case when components are notified as part of Interchangeable Composition Group (ICG) or the mixture conforms to specific Standard Formulas listed in Annex VIII to CLP.

The UFI is normally to be included on the label38. The inclusion of the UFI in the SDS is generally not mandatory, but it can be done voluntarily. Only in the case of mixtures which are not packaged, the UFI shall be indicated in the SDS or be included in the copy of the label elements referred to in Article 29(3), as applicable. For packaged mixtures to be used at industrial sites the supplier has the possibility to include the UFI on the SDS instead of the label (or both). The UFI must be indicated (when relevant) in Section 1.1.

The use of the UFI is relatively flexible. For example, when more than one UFI is used for the same mixture, it is possible and recommended to include one UFI only in the SDS. When the same SDS is used in different Member States, it is recommended to use (and notify) the same UFI in each of them. UFI(s) not notified in a Member State should not be used in the SDS supplied in that Member State.

To be noted that the provisions of Annex VIII to CLP apply from specific application dates on the basis of the final use of the mixture. Furthermore, a transitional period applies in certain cases. More details on the UFI are provided in the Guidance on harmonised information relating to emergency health response.39

38 Special provisions and alternatives about labelling may apply, please refer to the Annex VIII Guidance (see next footnote) and Labelling Guidance (available at: https://echa.europa.eu/guidance-documents/guidance-on-clp) 39 https://echa.europa.eu/documents/10162/13643/guidance_on_annex_viii_to_clp_en.pdf/


<a id="echa-s1-page-37"></a>
**ECHA printed page 37** — [original PDF page 37](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=37)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 37](page_images/ECHA_2020_page_037.jpg)

<a id="echa-sds-1-2"></a>
### 1.2 Relevant identified uses of the substance or mixture and uses advised against

Text Annex II

At least a brief description of the identified uses (for example, floor cleaning, or industrial use in polymer production, or professional use in cleaning agents) relevant for the recipient(s) of the substance or mixture shall be indicated.

The uses which the supplier advises against and the reasons why shall, where applicable, be stated. This need not be an exhaustive list.

Where a chemical safety report is required, the information in this subsection of the safety data sheet shall be consistent with the identified uses in the chemical safety report and the exposure scenarios from the chemical safety report set out in the annex to the safety data sheet.

The SDS must include at least a brief description of the identified uses40 of the substance or mixture relevant for the recipient(s) insofar as these are known. For registered substances for which a CSR is required this list of uses must be consistent with the uses identified in the registration CSR and exposure scenarios. For substances subject to authorisation the use(s) (as such or in a mixture) must be consistent with the use(s) identified in the authorisation CSR and exposure scenarios (unless the use(s) is/are exempted from the authorisation requirement).

To comply with the requirement for this description of identified uses to be brief, it is recommended that inclusion of a potentially long comprehensive list of formal “use descriptors”41 in this section be avoided. Otherwise it could result in an unnecessarily lengthy block of text diluting critical information on the front page of the SDS. An alternative is to have a more generic list of applications and a reference to any Exposure Scenario(s) attached. An index or table of contents could be added to section 16 with a reference in this section for the exposure scenario details e.g. generic list of applications plus a note such as ‘see SECTION 16 for a complete list of uses for which an exposure scenario is provided as an annex’.

The information in the subsection on uses advised against must be consistent with the information in section 3.6 of IUCLID (Uses Advised Against) for substances for which a registration is required. Note that where a use is advised against the reason why is also a requirement where applicable. Uses advised against may also be reported using elements of the Use Descriptor system, and/or with a generic description of the use(s). An example of how this subsection could look, including an illustrative entry is given below:

1.2. Relevant identified uses of the substance or mixture and uses advised against

Relevant identified uses: Consumer uses [SU 21]42 of Ink and Toners [PC18].

Uses advised against: Consumer uses [SU 21] of Coatings and paints, thinners, paint removers

40 Identified use is defined in REACH, Article 3 (26).

41 More information on use descriptors is given in Chapter R.12 of the ECHA Guidance on Information Requirements and Chemical Safety Assessment available at: guidance.echa.europa.eu/docs/guidance_document/information_requirements_en.htm.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 42 The full title of [and code for] the use descriptors as given in the Guidance on information requirements and chemical safety assessment Chapter R.12: Use description is given here for reference but is not a legal requirement within the SDS.


<a id="echa-s1-page-38"></a>
**ECHA printed page 38** — [original PDF page 38](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=38)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 38](page_images/ECHA_2020_page_038.jpg)

[PC9a].

Reason why uses advised against: Use on large surface area would potentially give excessive exposure to vapour.

It may also be useful to indicate whether the use is being advised against on the basis of being

(i) use advised against according to Annex I of REACH point 7 2.3 (substances that have

undergone CSA), (ii) a non statutory recommendation by a supplier according to Annex VI of REACH point 3.7 or, (iii) for non-registered substances or mixtures containing them merely a non statutory recommendation by the supplier, which might also have its basis in technical reasons.

<a id="echa-sds-1-3"></a>
### 1.3 Details of the supplier of the safety data sheet

Text Annex II

The supplier of the safety data sheet, whether it is the manufacturer, importer, only representative, downstream user or distributor, shall be identified. The full address and telephone number of the supplier shall be given as well as an e-mail address for a competent person responsible for the safety data sheet.

In addition, if the supplier is not located in the Member State where the substance or mixture is placed on the market and he has nominated a responsible person for that Member State, a full address and telephone number for that responsible person shall be given.

Where an only representative has been appointed, details of the non-Union manufacturer or formulator may also be provided.

For registrants, the information on the supplier of the safety data sheet and, if provided, the information on the supplier of the substance or mixture, shall be consistent with the information on the identity of the manufacturer, importer or only representative provided in the registration.

The contact details of the supplier must be specified in this section. In certain situations, it may be necessary to indicate more than one supplier in the same supply chain. For example, it should be noted that a distributor is also a supplier and thus they also always need to add their contact details in Section 1.3 of the SDS, even when they use the SDS from their supplier without changing any content. If nothing else is changed, it may suffice to keep the contact details of the previous supplier and add the contact details of the actual supplier with a 'stamp'.

Although details of the non-Union manufacturer or formulator are optional,  it is suggested to include whenever possible the details of the non-EU manufacturer/formulator to facilitate tracking of imported products by enforcement authorities.

It should further be noted that a “responsible person” is nominated by a “supplier” who, according to the definition of a “supplier” under REACH is located in one Member State. Such a “responsible person” can therefore be described for practical purposes as “any person that the supplier from one Member State may have chosen to appoint in a different Member State to deal with any enquiries concerning SDSs which arise in that different Member State”.

The information for this subsection may be structured as follows:


<a id="echa-s1-page-39"></a>
**ECHA printed page 39** — [original PDF page 39](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=39)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 39](page_images/ECHA_2020_page_039.jpg)

1.3. Details of the Supplier of the safety data sheet

- Manufacturer/Supplier

- Street address/P.O. Box

- Country ID/Postcode/Place

- Telephone number (if possible, indicate telefax)

- e-mail address of competent person responsible for the SDS

- National contact:

For the email address of the competent person responsible for the SDS, it is advisable to use a dedicated generic (non-personal) email address that can be then checked by various persons - e.g. SDS@companyX.com. There is no specific requirement that this competent person should be located within the territory of the European Union or European Economic Area.

In addition to the legal requirements specified above an additional department/contact person (e.g. internal or external health and safety consultant) responsible for the contents of the SDS could be indicated under “SECTION 16: Other information” (including telephone number as minimum contact information).

There is no requirement to mention the name of a physical person in an SDS, the “supplier” referred to above can be a physical (natural) or legal person.

<a id="echa-sds-1-4"></a>
### 1.4 Emergency telephone number

Text Annex II

References to emergency information services shall be provided. If an official advisory body exists in the Member State where the substance or mixture is placed on the market (this may be the body responsible for receiving information relating to health referred to in Article 45 of Regulation (EC) No 1272/2008), its telephone number shall be given and can suffice. If availability of such services is limited for any reasons, such as hours of operation, or if there are limits on specific types of information provided, this shall be clearly stated.

Please note that although the official advisory body may be appropriate, there may also be cases where certain Member States have an advisory body for medical personnel only to contact. In such cases if the telephone number is given in an SDS it should also be explicitly stated in the SDS that it is intended for use by medical professionals only. In any case it should be confirmed with the relevant body that its number can be given and whether any conditions apply (e.g. possibly prior supply of a copy of all SDSs or other information).

Please also note that at ECHA’s invitation, and on a voluntary basis, certain Member States have listed links to the telephone number(s) of appropriate national emergency information services to be listed in subsection 1.4 of the SDS in their entries on the ECHA web-page listing of national helpdesks at: https://echa.europa.eu/support/helpdesks.

The supplier must provide a reference to emergency information services. If an official advisory body as defined in the legal text above exists reference to it must be made.


<a id="echa-s1-page-40"></a>
**ECHA printed page 40** — [original PDF page 40](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=40)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 40](page_images/ECHA_2020_page_040.jpg)

Otherwise (or in addition) reference to an emergency service belonging to the supplier himself or to a competent third party provider of such a service must be made. Where the supplier provides his own emergency information service, be it alone or in combination with an official advisory body or other provider, the necessary competence should be available.

Any limitations on any the official advisory body, the supplier’s own, or any third party’s services (opening hours or types of information that can be provided) must be indicated e.g.:

(1) Only available during office hours.

(2) Only available during the following office hours: xx - xx

It is important to the reader of the SDS that the time-zones for office hours quoted are indicated, particularly where the offices are located in a Member State with a different time zone from the Member State where the product is being put on the market, and especially if they are outside the EU.

These services should be able to address requests/calls in the official language(s) of the Member State(s) for which the SDS is intended. Appropriate international dialling codes should of course be indicated as part of telephone numbers outside the country of supply of the substance/mixture referred to.

An example of how the structure of subsections 1.3 and 1.4 could look is given below:

1.3 Details of the supplier of the safety data sheet:

Supplier (manufacturer/importer/only representative/downstream user/distributor):

Street address/P.O. Box

Country ID/Postcode/Place

Telephone number

e-mail address of competent person for safety data sheet

National contact:

1.4 Emergency telephone number

Opening hours:

Other comments (e.g. language(s) of the phone service)


---

<a id="s2"></a>


# 3.2 SDS SECTION 2 — Hazards identification

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s2-page-41"></a>
**ECHA printed page 41** — [original PDF page 41](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=41)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 41](page_images/ECHA_2020_page_041.jpg)

3.2 SDS SECTION 2: Hazards identification

Text Annex II

This section of the safety data sheet shall describe the hazards of the substance or mixture and the appropriate warning information associated with those hazards.

The information on classification and labelling given in Section 2 of the SDS must of course be consistent with that on the actual labels for the substance/mixture in question.

<a id="echa-sds-2-1"></a>
### 2.1 Classification of the substance or mixture

Text Annex II

The classification of the substance or the mixture which results from the application of the classification criteria in Regulation (EC) No 1272/2008 shall be given. Where the supplier has notified information regarding the substance to the classification and labelling inventory in accordance with Article 40 of Regulation (EC) No 1272/2008, or has provided that information as part of a registration pursuant to this Regulation, the classification given in the safety data sheet shall be the same as the classification provided in that notification or registration.

If the mixture does not meet the criteria for classification in accordance with Regulation (EC) No 1272/2008, this shall be clearly stated.

Information on the substances in the mixture is provided under subsection 3.2.

If the classification, including the hazard statements, is not written out in full, reference shall be made to Section 16 where the full text of each classification, including each hazard statement, shall be given.

The most important adverse physical, human health and environmental effects shall be listed in accordance with Sections 9 to 12 of the safety data sheet, in such a way as to allow non-experts to identify the hazards of the substance or mixture.

For a substance

The classification given in the SDS must be the same as that provided in the registration dossier or, if the supplier is not a registrant, the same the supplier has notified to the classification and labelling inventory.

The classification is to be given according to the rules in the CLP Regulation: i.e. indication of hazard classes and categories and hazard statements.

Although not a legal requirement, information on which procedure was used for each endpoint classification (e.g. based on test data, human experience, minimum classification, summation method or specified bridging principles etc.) should preferably be given here, where available.

An example of how the structure of this section could look for a substance is given below43:

43 Note that additional numbering and sub-structuring below the subsection level is not a legal requirement.


<a id="echa-s2-page-42"></a>
**ECHA printed page 42** — [original PDF page 42](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=42)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 42](page_images/ECHA_2020_page_042.jpg)

SECTION 2: Hazards identification

2.1 Classification of the substance or mixture

2.1.1 Classification according to Regulation (EC) No 1272/2008 (CLP)

Flam. Liq. 2, H225

Acute Tox. 3, H301

Acute Tox. 3, H311

Acute Tox. 3, H331

STOT SE 1, H370

Aquatic Acute 1, H400

2.1.2 Additional information:

For full text of Hazard- and EU Hazard-statements: see SECTION 16.

For a mixture

The classification is given according to the CLP Regulation: indication of hazard classes and categories and hazard statements.

When the SDS is being provided on request for a non-classified mixture (according to the requirements of Article 31(3) of REACH or in Annex I of CLP), this should be indicated. It may also be desirable to indicate the specific reason for inclusion of the mixture within the scope of Article 31(3) or Annex I of CLP. An example of a statement to do this, in a case relating to Article 31(3) (c), could be:

“This product does not meet the criteria for classification in any hazard class according to Regulation (EC) No 1272/2008 on classification, labelling and packaging of substances and mixtures. However a safety data sheet is being supplied for it upon request as it contains a substance for which there is a Union workplace exposure limit”.

Please note that more and more information on the components of mixtures is becoming available (e.g. as a result of new tests or other information exchanges) following the REACH registration or a registration update, as a result of activities in the joint submission or consortium or by individual registrant. Increasing the availability of information continues via ECHA’s Integrated Regulatory Strategy and the ongoing regulatory activities conducted by the member states competent authorties.

<a id="echa-sds-2-2"></a>
### 2.2 Label elements

Text Annex II

Based on the classification, at least the following elements appearing on the label in accordance with Regulation (EC) No 1272/2008 shall be provided: hazard pictogram(s), signal word(s), hazard statement(s) and precautionary statement(s). A graphical reproduction of the full hazard pictogram in black and white or a graphical reproduction of the symbol only may be substituted for the colour pictogram provided in Regulation (EC) No 1272/2008.


<a id="echa-s2-page-43"></a>
**ECHA printed page 43** — [original PDF page 43](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=43)

The applicable label elements in accordance with Article 25(1) to (6) and Article 32(6) of Regulation (EC) No 1272/2008 shall be provided.

For both substances and mixtures the label elements are to be indicated according to the CLP Regulation. These elements must include all label elements appearing on the label (i.e. including, where appropriate, the inner packaging label elements44).

The label elements indicated must be consistent with the corresponding label affixed to the product.

Label elements according to the CLP Regulation include:

- Hazard pictogram(s)45,

- Signal word;

- Hazard statement(s), H and EUH, in full (or give in full in Section 16 if not here);

- Precautionary statement(s), P, in full

- Any additional applicable label elements in accordance with Article 25 of CLP on “Supplemental information on the label”

As indicated in the legal text quoted above, the hazard pictogram may be replaced by a graphical reproduction of the full hazard pictogram in black and white or a graphical reproduction of the symbol only.

The precautionary statements may be selected in accordance with the criteria laid down in Part 1 of Annex IV of CLP taking into account the hazard statements and the intended or identified use or uses of the substance or the mixture. Once selected, the precautionary statements should normally be worded in accordance with Part 2 of Annex IV of CLP. However, the wording of the selected precautionary statements  or their combinations may incorporate minor textual variations when these variations assist in communicating safety information and the safety advice is not diluted or compromised, as described in paragraph (1) of Annex IV to the CLP Regulation (as amended by Commission Regulation (EU) 2019/521).

In selecting the precautionary statements in accordance with Articles 22 and 28 of CLP, suppliers may combine the precautionary statements, having regard to clarity and comprehensibility of the precautionary advice. It should be noted that according to Article 28(3) of CLP not more than six precautionary statements should appear on the label unless necessary. For further information on selection of precautionary statements see the ECHA Guidance on labelling and packaging in accordance with Regulation (EC) 1272/200846.

It may be useful for industrial and professional users (not for consumers since they do not receive SDSs) to include special precautionary statements into the appropriate sections of the

44 i.e. including, for example, hazard pictograms which do not have to appear on the outer packaging according to Article 33(1) of CLP because these relate to the same hazard as in the rules for transport of dangerous goods.

45 According to Article 2(3) of CLP " ‘hazard pictogram’ means a graphical composition that includes a symbol plus other graphic elements, such as a border, background pattern or colour that is intended to convey specific information on the hazard concerned; "

46 Available at: https://echa.europa.eu/guidance-documents/guidance-on-clp


<a id="echa-s2-page-44"></a>
**ECHA printed page 44** — [original PDF page 44](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=44)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 44](page_images/ECHA_2020_page_044.jpg)

SDS main body in order to reduce the number of precautionary statements on the label47 48. Examples of such precautionary statements that could, for example, be given in subsection 7.1 “precautions for safe handling” instead of on the label are as follows:

- Do not handle until all safety precautions have been read and understood (P202)

- Wash hands thoroughly after handling (P264)

- Do not eat, drink or smoke when using this product (P270)

- Contaminated work clothing should not be allowed out of the workplace (P272)

According to REACH Article 65, holders of an authorisation, as well as downstream users referred to in Article 56(2) who include a substance subject to authorisation in a mixture, must include the authorisation number on the label of the respective substance or mixture before it is placed on the market. In such cases the authorisation number becomes a mandatory label element according to CLP (via Article 32(6) of CLP concerning “label element requirements resulting from other Community acts”) and must therefore be included in this section of the SDS. Required label elements according to REACH Annex XVII (such as "Restricted to professional users" are also examples of label elements which should be included in the SDS, in subsection 2.2. for substances and mixtures labelled according to CLP. Label elements potentially arising out of national legislation may also be given here.

An example of how the structure of this subsection could look for a substance is given below49:

2.2: Label elements50

Labelling according to Regulation (EC) No 1272/2008 [CLP]

Hazard pictograms

Signal word:

Danger

Hazard statements:

H27151May cause fire or explosion; strong oxidiser.

47 Note that the P-code (e.g. "P202") is not itself a part of the precautionary statement, but it may be useful to indicate it in brackets after the statement for ease of reference.

48 Precautionary statements should be provided in the SDS (and not on the label) only when these would not be necessary on the label itself to reflect the nature and severity of hazards (see the conditions in Article 28(3) of CLP).

49 Sodium peroxide has been used as an actual example to further illustrate reduction of the number of precautionary statements. This is therefore not an example of a substance subject to authorisation.

50 Note that the product identifier, although a label element, is not given in subsection 2.2 as it is not specified as one of the elements which should appear here. It is to be given in section 1.1.

51 Note the reference number of pictograms and H and P statements (e.g. “H271”) do not need to appear on the label


<a id="echa-s2-page-45"></a>
**ECHA printed page 45** — [original PDF page 45](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=45)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 45](page_images/ECHA_2020_page_045.jpg)

H314 Causes severe skin burns and eye damage

Precautionary statements52:

P210 Keep away from heat/sparks/open flames/hot surfaces. – No smoking.

P221Take any precaution to avoid mixing with combustibles.

P280 Wear protective gloves/protective clothing/eye protection/ face protection.

P301+P330+P331 IF SWALLOWED: rinse mouth. Do NOT induce vomiting.

P303+P361+P353+310   IF ON SKIN (or hair): Remove/Take off immediately all contaminated clothing. Rinse skin with water/shower. Immediately call a POISON CENTER53 or doctor/physician.

P305+P351+P338IF IN EYES: Rinse cautiously with water for several minutes. Remove contact lenses, if present and easy to do. Continue rinsing.

P371+P380+P375In case of major fire and large quantities: Evacuate area. Fight fire remotely due to the risk of explosion.

Supplemental Hazard information (EU)54: Not applicable.

Reduction of the number of precautionary statements

According to Article 28(3) of CLP “Not more than six precautionary statements shall appear on the label, unless necessary to reflect the nature and the severity of the hazards”.

The determination of which precautionary statements appear on the label should be carried out in compliance with the CLP regulation. The requirement of Annex II of REACH with respect to their inclusion in an SDS is simply that the statements which appear on the label be given in this subsection (2.2) of the SDS.

Further information on how the number of precautionary statements can be reduced to as close as reasonable to the target number of a maximum of six is given in the ECHA Guidance on labelling and packaging in accordance with Regulation (EC) No 1272/200855.

<a id="echa-sds-2-3"></a>
### 2.3 Other hazards

Text Annex II

and in subsection 2.2 of the SDS; only their full text is required. However, in order to be able to check and/or compare labelling information, it is recommended to quote these numbers in subsection 2.2 of the SDS.

52 See next page for further information on how the number of precautionary statements has been reduced.

53 (Note spelling of “center” is US English, carried over from GHS).

54 If applicable.

55 Available at: https://echa.europa.eu/guidance-documents/guidance-on-clp


<a id="echa-s2-page-46"></a>
**ECHA printed page 46** — [original PDF page 46](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=46)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 46](page_images/ECHA_2020_page_046.jpg)

Information shall be provided on whether the substance meets the criteria for persistent, bioaccumulative and toxic or very persistent and very bioaccumulative in accordance with Annex XIII, whether the substance was included in the list established in accordance with Article 59(1) for having endocrine disrupting properties, and whether the substance is a substance identified as having endocrine disrupting properties in accordance with the criteria set out in Commission Delegated Regulation (EU) 2017/210056 or Commission Regulation (EU) 2018/60557. For a mixture, information shall be provided for each such substance that is present in the mixture at a concentration equal to or greater than 0.1% by weight.

Information shall be provided on other hazards which do not result in classification but which may contribute to the overall hazards of the substance or mixture, such as formation of air contaminants during hardening or processing, dustiness, explosive properties which do not fulfil the classification criteria of part 2 Section 2.1. of Annex I to Regulation (EC) No 1272/2008, dust explosion hazards, cross-sensitisation, suffocation, freezing, high potency for odour or taste, or environmental effects like hazards to soil-dwelling organisms, or photochemical ozone creation potential. The statement ”May form explosible dust-air mixture if dispersed” is appropriate in the case of a dust explosion hazard.

The information on other hazards which do not result in classification, but which must be given here, includes, for example, information on the presence of sensitisers, according to Article 25(6) of CLP58.

An example of how the structure of this subsection could look, including some phrases that can be used if appropriate, is given below:

2.3 Other hazards

Risk of blindness after swallowing the product.

Substance meets the criteria for vPvB and PBT according to Regulation (EC) No 1907/2006, Annex XIII

Substance identified as having endocrine disrupting properties according to Regulation (EU) 2017/2100

Substance is phototoxic.


---

<a id="s3"></a>


# 3.3 SDS SECTION 3 — Composition/information on ingredients

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s3-page-46"></a>
**ECHA printed page 46** — [original PDF page 46](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=46)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 46](page_images/ECHA_2020_page_046.jpg)

<a id="echa-sds-3-3"></a>
### 3.3 SDS SECTION 3: Composition/information on ingredients

Text Annex II

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   56 Commission Delegated Regulation (EU) 2017/2100 of 4 September 2017 setting out scientific criteria for the determination of endocrine-disrupting properties pursuant to Regulation (EU) No 528/2012 of the European Parliament and Council (OJ L 301, 17.11.2017, p. 1). 57 Commission Regulation (EU) 2018/605 of 19 April 2018 amending Annex II to Regulation (EC) No 1107/2009 by setting out scientific criteria for the determination of endocrine disrupting properties (OJ L 101, 20.4.2018, p. 33). 58 As a further example, information on explosive properties includes, for example, information related to transport packaging, EU test method A.14, the potential risk from explosive atmospheres, and other circumstances not associated with the CLP classification.


<a id="echa-s3-page-47"></a>
**ECHA printed page 47** — [original PDF page 47](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=47)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 47](page_images/ECHA_2020_page_047.jpg)

This section of the safety data sheet shall describe the chemical identity of the ingredient(s) of the substance or mixture, including impurities and stabilising additives as set out below. Appropriate and available safety information on surface chemistry shall be indicated.

Either section 3.1 or 3.2 must be included in the SDS, as appropriate, for only one of either a substance or mixture as applicable59.

It should be noted that the term “surface chemistry” as used in the text above is intended to refer to properties that may arise as a result of the particular surface properties of a (solid) substance or mixture (e.g. due to having certain dimensions in the nano range)60.

<a id="echa-sds-3-1"></a>
### 3.1 Substances

Text Annex II

The chemical identity of the main constituent of the substance shall be provided by providing at least the product identifier or one of the other means of identification given in subsection 1.1.

The chemical identity of any impurity, stabilising additive, or individual constituent other than the main constituent, which is itself classified and which contributes to the classification of the substance shall be provided as follows:

(a) the product identifier in accordance with Article 18(2) of Regulation (EC) No 1272/2008;

(b) if the product identifier is not available, one of the other names (usual name, trade name, abbreviation) or identification numbers.

The specific concentration limit, the M-factor and the acute toxicity estimate for substances included in Part 3 of Annex VI to Regulation (EC) No 1272/2008 or determined in accordance with Annex I to that Regulation shall be indicated, if available.

If the substance is registered and it covers a nanoform, the particle characteristics that specify the nanoform, as described in Annex VI, shall be indicated.

If the substance is not registered, but the safety data sheet covers nanoforms, the particle characteristics of which have impact on the safety of the substance, those characteristics shall be indicated.

Suppliers of substances may choose to list in addition all constituents including non-classified ones.

This subsection may also be used to provide information on multi-constituent substances.

The chemical identifiers of the main constituent need to be added in this section (information from Section 1.1).

59 Whichever of these two subsections is not applicable becomes the only subsection in the SDS which may be left out completely. If the sub-heading that does not apply is included, the field needs to be filled in with the indication that it does not apply (i.e. “not applicable”). Please note, it is not sufficient to use the main heading “Section 3: composition information on ingredients” only.

60 It is specifically not intended to require information to be given here on surfactant properties of (liquid or dissolved) substances or mixtures.


<a id="echa-s3-page-48"></a>
**ECHA printed page 48** — [original PDF page 48](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=48)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 48](page_images/ECHA_2020_page_048.jpg)

The update of Regulation 2020/878 adds to this section the requirement to indicate the specific concentration limit (SCL), the multiplication factor (M-factor) and the acute toxicity estimate (ATE), if applicable and available. Annex II specifies that this information should be provided in Section 3.1, rather than in Section 2.1.

The derivation of an SCL or an ATE, when this is appropriate, or the assignment of M-factors when a substance is classified as Aquatic acute 1 or Aquatic chronic 1, is an essential part of the classification procedure, to ensure that substances and mixtures containing the substance are correctly classified. However, while these values are an integral part of a classification, they can be considered as tools for the determination of the correct classification of a mixture containing the substance in question, and therefore, for consistency, they should all be indicated in Section 3.

Note that it is not a requirement to separately give the classification  etc. for impurities in a substance (by contrast to the case for mixtures covered by point 3.2.3 in the legal text below) since these should already have been taken into account in the classification of the substance as registered under REACH / notified under CLP.

An expanded illustrative example of how the structure of this section could look for a styrene monomer is given below61:

SECTION 3: COMPOSITION/INFORMATION ON INGREDIENTS 3.1 SUBSTANCES

Product identifier type in accordance with Article 18(2) of Regulation (EC) No 1272/2008

Identification number

Substance name

Weight % content (or range)

EC Number62

SCL/

M-factor/

ATE

Index number in CLP Annex VI
601-026-00-0
styrene
99.70 – 99.95
202-851-5
ATE
(inhalation,
vapour): 11,
8 mg/l/4h

CAS number in CLP Annex VI 98-83-9 α- methylstyrene

0.04 maximum

202-705-0 STOT SE 3; H335: C ≥ 25 %

61 Note that the field names need not in practice be as pedantic as those used for illustration here and that a more “classical” listing with multiple identifiers would also be acceptable, as long as the content of the fields conforms with the requirements – see reduced example on next page.

62 If all the first three columns in this example are populated this column is not a requirement – it is for information only.


<a id="echa-s3-page-49"></a>
**ECHA printed page 49** — [original PDF page 49](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=49)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 49](page_images/ECHA_2020_page_049.jpg)

CAS number in CLP Annex VI63 100-41-4 ethylbenzene 0.05 maximum

202-849-4 ATE (inhalation, vapour): 17,6 mg/l/4h

ATE (oral): 3500 mg/kg

ATE (dermal): 15400 mg/kg

CAS number 98-29-3 4-tert- butylbenzene- 1,2-diol64

0.0015 (15 ppm) maximum

202-653-9 M = 1 (Aquatic acute)

ATE (oral): 815 mg/kg

ATE (dermal): 1331 mg/kg

(Non-classified constituent) Not applicable Polymers Max 0.0020 Not applicable

-

In practice, for the particular case given above, since the components other than styrene are present at a level below that to be taken into account for classification, the example could be reduced to the following where the supplier does not wish to use the SDS to additionally give specification information:

SECTION 3: COMPOSITION/INFORMATION ON INGREDIENTS: 3.1 SUBSTANCES

Substance name

Index number in CLP Annex VI

Weight % content (or range)

SCL, M-factor, ATE

Styrene 601-026-00-0 > 99.5 % ATE (inhalation, vapour): 11,8 mg/l/4h

63 Ethylbenzene and α-methylstyrene have of course also an index number in Annex VI of CLP – the CAS number has been chosen here to illustrate the principle that any of the identifiers given in the Annex can be used – in practice consistency might be desirable in choice of available numbers.

64 This is the actual IUPAC name for the substance otherwise known as 4-tert-butyl catechol / 4-tert-butyl pyrocatecol / TBC.


<a id="echa-s3-page-50"></a>
**ECHA printed page 50** — [original PDF page 50](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=50)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 50](page_images/ECHA_2020_page_050.jpg)

The example for a substance with impurities can be contrasted with the example given for a mixture in the next section . This may help to clarify the difference in requirements for substance information under subsection 3.1 with those for mixture information under subsection 3.2.

For nanoforms, the particle characteristics that specify the nanoform, as described in Annex VI must be provided. The Appendix for nanoforms applicable to the Guidance on Registration and Substance Identification65 provides advice on the characterisation and reporting requirements for nanoforms according to Annex VI of REACH.

For the nanoforms that have not been registered, the particle characteristics of which have impact on the safety of the substance should be provided. Both the Appendix above and the Appendix R.6-1: for nanomaterials applicable to the Guidance on QSARs and Grouping describe the particle characteristics that may have an impact on the safety of nanoforms.  The additional information for nanoforms could follow the model shown in Table 1.  Table 1: additional information required for (registered) nanoforms of a substance:

Name of (set of) nanoform(s) [Name]

Value Unit

d10 [range]

Number based particle size distribution

d50 [range]

d90 [range]

Shape and aspect ratio of particles [shape] [aspect ratio range]

Crystallinity [ratio of crystal structures]

Agent(s) [list of treatment agents]

Surface functionalisation / treatment

Process [brief process description]

Specific surface area [range]

Additional information [any additional information]

<a id="echa-sds-3-2"></a>
### 3.2 Mixtures

Text Annex II

The product identifier, the concentration or concentration ranges and the classifications shall be provided for at least all substances referred to in points 3.2.1 or 3.2.2. Suppliers of mixtures may choose to list in addition all substances in the mixture, including substances not meeting the criteria for classification. This information shall enable the recipient to identify readily the hazards of the substances in the mixture. The hazards of the mixture itself shall be given in Section 2.

The concentrations of the substances in a mixture shall be described as either of the following:

(a) exact percentages in descending order by mass or volume, if technically possible;

65 https://echa.europa.eu/documents/10162/13655/how_to_register_nano_en.pdf/


<a id="echa-s3-page-51"></a>
**ECHA printed page 51** — [original PDF page 51](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=51)

(b) ranges of percentages in descending order by mass or volume, if technically possible.

When using a range of percentages, if the effects of the mixture as a whole are not available, the health and environmental hazards shall describe the effects of the highest concentration of each ingredient.

If the effects of the mixture as a whole are available, the classification determined from this information shall be included under section 2.

Where the use of an alternative chemical name is permitted in accordance with Article 24 of Regulation (EC) No 1272/2008, that name can be used.

3.2.1. For a mixture meeting the criteria for classification in accordance with Regulation (EC) No 1272/2008, the following substances (see also Table 1.1) shall be indicated, together with their concentration or concentration range in the mixture:

(a) substances presenting a health or environmental hazard within the meaning of Regulation (EC) No 1272/2008, if those substances are present in concentrations equal to or greater than the lowest of any of the following:

(i) the generic cut-off values set out in Table 1.1 of Annex I to Regulation (EC) No 1272/2008;

(ii) the generic concentration limits given in parts 3 to 5 of Annex I to Regulation (EC) No 1272/2008, taking into account the concentrations specified in the notes to certain tables in part 3 in relation to the obligation to make available a safety data sheet for the mixture upon request, and for aspiration hazard (Section 3.10 of Annex I to Regulation (EC) No 1272/2008) ≥ 1 %;

(iii) the specific concentration limits given in Part 3 of Annex VI to Regulation (EC) No 1272/2008;

(iv) if a M-factor has been given in Part 3 of Annex VI to Regulation (EC) No 1272/2008, the generic cut-off value in Table 1.1 of Annex I to that Regulation, adjusted using the calculation set out in Section 4.1 of Annex I to that Regulation;

(v) the specific concentration limits provided to the classification and labelling inventory established under Regulation (EC) No 1272/2008;

(vi) one tenth of the specific concentration limit for a substance classified as skin sensitiser or respiratory sensitiser with a specific concentration limit;

(vii) the concentration limits set out in Annex II to Regulation (EC) No 1272/2008;

(viii) if an M-factor has been provided to the classification and labelling inventory established under Regulation (EC) No 1272/2008, the generic cut-off value in Table 1.1 of Annex I to that Regulation, adjusted using the calculation set out in Section 4.1 of Annex I to that Regulation.

(b) substances for which there are Union workplace exposure limits which are not already included under point (a);

(c) provided that the concentration of an individual substance is equal to or greater than 0,1 %, substances that meet any of the following criteria:

- substances that are persistent, bioaccumulative and toxic or very persistent and very bioaccumulative in accordance with the criteria set out in Annex XIII,

- substances included in the list established in accordance with Article 59(1) for reasons other than the hazards referred to in point (a) of this subsection such as endocrine disrupting properties,

- substances identified as having endocrine disrupting properties in accordance with the criteria set out in Delegated Regulation (EU) 2017/2100 or Regulation (EU) 2018/605.

List of hazard classes, hazard categories and concentration limits for which a substance shall be listed as a substance in a mixture in subsection 3.2.

1.1 Hazard class and category Concentration


<a id="echa-s3-page-52"></a>
**ECHA printed page 52** — [original PDF page 52](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=52)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 52](page_images/ECHA_2020_page_052.jpg)

limit %

Acute toxicity, category 1, 2 and 3 ≥ 0,1

Acute toxicity, category 4 ≥ 1

Skin corrosion/irritation, category 1, categories 1A, 1B, 1C and category 2

≥ 1

Serious damage to eyes/eye irritation, category 1 and 2 ≥ 1

Respiratory sensitiser category 1 or category 1B ≥ 0,1

Respiratory sensitiser category 1A ≥ 0,01

Skin sensitiser category 1 or category 1B ≥ 0,1

Skin sensitiser category 1A ≥ 0,01

Germ cell mutagenicity category 1A and 1B ≥ 0,1

Germ cell mutagenicity category 2 ≥ 1

Carcinogenicity category 1A, 1B and 2 ≥ 0,1

Reproductive toxicity, category 1A, 1B, 2 and effects on or via lactation

≥ 0,1

Specific target organ toxicity (STOT) - single exposure, category 1, 2 and 3

≥ 1

Specific target organ toxicity (STOT) – repeated exposure, category 1 and 2

≥ 1

Aspiration toxicity ≥ 1

Hazardous to the aquatic environment – Acute, category 1 ≥ 0,1

Hazardous to the aquatic environment – Chronic, category 1 ≥ 0,1

Hazardous to the aquatic environment – Chronic, category 2, 3 and ≥ 1


<a id="echa-s3-page-53"></a>
**ECHA printed page 53** — [original PDF page 53](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=53)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 53](page_images/ECHA_2020_page_053.jpg)

4

Hazardous for the ozone layer ≥ 0,1

3.2.2. For a mixture not meeting the criteria for classification in accordance with Regulation (EC) No 1272/2008, substances present in an individual concentration equal to or greater than the following concentrations shall be indicated, together with their concentration or concentration range:

(a) 1 % by weight in non-gaseous mixtures and 0,2 % by volume in gaseous mixtures for:

(i) substances which present a health or environmental hazard within the meaning of Regulation (EC) No 1272/2008; or

(ii) substances for which Union workplace exposure limits have been assigned;

(b) 0,1 % by weight for substances that meet any of the following criteria:

- substances that are persistent, bioaccumulative and toxic in accordance with the criteria set out in Annex XIII,

- substances that are very persistent and very bioaccumulative in accordance with the criteria set out in Annex XIII,

- substances included in the list established in accordance with Article 59(1) for reasons other than the hazards referred to in point (a) of this subsection such as endocrine disrupting properties;

- identified as having endocrine disrupting properties in accordance with the criteria set out in Delegated Regulation (EU) 2017/2100 or Regulation (EU) 2018/605;

(c) 0,1 % of a substance classified as skin sensitiser category 1 or 1B, respiratory sensitiser  category 1 or 1B, or carcinogenic category 2;

(d) 0,01 % of a substance classified as skin sensitiser category 1A or respiratory sensitiser  category 1A;

(e)  one tenth of the specific concentration limit for a substance classified as skin sensitiser or  respiratory sensitiser with a specific concentration limit;

(f) 0,1 % of a substance classified as toxic to reproduction categories 1A, 1B or 2, or with effects on or via lactation.

3.2.3. For the substances indicated in subsection 3.2.:

- the classification of the substance according to Regulation (EC) No 1272/2008, including the hazard class(es) and category code(s) as provided in Table 1.1 of Annex VI to that Regulation as well as the hazard statements and supplemental hazard statements, shall be provided. The hazard statements and the supplemental hazard statements do not need to be written out in full in this subsection; their codes shall be sufficient. In cases where they are not written out in full, reference shall be made to section 16, where the full text of each relevant hazard statement shall be listed. If the substance does not meet the classification criteria, the reason for indicating the substance in subsection 3.2. shall be described, such as ‘non-classified vPvB substance’ or ‘substance with a Union workplace exposure limit’.


<a id="echa-s3-page-54"></a>
**ECHA printed page 54** — [original PDF page 54](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=54)

- the specific concentration limit, the M-factor and the acute toxicity estimate for the substance in Part 3 of Annex VI to Regulation (EC) No 1272/2008 or as determined in accordance with Annex I to that Regulation shall be indicated, if available.

- if the substance as used in the mixture is in nanoform and is as such registered or addressed by the downstream user chemical safety report, the particle characteristics that specify the nanoform, as described in Annex VI, shall be indicated. If the substance as used in the mixture is in nanoform but is not registered or addressed by the downstream user chemical safety report, the particle characteristics which have impact on the safety of the mixture, shall be provided.

3.2.4. For the substances indicated in subsection 3.2 the name and, if available, the registration number, as assigned under Article 20(3) of this Regulation, shall be given.

Without affecting the obligations of downstream users laid down in Article 39 of this Regulation, the part of the registration number referring to the individual registrant of a joint submission may be omitted by the supplier of the mixture provided that:

(a) this supplier assumes the responsibility to provide the full registration number upon request for enforcement purposes, or, if the full registration number is not available to him, to forward the request to his supplier, in line with point (b); and

(b) this supplier provides the full registration number to the Member State authority responsible for enforcement (hereinafter referred to as the enforcement authority) within seven days upon request, received either directly from the enforcement authority or forwarded by his recipient, or, if the full registration number is not available to him, this supplier shall forward the request to his supplier within seven days upon request and at the same time inform the enforcement authority thereof.

The EC number, if available, shall be given in accordance with Regulation (EC) No 1272/2008. The CAS number, if available, and the IUPAC name, if available, may also be given.

For substances indicated in this subsection by means of an alternative chemical name in accordance with Article 24 of Regulation (EC) No 1272/2008, the registration number, EC number and other precise chemical identifiers are not necessary.

Where a specific concentration limit (SCL), a multiplying factor (M-factor), or an acute toxicity estimate (ATE) is available, these must be indicated together with the classification information and any relevant supplemental hazard statements for the relevant component in this subsection 3.2.

The term “if technically possible”, as used in the context of the requirement to give concentrations of the substances in a mixture as either exact percentages or ranges of percentages in descending order, means that expressing the concentrations either as exact percentages or ranges of percentages should be done if e.g. the SDS-generating software allows this ranking with the available composition information. It does not mean that all technical steps (including e.g. analysis) need to be exhausted in order to determine precise information necessary for such a ranking where it is not otherwise available.

In the case of mixtures, the part of the REACH registration number for component substances referring to the individual registrant of a joint submission (the last four digits of the original full registration number) can be omitted by any supplier (it should be noted that in this case it is not a requirement that the supplier be a downstream user or distributor as is the case for truncation of the registration number given for substances in subsection 1.1)66. It should be further noted that registration numbers are only required in this subsection for the substances

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   66 For more information please refer to Q&As section (Q&As nr 137, 144 and 145) on the ECHA website at: http://www.echa.europa.eu/support/qas-support/search-qas.


<a id="echa-s3-page-55"></a>
**ECHA printed page 55** — [original PDF page 55](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=55)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 55](page_images/ECHA_2020_page_055.jpg)

referred to in points 3.2.1 or 3.2.2. However, if suppliers choose to list additional substances in the mixture under subsection 3.2, although they are not obliged to give the information specified in point 3.2.1 or 3.2.2 for these substances, they must then give the applicable information specified in points 3.2.3 and 3.2.4, including the registration numbers if available. It may be helpful to indicate on what basis a substance has been included in Section 3.2, e.g., due to CLP classification triggers (e.g. generic concentration limits, additivity or bridging principles) or due to REACH Annex II requirements.

The “substances included in the list established in accordance with Article 59(1) for reasons other than the hazards referred to in point (a), if the concentration of an individual substance is equal to or greater than 0,1 %” in the legal text quoted above are the so-called “candidate list” substances (see chapter 2, para 2.15 of this document for more information).

An example of how the structure of this subsection could look for a mixture is given below67:

CAS No EC No Index No. REACH Registration No.

% [weight]

Substance name

Classification according to Regulation (EC) No 1278/2008 (CLP).

SCL,

M-factor,

ATE

7681-52-9 231-668-3 017-011-00-1 01- XXXXXXXXXX- XX-YYYY

60 Sodium hypochlorite

Skin Corr. 1B, H314

EUH031: C ≥ 5 %

Eye Dam. 1, H318

Aquatic Acute 1, H400

M (acute) =1

Aquatic Chronic 1, H410

M (chronic) =10

1310-73-2 215-185-5 011-002-00-6 01- NNNNNNNNNN -NN-ZZZZ

39 Sodium hydroxide

Skin Corr. 1A, H314

Eye Irrit. 2; H319: 0.5 % ≤ C < 2 %

Eye Dam. 1, H318

Skin Corr. 1A; H314: C ≥ 5 %

Skin Corr. 1B; H314: 2 % ≤ C < 5 %

Skin Irrit. 2; H315: 0.5 % ≤ C < 2 %

67 PLEASE NOTE: This example is given for the purposes of illustrating the format of entries in this subsection, and in particular the difference by comparison of with an entry in subsection 3.1 for a substance with impurities. IT IS NOT TO BE TAKEN AS AN INDICATION THAT SUCH A MIXTURE WOULD BE STABLE AGAINST ANY REACTIONS.


<a id="echa-s3-page-56"></a>
**ECHA printed page 56** — [original PDF page 56](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=56)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 56](page_images/ECHA_2020_page_056.jpg)

7758-98-7 231-847-6 029-004-00-0 01- NNNNNNNNNN -NN-WWWW

1 Copper sulphate

Acute tox 3

ATE (oral): 482 mg/kg

Skin Irrit 2

Eye Irrit 2

Aquatic Acute 1

M(acute)= 10

Aquatic Chronic 1

M(chronic)= 1

For nanoform components, the same characterisation requirements detailed for section 3.1 of the SDS apply (see Table 1).

Additional information:

For full text of H-statements, see SECTION 16.

Note that since only one of CAS, EC or index number is required, this table could alternatively be simplified by replacing the three columns (one for each type of number) by two columns: one for "number type" and a second for "number". Alternatively these example tables can be presented in other ways, e.g. by using two columns for 'number type' and 'number'.

It should be noted that the classification given for a component substance in the final two columns should be that of the pure (100%) substance.

Weight ranges may be given instead of actual weight percentages. When using a range of percentages, the indicated health and environmental hazards must reflect the effects of the highest concentration of each ingredient substance. It should be noted that if the total sum of the highest concentrations exceeds 100 %, the classification of the mixture cannot be correctly derived.

It should be noted that the table given in the text of Annex II quoted above under the title “List of hazard classes, hazard categories and concentration limits (including generic cut-off values in Table 1.1 of Regulation (EC) No 1272/2008 and generic concentration limits given in parts 3 to 5 of Annex I to that Regulation) for which a substance shall be listed as a substance in a mixture in subsection 3.2.” gives the values above which the specified substances must be listed in an SDS. These are not necessarily the generic limits for classification – the values in this particular table have been adjusted to incorporate the notes in the CLP regulation requiring provision of an SDS in certain cases even when the value is below that leading to classification. For example, in the case of Reproductive toxicity, category 1A, 1B, 2 and effects on or via lactation the value given in the table is ≥ 0.1, even though according to Table 3.7.2 “Generic concentration limits of ingredients of a mixture classified as reproduction toxicants or for effects on or via lactation that trigger classification of the mixture” in Annex I of the CLP Regulation gives a value of ≥ 0.3 for the concentration limit for classification. This is because this table incorporates the relevant Note 1 below the table which states that “If a Category 1 or Category 2 reproductive toxicant or a substance classified for effects on or via lactation is present in the mixture as an ingredient at a concentration above 0,1 %, a SDS shall be available for the mixture upon request”. It is this latter value which appears in the table referred to above, since its aim is to indicate the value relevant to the SDS, not that determining classification.

Where an alternative chemical name is being used according to the provisions of Article 24 of


<a id="echa-s3-page-57"></a>
**ECHA printed page 57** — [original PDF page 57](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=57)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 57](page_images/ECHA_2020_page_057.jpg)

CLP for a substance in a mixture it is recommended that this be indicated (with an appropriate identifier such as a notification number) in this subsection (or in Sections 15 or 16) in order to avoid enquiries on its use from recipients or from enforcement authorities. For substances indicated in this subsection by means of an alternative chemical name, the registration number, EC number and other precise chemical identifiers are not necessary.

Subsection 3.2 of the SDS may also be used to provide certain information on the composition of detergents intended to be used in the industrial and institutional sector, and not made available to members of the general public68.

With respect to listing under subsection 3.2 it should be noted that the legal requirement (for substances not already listed for other reasons) is to be listed when these are “(b) substances for which there are Union workplace exposure limits…“ i.e. it is a Union limit which determines listing. However, compilers may voluntarily list substances in this subsection (or in SECTIONS 15 or 16) for which a national, but no Union limit has been assigned (contrast the case discussed below for subsection 8.1 where it is information on national limits that must be provided, regardless of whether a corresponding Union limit exists).


---

<a id="s4"></a>


# 3.4 SDS SECTION 4 — First aid measures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s4-page-57"></a>
**ECHA printed page 57** — [original PDF page 57](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=57)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 57](page_images/ECHA_2020_page_057.jpg)

3.4 SDS SECTION 4: First aid measures

Text Annex II

This section of the safety data sheet shall describe the initial care in such a way that an untrained responder can understand and provide it without the use of sophisticated equipment and without the availability of a wide selection of medications. If medical attention is required, the instructions shall state this, including its urgency.

<a id="echa-sds-4-1"></a>
### 4.1 Description of first aid measures

Text Annex II

4.1.1.First aid instructions shall be provided by relevant routes of exposure. Subdivisions shall be used to indicate the procedure for each route, such as inhalation, skin, eye and ingestion.

4.1.2.Advice shall be provided as to whether:

(a) immediate medical attention is required and if delayed effects can be expected after exposure;

(b) movement of the exposed individual from the area to fresh air is recommended;

(c) removal and handling of clothing and shoes from the individual is recommended; and

(d) personal protective equipment for first aid responders is recommended.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   68 Ingredients required to be listed according to the Detergents Regulation can be displayed under subsection 3.2. of the SDS, providing that these are clearly distinguished from each other by means of suitable subheadings indicating to which piece of legislation these apply. For more information see: https://ec.europa.eu/growth/sectors/chemicals/specific-chemicals_en


<a id="echa-s4-page-58"></a>
**ECHA printed page 58** — [original PDF page 58](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=58)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 58](page_images/ECHA_2020_page_058.jpg)

The information in this subsection may be structured as follows:

4.1 Description of first aid measures

- general notes

- following inhalation

- following skin contact

- following eye contact

- following ingestion

- self-protection of the first aider

<a id="echa-sds-4-2"></a>
### 4.2 Most important symptoms and effects, both acute and delayed

Text Annex II

Briefly summarised information shall be provided on the most important symptoms and effects, both acute and delayed, from exposure.

It should be noted that this subsection is for symptoms and effects - treatments are to be described in subsection 4.3.

<a id="echa-sds-4-3"></a>
### 4.3 Indication of any immediate medical attention and special treatment needed

Text Annex II

Where appropriate, information shall be provided on clinical testing and medical monitoring for delayed effects, specific details on antidotes (where they are known) and contraindications.

For some substances or mixtures, it may be important to emphasise that special means to provide specific and immediate treatment shall be available at the workplace.

It should be noted that (as indicated in the legal text introducing Section 4 as a whole) the initial care must be described in such a way that it can be understood and given by an untrained responder and that if medical attention is required this must be explicitly stated

Where it appears to be necessary to provide specific information for the doctor (e.g. specific antidote treatment, positive airway pressure, prohibition of certain drugs, eating, drinking or smoking, etc.) this information may be given under a heading such as “Notes for the doctor” (symptoms, hazards, treatment). The information provided under this heading may contain special medical terms which may be difficult to understand for non-medical personnel. The information must be accurate and thus has to be provided by experts or using expert knowledge.


<a id="echa-s4-page-59"></a>
**ECHA printed page 59** — [original PDF page 59](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=59)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 59](page_images/ECHA_2020_page_059.jpg)

Although not a specific requirement it may also be indicated whether any recommendations for specific actions or treatments can or cannot be carried out by first aiders as well as by medical doctors.


---

<a id="s5"></a>


# 3.5 SDS SECTION 5 — Firefighting measures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s5-page-59"></a>
**ECHA printed page 59** — [original PDF page 59](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=59)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 59](page_images/ECHA_2020_page_059.jpg)

3.5 SDS SECTION 5: Firefighting measures

Text Annex II

This section of the safety data sheet shall describe the requirements for fighting a fire caused by the substance or mixture, or arising in its vicinity.

<a id="echa-sds-5-1"></a>
### 5.1 Extinguishing media

Text Annex II

Suitable extinguishing media:

Information shall be provided on the appropriate extinguishing media.

Unsuitable extinguishing media:

Indications shall be given whether any extinguishing media are inappropriate for a particular situation involving the substance or mixture (e.g. avoid high pressure media which could cause the formation of a potentially explosible dust-air mixture).

Unsuitable extinguishing media are extinguishing media which must not be used for safety reasons including media that may cause chemical or physical reactions resulting in an additional potential hazard. For example, in the presence of substances which in contact with water emit flammable or toxic gases (e.g. Calcium carbide reacts with water to form Ethyne (Acetylene), an extremely flammable gas, which could result in an explosion).

<a id="echa-sds-5-2"></a>
### 5.2 Special hazards arising from the substance or mixture

Text Annex II

Information shall be provided on hazards that may arise from the substance or mixture, like hazardous combustion products that form when the substance or mixture burns, such as “may produce toxic fumes of carbon monoxide if burning” or “produces oxides of sulphur and nitrogen on combustion”.

This subsection includes information about any specific hazards arising from the chemical (e.g. nature of any hazardous combustion products or vapour cloud explosion risks.)

<a id="echa-sds-5-3"></a>
### 5.3 Advice for firefighters


<a id="echa-s5-page-60"></a>
**ECHA printed page 60** — [original PDF page 60](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=60)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 60](page_images/ECHA_2020_page_060.jpg)

Text Annex II

Advice shall be provided on any protective actions to be taken during firefighting, such as “keep containers cool with water spray”, and on special protective equipment for firefighters, such as boots, overalls, gloves, eye and face protection and breathing apparatus.

It can be emphasized that no chemical protective clothing will afford protection against all chemicals. Depending upon the respective hazards of substances, levels of protection advised can be divided into three categories.

- Self-Contained Breathing Apparatus (SCBA) with chemical resistant gloves.

- SCBA with a chemical protection suit only where personal (close) contact is likely.

- SCBA with gas-tight suit when close proximity to the substance or its vapours is likely.

The gas-tight suit represents the highest level of chemical protective clothing. Such suits may be manufactured from neoprene, vinyl rubber or other materials and are used with SCBA. Protection will be afforded from many chemicals but not all. If in any doubt, specialist advice should be sought.

For incidents involving deeply refrigerated and many other liquefied gases where contact will cause frostbite and severe damage to eyes, thermally insulated undergarments including thick textile or leather gloves, and eye protection should be worn. Similarly, for incidents involving significant heat radiation, it is recommended that heat reflective suits be used.

Fire fighter's clothing conforming to European standard EN469 provides a basic level of protection for chemical incidents and includes helmets, protective boots and gloves. Clothing not conforming to EN469 may not be suitable in any chemical incident.

Additionally, one may include recommended measures for isolating the area affected, for limiting damage in the event of fire or for the disposal of residues of extinguishing media.

When compiling this section, it should be considered whether spillage and fire-fighting water could cause pollution of watercourses. If so, information should be given on how to minimize their impact on the environment.

An example of how the structure of this section could look like is given below:

SECTION 5: Firefighting measures

5.1 Extinguishing media:

Suitable extinguishing media:

Unsuitable extinguishing media:

5.2 Special hazards arising from the substance or mixture

Hazardous combustion products:

5.3 Advice for firefighters


---

<a id="s6"></a>


# 3.6 SDS SECTION 6 — Accidental release measures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s6-page-61"></a>
**ECHA printed page 61** — [original PDF page 61](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=61)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 61](page_images/ECHA_2020_page_061.jpg)

3.6 SDS SECTION 6: Accidental release measures

Text Annex II

This section of the safety data sheet shall recommend the appropriate response to spills, leaks, or releases, to prevent or minimise the adverse effects on persons, property and the environment. It shall distinguish between responses to large and small spills, in cases where the spill volume has a significant impact on the hazard. If the procedures for containment and recovery indicate that different practices are required, these shall be indicated in the safety data sheet.

[The text above is considered as needing no further explanation].

<a id="echa-sds-6-1"></a>
### 6.1 Personal precautions, protective equipment and emergency procedures

Text Annex II

6.1.1. For non-emergency personnel

Advice shall be provided related to accidental spills and release of the substance or mixture such as:

(a) the wearing of suitable protective equipment (including personal protective equipment referred to under Section 8 of the safety data sheet) to prevent any contamination of skin, eyes and personal clothing;

(b) removal of ignition sources, provision of sufficient ventilation, control of dust; and

(c) emergency procedures such as the need to evacuate the danger area or to consult an expert.

6.1.2. For emergency responders

Advice shall be provided related to suitable fabric for personal protective clothing (such as “appropriate: Butylene”; “not appropriate: PVC”).

[The text above is considered as needing no further explanation].

<a id="echa-sds-6-2"></a>
### 6.2 Environmental precautions

Text Annex II

Advice shall be provided on any environmental precautions to be taken related to accidental spills and release of the substance or mixture, such as keeping away from drains, surface and ground water.

[The text above is considered as needing no further explanation].


<a id="echa-s6-page-62"></a>
**ECHA printed page 62** — [original PDF page 62](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=62)

<a id="echa-sds-6-3"></a>
### 6.3 Methods and material for containment and cleaning up

Text Annex II

6.3.1. Appropriate advice shall be provided on how to contain a spill. Appropriate containment techniques may include any of the following:

(a) bunding, covering of drains;

(b) capping procedures.

6.3.2. Appropriate advice shall be provided on how to clean-up a spill. Appropriate clean-up procedures may include any of the following:

(a ) neutralisation techniques;

(b) decontamination techniques;

(c) adsorbent materials;

(d) cleaning techniques;

(e) vacuuming techniques;

(f) equipment required for containment/clean-up (include the use of non-sparking tools and equipment where applicable).

6.3.3. Any other information shall be provided relating to spills and releases, including advice on inappropriate containment or clean-up techniques, such as by indications like “never use …”.

Note that the list of techniques is not exhaustive, notably absorbents may be used as well as adsorbents.

Also note that “bunding”69 and “capping”70 here have the meanings as defined in Annex 4 of the GHS71.

Some examples of the kind of recommendations that could be included in this subsection are:

- Wet clean or vacuum up solids.

- Don't use a brush or compressed air for cleaning surfaces or clothing.

- Clear spills immediately

<a id="echa-sds-6-4"></a>
### 6.4 Reference to other sections

69 “A bund is a provision of liquid collection facilities which, in the event of any leak or spillage from tanks or pipe work, will capture well in excess of the volume of liquids held, e.g. an embankment.  Bunded areas should drain to a capture tank which should have facilities for water/oil separation.”

70 “i.e. providing a cover or protection (e.g. to prevent damage or spillage).”

71 Globally Harmonized Classification and Labelling system of Chemicals (GHS),  Fifth revised edition 2013.  Annex 4 – Guidance on the compilation of safety data sheets, page 415; See: http://www.unece.org/trans/danger/publi/ghs/ghs_rev05/05files_e.html.


<a id="echa-s6-page-63"></a>
**ECHA printed page 63** — [original PDF page 63](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=63)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 63](page_images/ECHA_2020_page_063.jpg)

Text Annex II

If appropriate Sections 8 and 13 shall be referred to.

It should be noted that the only sections for which (cross)-references are required here (and then only if appropriate) are sections 8 and 13 – i.e. cross-references should be made to information on exposure control and personal protection and disposal considerations, respectively, which are relevant to potential accidental release. The intention here is to avoid duplication of information – not to require such duplication. Any additional references to other sections that may be made here are not a requirement of the Regulation.

An example of how the structure of this section could look is given below72:

SECTION 6: Accidental release measures

6.1 Personal precautions, protective equipment and emergency procedures

6.1.1 For non-emergency personnel

Protective equipment:

Emergency procedures:

6.1.2 For emergency responders

6.2 Environmental precautions:

6.3 Methods and material for containment and cleaning up

6.3.1 For containment:

6.3.2 For cleaning up:

6.3.3 Other information:

6.4 Reference to other sections


---

<a id="s7"></a>


# 3.7 SDS SECTION 7 — Handling and storage

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s7-page-63"></a>
**ECHA printed page 63** — [original PDF page 63](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=63)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 63](page_images/ECHA_2020_page_063.jpg)

3.7 SDS SECTION 7: Handling and storage

Text Annex II

72 Note that additional numbering and sub-structuring below the subsection level is not a legal requirement.


<a id="echa-s7-page-64"></a>
**ECHA printed page 64** — [original PDF page 64](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=64)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 64](page_images/ECHA_2020_page_064.jpg)

This section of the safety data sheet shall provide advice on safe handling practices. It shall emphasise precautions that are appropriate to the identified uses referred to under subsection 1.2 and to the unique properties of the substance or mixture.

Information in this section of the safety data sheet shall relate to the protection of human health, safety and the environment. It shall assist the employer in devising suitable working procedures and organisational measures according to Article 5 of Directive 98/24/EC and Article 5 of Directive 2004/37/EC.

Where a chemical safety report is required, the information in this section of the safety data sheet shall be consistent with the information given for the identified uses in the chemical safety report and the exposure scenarios showing control of risk from the chemical safety report set out in the annex to the safety data sheet.

In addition to information given in this section, relevant information may also be found in Section 8.

[The text above is considered as needing no further explanation]

<a id="echa-sds-7-1"></a>
### 7.1 Precautions for safe handling

Text Annex II

7.1.1. Recommendations shall be specified to:

(a) allow safe handling of the substance or mixture, such as containment and measures to prevent fire as well as aerosol and dust generation;

(b) prevent handling of incompatible substances or mixtures;

(c) draw attention to operations and conditions which create new risks by altering the properties of the substance or mixture, and to appropriate countermeasures; and

(d) reduce the release of the substance or mixture to the environment, such as avoiding spills or keeping away from drains.

7.1.2. Advice on general occupational hygiene shall be provided, such as:

(a) not to eat, drink and smoke in work areas;

(b) to wash hands after use; and

(c) to remove contaminated clothing and protective equipment before entering eating areas.

This subsection should provide information concerning protective measures for safe handling and recommended technical measures such as containment, measures to prevent aerosol and dust generation and fire, measures required to protect the environment (e.g. use of filters or scrubbers on exhaust ventilation, use in a bonded area, measures for collection and disposal of spillages, etc.) and any specific requirements or rules relating to the substance or mixture (e.g. procedures or equipment which are prohibited or recommended). If possible, give a brief description of the measure.

An example of how the structure of this subsection could look is given below:


<a id="echa-s7-page-65"></a>
**ECHA printed page 65** — [original PDF page 65](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=65)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 65](page_images/ECHA_2020_page_065.jpg)

SECTION 7: Handling and storage

7.1 Precautions for safe handling

Protective measures:

Measures to prevent fire:

Measures to prevent aerosol and dust generation:

Measures to protect the environment:

Advice on general occupational hygiene:

<a id="echa-sds-7-2"></a>
### 7.2 Conditions for safe storage, including any incompatibilities

Text Annex II

The advice provided shall be consistent with the physical and chemical properties described in Section 9 of the safety data sheet. If relevant, advice shall be provided on specific storage requirements including:

(a) How to manage risks associated with:

(i) explosive atmospheres;

(ii) corrosive conditions;

(iii) flammability hazards;

(iv) incompatible substances or mixtures;

(v) evaporative conditions; and

(vi) potential ignition sources (including electrical equipment).

(b) How to control the effects of:

(i) weather conditions;

(ii) ambient pressure;

(iii) temperature;

(iv) sunlight;

(v) humidity; and

(vi) vibration.

(c) How to maintain the integrity of the substance or mixture by the use of:

(i) stabilisers; and


<a id="echa-s7-page-66"></a>
**ECHA printed page 66** — [original PDF page 66](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=66)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 66](page_images/ECHA_2020_page_066.jpg)

(ii) antioxidants.

(d) Other advice including:

(i) ventilation requirements;

(ii) specific designs for storage rooms or vessels (including retention walls and ventilation);

(iii) quantity limits under storage conditions (if relevant); and

(iv) packaging compatibilities.

This subsection should, if relevant, specify the conditions for safe storage such as:

- specific design for storage rooms or vessels (including retention walls and ventilation)

- incompatible materials

- conditions of storage (humidity limit/range, light, inert gas, etc.)

- special electrical equipment and prevention of static electricity

The subsection should also include advice - if relevant - on quantity limits under storage conditions (or e.g. an indication of threshold quantities above which the Seveso III Directive73 would apply to the substance or substance class). This subsection should further indicate any special requirements such as the type of material used in the packaging/containers of the substance or mixture.

It should be noted that in the context of the content of information to be given in subsection 7.2 the term “incompatibilities” should be taken to include incompatibilities of the substance or mixture with packaging materials with which these are likely to come into contact.

Some suppliers may choose to indicate here information about national storage class systems. The storage class is derived from the classification of the pure substance or mixture - the packaging should not be taken into account for this purpose.

It is not recommended to add quality-related storage information to this subsection. If this information is added, it should be clearly indicated that it is quality and not safety related information.

An example of how the structure of this subsection could look is given below:

7.2 Conditions for safe storage, including any incompatibilities

Technical measures and storage conditions:

Packaging materials:

Requirements for storage rooms and vessels:

73 In 2012 Seveso-III (Directive 2012/18/EU) was adopted taking into account, amongst others, the changes in the Union legislation on the classification of chemicals and increased rights for citizens to access information and justice: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32012L0018


<a id="echa-s7-page-67"></a>
**ECHA printed page 67** — [original PDF page 67](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=67)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 67](page_images/ECHA_2020_page_067.jpg)

Storage class:

Further information on storage conditions:

<a id="echa-sds-7-3"></a>
### 7.3 Specific end use(s)

Text Annex II

For substances and mixtures designed for specific end use(s), recommendations shall relate to the identified use(s) referred to in subsection 1.2 and be detailed and operational. If an exposure scenario is attached, reference to it may be made or the information as required in subsections 7.1 and 7.2 shall be provided. If an actor in the supply chain has carried out a chemical safety assessment for the mixture, it is sufficient that the safety data sheet and the exposure scenarios are consistent with the chemical safety report for the mixture, rather than with the chemical safety reports for each substance in the mixture. If industry- or sector-specific guidance is available, detailed reference to it (including source and issuing date) may be made.

For biocidal products, as an example of substances and mixtures designed for specific end uses, in addition to identified uses listed in subsection 1.2 which must be listed, any additional uses for which the product has been authorised may be indicated (e.g. wood preservation, disinfection, slime control, in-can preservation, etc.). Additional reference may be made to any technical fact sheet containing further information concerning the quantity to be applied and the handling instructions for any kind of use.

If the SDS has corresponding exposure scenarios attached, which give the necessary recommendations relating to safe handling and use, and reference is made to it there is no need to use this subsection for detailed recommendations for specific end uses.

For substances for which exposure scenarios are not required (e.g. substances  for which no CSA is required  because these are not subject to registration at ≥ 10 t/a74),  this section may additionally be used to include similar or equivalent information to that which would otherwise be given more fully in an exposure scenario. This section can also be of potential use in the case of SDSs for mixtures for which no consolidating document equivalent to an “exposure scenario for the mixture” is attached.

An example of how the structure of this subsection could look is given below:

7.3 Specific end use(s):

Recommendations:

Industrial sector specific solutions:

74 Note: Even for substances at > 10 t/a for which a CSA is required there are further criteria according to Article 14

(4) before an exposure scenario is required, however these criteria will apply for most substances for which an SDS is

required.


---

<a id="s8"></a>


# 3.8 SDS SECTION 8 — Exposure controls/personal protection

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s8-page-68"></a>
**ECHA printed page 68** — [original PDF page 68](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=68)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 68](page_images/ECHA_2020_page_068.jpg)

3.8 SDS SECTION 8: Exposure controls/personal protection

Note: for those compiling SDSs for "special mixtures"75, additional information on how to adapt Section 8 is given in Annex 2.

Text Annex II

This section of the safety data sheet shall describe the applicable occupational exposure limits and necessary risk management measures.

Where a chemical safety report is required, the information in this section of the safety data sheet shall be consistent with the information given for the identified uses in the chemical safety report and the exposure scenarios showing control of risk from the chemical safety report set out in the annex to the safety data sheet.

<a id="echa-sds-8-1"></a>
### 8.1 Control parameters76

Text Annex II

8.1.1. Where available, the following national limit values, including the legal basis of each of them, which are currently applicable in the Member State in which the safety data sheet is being provided shall be listed for the substance or for each of the substances in the mixture. When listing occupational exposure limit values, the chemical identity as specified in section 3 shall be used:

8.1.1.1. the national occupational exposure limit values that correspond to Union occupational exposure limit values in accordance with Directive 98/24/EC, including any notations as referred to in Article 2(3) of Commission Decision 2014/113/EU (77);

8.1.1.2. the national occupational exposure limit values that correspond to Union limit values in accordance with Directive 2004/37/EC, including any notations as referred to in Article 2(3) of Decision 2014/113/EU;

8.1.1.3. any other national occupational exposure limit values;

8.1.1.4. the national biological limit values that correspond to Union biological limit values in accordance with Directive 98/24/EC, including any notations as referred to in Article 2(3) of Decision 2014/113/EU;

8.1.1.5. any other national biological limit values.

8.1.2. Information on currently recommended monitoring procedures shall be provided at least for the most relevant substances.

75 Special mixtures are those in which a common feature is that the properties of the constituent substances are modulated by their inclusion within the matrix of the mixture. The availability for exposure of the constituent substances and their potential to express any ecotoxicological/toxic properties may be affected following their inclusion in the matrix.

76 PLEASE NOTE THAT WHERE FOOTNOTES ARE GIVEN AS PART OF THE QUOTED ORIGINAL LEGAL TEXT THESE ARE REPRODUCED (IN ITALIC FONT) IN THEIR ORIGINAL FORM, EVEN WHERE UPDATES TO THE DOCUMENTS CITED MAY ALREADY BE AVAILABLE.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 77 Commission Decision 2014/113/EU of 3 March 2014 on setting up a Scientific Committee on Occupational Exposure Limits for Chemical Agents and repealing Decision 95/320/EC (OJ L 62, 4.3.2014, p.18).


<a id="echa-s8-page-69"></a>
**ECHA printed page 69** — [original PDF page 69](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=69)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 69](page_images/ECHA_2020_page_069.jpg)

8.1.3. If air contaminants are formed when using the substance or mixture as intended, applicable occupational exposure limit values and/or biological limit values for these shall also be listed.

8.1.4. Where a chemical safety report is required or where a DNEL as referred to in Section 1.4 of Annex I or a PNEC as referred to in Section 3.3 of Annex I is available, the relevant DNELs and PNECs for the substance shall be given for the exposure scenarios from the chemical safety report set out in the annex to the safety data sheet.

8.1.5. Where a control banding approach is used to decide on risk management measures in relation to specific uses, sufficient detail shall be given to enable effective management of the risk. The context and limitations of the specific control banding recommendation shall be made clear.

Occupational exposure limit values

This subsection should include currently applicable specific control parameters including occupational exposure limit (OEL) values and/or biological limit values. Values must be given for the Member State where the substance or mixture is placed on the market. While a supplier might find it practical to provide OELs for multiple Member States, there are national requirements, such as those in subsections 1.1, 1.4 and 15.1 as well as the national language requirement, meaning that the safety data sheet must be specific to a Member State.

It should be noted that although for Section 3 of the SDS the requirement is clearly to list substances with a Union limit value78, for Section 8 the requirement is that the national occupational exposure limit values that correspond to Union OELs must be listed and that even in the absence of a Union OEL any relevant national limit must be listed (see points 8.1.1.1 + 8.1.1.2. and 8.1.1.3. of the legal text quoted above, respectively). In cases where an Indicative Occupational Exposure Limit Value (IOELV) has been established by the European Commission but has not yet been transposed into individual Member State national law it is desirable to give the Union value, although not specifically required.

The GESTIS International Limit values Database may be particularly useful as a source of this type of information: https://limitvalue.ifa.dguv.de/

There are also commercial databases available where this type of information is available on a subscription or other payment basis.

Information on monitoring procedures

The information in this subsection must also include the currently recommended monitoring or observation methods at least for the most relevant substances. These monitoring methods can be: personal air monitoring, room air monitoring, biological monitoring etc according to agreed standards. The specific standard should be referenced, for example:

“EN 14042:2003 Title Identifier: Workplace atmospheres. Guide for the application and use of procedures for the assessment of exposure to chemical and biological agents.”

78 See point 3.2.1 (b) of text of Annex II text above.


<a id="echa-s8-page-70"></a>
**ECHA printed page 70** — [original PDF page 70](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=70)

It should be noted that since the applicable limits and their legal basis are those of individual Member States on whose market the substance or mixture is being placed, the monitoring methods of the country for which the SDS is being provided should take precedence over those of the originating country where there is a difference in methods.

For mixtures, it should be considered that the requirement that “Information on currently recommended monitoring procedures shall be provided at least for the most relevant substances” means that it must be provided at least for those constituent substances which are required to be listed in subsection 3.2 of the SDS, if available79.

The Derived No Effect Levels (DNELs) and Predicted No Effect Concentrations (PNECs) applicable to the exposure scenarios in any required annex(es) to the SDS for a specific substance or mixture can be listed together with - and in the same way as - the OELs discussed above, or can be listed or tabled separately, depending on the supplier’s preference.

It should be noted that only the applicable DNELs, and PNECs should be listed - the others should be removed from the list as appropriate.

An example of how the required information on DNELs and PNECs in this section could be structured is given below:

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   79 For certain types of substances and mixtures (e.g. complex UVCBs) such methods may not be available.


<a id="echa-s8-page-71"></a>
**ECHA printed page 71** — [original PDF page 71](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=71)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 71](page_images/ECHA_2020_page_071.jpg)

SUBSTANCE NAME

EC number: CAS number:

DNELs

Workers Consumers

Route of exposure

Acute effect local

Acute effects systemic

Chronic effects local

Chronic effects

Acute effects local

Acute effects systemic

Chronic effects local

Chronic effects

Oral Not required

Inhalation

Dermal

Each of the cells should contain one of the following information: i) DNEL value with unit or ii) hazard identified but no DNEL available or iii)  no exposure expected, iv) no hazard identified

PNECs

Environmental protection target PNEC

Fresh water

Freshwater sediments

Marine water

Marine sediments

Food chain

Microorganisms in sewage treatment

Soil (agricultural)

Air


<a id="echa-s8-page-72"></a>
**ECHA printed page 72** — [original PDF page 72](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=72)

Each of the cells should contain one of the following information: i) PNEC value with unit or ii) hazard identified but no PNEC available or iii) no exposure expected or iv) no hazard identified


<a id="echa-s8-page-73"></a>
**ECHA printed page 73** — [original PDF page 73](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=73)

The control banding approach

According to the International Labour Organisation, Control Banding can be described as follows80:

It is a complementary approach to protecting worker health by focusing resources on exposure controls. Since it is not possible to assign a specific Occupational Exposure Limit to every chemical in use, a chemical is assigned to a "band" for control measures, based on its hazard classification according to international criteria, the amount of chemical in use, and its volatility/dustiness. The outcome is one of four recommended control strategies:

1. Employ good industrial hygiene practice

2. Use local exhaust ventilation

3. Enclose the process

4. Seek the advice of a specialist

It should be noted that use of the control banding approach is not mandatory. However, when it is used in addition to the legally required information as explained above then sufficient detail must be given to enable effective management of the risk and the context and limitations of the specific control banding recommendation must be made clear.

<a id="echa-sds-8-2"></a>
### 8.2 Exposure controls

Text Annex II

The information required in the present subsection shall be provided, unless an exposure scenario containing that information is attached to the safety data sheet.

Where the supplier has waived a test under Section 3 of Annex XI, he shall indicate the specific conditions of use relied on to justify the waiving.

Where a substance has been registered as an isolated intermediate (on-site or transported), the supplier shall indicate that this safety data sheet is consistent with the specific conditions relied on to justify the registration in accordance with Article 17 or 18.

8.2.1. Appropriate engineering controls

The description of appropriate exposure control measures shall relate to the identified use(s) of the substance or mixture as referred to in subsection 1.2. This information shall be sufficient to enable the employer to carry out an assessment of risk to the safety and health of workers arising from the presence of the substance or mixture in accordance with Articles 4 to 6 of Directive 98/24/EC and Articles 3 to 5 of Directive 2004/37/EC, where appropriate.

This information shall complement that already given under Section 7.

8.2.2. Individual protection measures, such as personal protective equipment

8.2.2.1.The information on use of personal protective equipment shall be consistent with good occupational hygiene practices and in conjunction with other control measures, including engineering controls, ventilation and isolation. Where appropriate, section 5 shall

80 See: ilo.org/legacy/english/protection/safework/ctrl_banding/whatis.htm.


<a id="echa-s8-page-74"></a>
**ECHA printed page 74** — [original PDF page 74](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=74)

be referred to for specific fire/chemical personal protective equipment advice.

8.2.2.2. Taking into account Regulation (EU) 2016/425 of the European Parliament and of the Council (81)and referring to the appropriate CEN standards, detailed specifications shall be given on which equipment will provide adequate and suitable protection, including:

(a) Eye/face protection

The type of eye/face protection equipment required shall be specified based on the hazard of the substance or mixture and potential for contact, such as safety glasses, safety goggles, face shield.

(b)Skin protection

(i) Hand protection

The type of gloves to be worn when handling the substance or mixture shall be clearly specified based on the hazard of the substance or mixture and potential for contact and with regard to the amount and duration of dermal exposure, including:

- the type of material and its thickness, - the typical or minimum breakthrough times of the glove material.

If necessary any additional hand protection measures shall be indicated.

(ii) Other

If it is necessary to protect a part of the body other than the hands, the type and quality of protection equipment required shall be specified, such as gauntlets, boots, bodysuit based on the hazards associated with the substance or mixture and the potential for contact.

If necessary, any additional skin protection measures and specific hygiene measures shall be indicated.

(c) Respiratory protection

For gases, vapours, mist or dust, the type of protective equipment to be used shall be specified based on the hazard and potential for exposure, including air-purifying respirators, specifying the proper purifying element (cartridge or canister), the adequate particulate filters and the adequate masks, or self-contained breathing apparatus.

(d) Thermal hazards

When specifying protective equipment to be worn for materials that represent a thermal hazard, special consideration shall be given to the construction of the personal protective equipment.

8.2.3. Environmental exposure controls

The information required by the employer to fulfil his commitments under Union environmental protection legislation shall be specified.

Where a chemical safety report is required, a summary of the risk management measures that

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   81 Regulation (EU) 2016/425 of the European Parliament and of the Council of 9 March 2016 on personal protective equipment and repealing Council Directive 89/686/EEC (OJ L 81, 31.3.2016, p. 51).


<a id="echa-s8-page-75"></a>
**ECHA printed page 75** — [original PDF page 75](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=75)

adequately control exposure of the environment to the substance shall be given for the exposure scenarios set out in the annex to the safety data sheet.

“Exposure control” should here be taken to mean all protective measures and precautions to be taken during use of the substance or mixture in order to minimise worker and environmental exposure. Therefore any information available concerning workplace exposure should be indicated in this subsection, unless it is included in an attached exposure scenario in which case reference to it should be made.

Where design regulations concerning technical facilities are required for exposure control in addition to the guidance provided in Section 7.” Handling and storage” these should be amended in the form of "Additional guidance on the design of technical facilities".

This subsection can include cross-references to the information provided in Section 7 of the SDSs “Handling and storage” if appropriate.

Appropriate engineering controls (point 8.2.1 in legal text above)

Information should be given in subsection 8.2 of the SDS which aids an employer in developing the required risk management and risk reduction measures according to his obligations under Directives 98/24/EC and 2004/37/EC82 concerning the design of appropriate working methods and technical control facilities as well as the use of suitable work equipment and materials, based on the identified uses (subsection 1.2 of the SDS). These include, for example the implementation of means of collective protection at the hazard source, and of individual protective measures including the provision of personal protective equipment.

Suitable information on these measures must be provided to enable a proper risk assessment to be carried out under Article 4 of Directive 98/24/EC. This information should be consistent with that given in subsection 7.1 of the SDS. If one or more exposure scenario(s) is/are attached to the SDS for a substance then the information given should also be consistent with that given in the ESs. In the case of mixtures the information given should reflect a consolidation of the information for components.

Personal Protection (point 8.2.2 in legal text above)

It is a requirement that detailed specifications of equipment which provides adequate and suitable protection be given where personal protection is needed, taking into account Regulation (EU) 2016/425 of the European Parliament and of the Council 83 and referring to relevant CEN standards.

The equipment must be specified in sufficient detail (e.g. in terms of kind, type and class) to ensure that it will provide adequate and suitable protection during the foreseen uses.

A useful source of such information may be the suppliers or manufacturers of protection

82 Corrigendum to Directive 2004/37/EC of the European Parliament and of the Council of 29 April 2004 on the protection of workers from the risks related to exposure to carcinogens or mutagens at work (Sixth individual

Directive within the meaning of Article 16(1) of Council Directive 89/391/EEC) (codified version) OJ L 229, 29.6.2004, p. 23.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 83 Regulation (EU) 2016/425 of the European Parliament and of the Council of 9 March 2016 on personal protective equipment and repealing Council Directive 89/686/EEC (OJ L 81, 31.3.2016, p. 51).


<a id="echa-s8-page-76"></a>
**ECHA printed page 76** — [original PDF page 76](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=76)

equipment who may have help-lines or websites available.

Note that detailed requirements given in the legal text are not re-quoted in full below unless further clarification is being given.

Eye/face protection

The type of eye protection equipment required, such as: safety glasses, safety goggles, face- shields, must be specified based on the hazard of the substance or mixture and potential for contact.

Skin protection

Information on skin protection may be sub-divided into (i) “hand protection” and ii) “other” (along the lines suggested by the legal text, which requires both to be included if necessary). In this context it should be noted that “skin, other” is covered by “body protection” as a subsection of the information on skin protection, unless otherwise specified.

Again the equipment must be specified based on hazard and potential for contact and potential duration and amount of exposure.

It should be noted that when calculating the maximum time that skin protection (e.g. gloves) can be worn it is necessary to take into account the maximum time of exposure to the relevant substance(s) and not simply the total working time.

In some cases, reference to gauntlets (i.e. gloves with an extended cuff covering part of the forearm) may need to be included. Note that in this case, since protection is additionally given to a part of the body other than the hand itself, this would be under the “other” sub-division of this subsection.

Respiratory protection

Specify the type of protective equipment to be used, such as self-contained breathing apparatus or respirator, including the type of filter needed. It is recommended that information on the assigned protection factor (APF) that should be used in the particular scenario be given, if available. It should be noted that filter masks may be of limited use in cases of high or unknown exposure, and self-contained breathing apparatus should be used only under certain conditions.

Environmental Exposure Controls (point 8.2.3 in legal text)

This subsection includes the information required by the employer to fulfil his obligations under environmental protection legislation. If appropriate, a reference to SECTION 6 of the SDS may be included84.

An example of how the structure of this subsection could look is given below85:

84 Note that the measures to be described under subsection 8.2 are those to be implemented under normal operation, whereas those in SECTION 6 are for accidental release. These may therefore be very different.

85 Please note that numbering below the level of the subsection 8.2 is in the example is not a legal requirement – it has been inserted for clarity. See also note in chapter 2.6 of this guidance on numbering of subsections.


<a id="echa-s8-page-77"></a>
**ECHA printed page 77** — [original PDF page 77](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=77)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 77](page_images/ECHA_2020_page_077.jpg)

8.2 Exposure controls

8.2.1 Appropriate engineering controls:

Substance/mixture related measures to prevent exposure during identified uses:

Structural measures to prevent exposure:

Organisational measures to prevent exposure:

Technical measures to prevent exposure:

8.2.2 Personal protection equipment:

8.2.2.1 Eye and face protection:

8.2.2.2 Skin protection:

Hand protection:

Other skin protection:

8.2.2.3 Respiratory protection:

8.2.2.4 Thermal hazards:

8.2.3 Environmental exposure controls:

Substance/mixture related measures to prevent exposure:

Instruction measures to prevent exposure:

Organisational measures to prevent exposure:

Technical measures to prevent exposure:


---

<a id="s9"></a>


# 3.9 SDS SECTION 9 — Physical and chemical properties

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s9-page-77"></a>
**ECHA printed page 77** — [original PDF page 77](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=77)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 77](page_images/ECHA_2020_page_077.jpg)

3.9 SDS SECTION 9: Physical and chemical properties

Text Annex II

This section of the safety data sheet shall describe the empirical data relating to the substance or mixture, if relevant. Article 8(2) of Regulation (EC) No 1272/2008 shall apply.

To enable proper control measures to be taken, all relevant information on the substance or mixture shall be provided. The information in this section shall be consistent with the information provided in the registration or in the chemical safety report, where required, and with the classification of the substance or mixture.

In the case of a mixture, where information does not apply to the mixture as a whole, the entries shall clearly indicate to which substance in the mixture the data apply.

Reported properties shall be clearly identified and reported in the appropriate measurement units. The method of determination shall be provided, including measurement and reference conditions, if relevant for the interpretation of the numerical value. Unless specified otherwise, standard


<a id="echa-s9-page-78"></a>
**ECHA printed page 78** — [original PDF page 78](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=78)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 78](page_images/ECHA_2020_page_078.jpg)

conditions of temperature and pressure are 20 °C and 101,3 kPa, respectively.

The properties listed in subsections 9.1 and 9.2 may be presented in a form of a list. Within the subsections, the order of listing the properties may be different if deemed appropriate.

It is a primary requirement that the information in this section be consistent with the information provided in the registration dossier and in the CSR where required, and also with the classification of the substance or mixture – it should therefore support any transport classification given in Section 14 as well as the classification and labelling information in Section 2.

In the context of deciding whether specific information should appear in Section 9 or Section 10 of the SDS, historically the practice has been for Section 9 to contain numerical (measured) values for physical and chemical properties, whereas Section 10 should give a description of the intrinsic (qualitative) properties (including potentially hazardous interactions with other substances) that result from (or are related to) these values.

The requirement that “this section of the SDS shall describe the empirical data of the substance or mixture, if relevant” should be interpreted to mean that values which are likely to be within a range relevant to the classification and the hazards of a substance or mixture should be given in this section. Thus, for example, the flash point of a volatile organic liquid that is likely to be classified as flammable should be given, whereas there is no need to determine this for a high melting-point solid. Where any statement is made to indicate that a particular property does not apply this should be based on a clear lack of relevance, the reason for which should be stated if not obvious, and not on the absence of information. A clear differentiation should also be made between cases where no information is available to the compiler (e.g. “no information available because it is not practical to measure”), and cases where actual negative test results are available.

The data should preferably have been generated in accordance with the test methods referred to in the REACH or CLP Regulations, transport provisions or international principles or procedures for the validation of information, so as to ensure quality and comparability of the results and consistency with other requirements at international or Union level. The information in this section must be consistent with the information provided in the registration dossier and in the chemical safety report, where required, and with the classification of the substance or mixture.

As specified in the relevant test methods, critical information such as test temperature and methods used, which affect the value of physical-chemical properties and safety characteristics, should be provided for all test results and, if available, for data acquired from the literature.

For mixtures, where information does not apply to the mixture as a whole the entries must clearly indicate to which substance in the mixture the data apply.

<a id="echa-sds-9-1"></a>
### 9.1 Information on basic physical and chemical properties

Text Annex II

Each safety data sheet shall include the properties mentioned below. If it is stated that a particular property does not apply or if information on a particular property is not available, this shall be


<a id="echa-s9-page-79"></a>
**ECHA printed page 79** — [original PDF page 79](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=79)

clearly indicated, giving the reasons where possible.

(a) Physical state

The physical state (gas, liquid or solid) shall generally be indicated at standard conditions of temperature and pressure.

The definitions of the terms gas, liquid and solid, as provided in Section 1.0 of Annex I to Regulation (EC) No 1272/2008, shall apply.

(b) Colour

The colour of the substance or mixture as supplied shall be indicated.

In cases where one safety data sheet is used to cover variants of a mixture which may have different colours, the term 'various' can be used to describe the colour.

(c) Odour

A qualitative description of the odour shall be given if it is well-known or described in the literature.

If available, the odour threshold shall be indicated (qualitatively or quantitatively).

(d) Melting point/freezing point

Does not apply to gases.

Melting point and freezing point shall be indicated at standard pressure.

In case the melting point is above the measuring range of the method, it shall be indicated up to which temperature no melting point was observed.

If decomposition or sublimation occur prior to or during melting, it shall be indicated.

As regards waxes and pastes, the softening point/range may be indicated instead of the melting point and freezing point.

As regards mixtures, if it is technically not possible to determine the melting point/freezing point, this shall be indicated.

(e) Boiling point or initial boiling point and boiling range

These properties shall be indicated at standard pressure. A boiling point at lower pressure might however be indicated, in case the boiling point is very high or in case decomposition occurs before boiling at standard pressure.

If the boiling point is above the measuring range of the method, the temperature up to which no boiling point was observed shall be indicated.

If decomposition occurs prior to or during boiling, this shall be indicated.

As regards mixtures, if it is technically not possible to determine their boiling point or range, this shall be indicated; in that case, the boiling point of the lowest boiling ingredient shall also be indicated.

(f) Flammability

Applies to gases, liquids and solids.


<a id="echa-s9-page-80"></a>
**ECHA printed page 80** — [original PDF page 80](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=80)

It shall be indicated whether the substance or mixture is ignitable, i.e. capable of catching fire or being set on fire, even if not classified for flammability.

If available and appropriate, further information may be indicated, such as whether the effect of ignition is other than a normal combustion (e.g. an explosion) and the ignitability under non-standard conditions.

More specific information on the flammability may be indicated based on the respective hazard classification. The information provided in subsection 9.2.1 shall not be provided in this point.

(g) Lower and upper explosion limit

Do not apply to solids.

As regards flammable liquids, at least the lower explosion limit shall be indicated. If the flash point is approximately -25 °C or higher, it may not be possible to determine the upper explosion limit at standard temperature; in that case, it is recommended to indicate the upper explosion limit at a higher temperature. If the flash point is higher than 20 °C, it may not be possible to determine the lower or the upper explosion limit at standard temperature; in that case, it is recommended to indicate both the lower and the upper explosion limits at a higher temperature.

(h) Flash point

Does not apply to gases, aerosols and solids.

For mixtures, a value for the mixture shall be indicated, if available. Otherwise, the flash point(s) of the substance(s) with the lowest flash point(s) shall be indicated.

(i) Auto-ignition temperature

Only applies to gases and liquids.

As regards mixtures the auto-ignition temperature for the mixture shall be indicated, if available. If the value for the mixture is not available, the auto-ignition temperature(s) of the ingredients with the lowest auto-ignition temperature(s) shall be indicated.

(j) Decomposition temperature

Only applies to self-reactive substances and mixtures, organic peroxides, and other substances and mixtures that may decompose.

The self-accelerating decomposition temperature (SADT) and the volume to which it applies, or the decomposition onset temperature shall be indicated.

It shall be indicated whether the temperature given is the SADT or the decomposition onset temperature.

If no decomposition was observed, it shall be indicated up to which temperature no decomposition was observed, e.g. ‘no decomposition observed up to x °C’.

(k) pH

Does not apply to gases.

The pH of the substance or mixture as supplied, or where the product is a solid, the pH of an aqueous liquid or solution at a given concentration, shall be indicated.


<a id="echa-s9-page-81"></a>
**ECHA printed page 81** — [original PDF page 81](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=81)

The concentration of the test substance or mixture in water shall be indicated.

(l) Kinematic viscosity

Only applies to liquids.

The measurement unit shall be mm2/s.

For non-Newtonian liquids, the thixotropic or rheopexic behaviour shall be indicated.

(m)  Solubility

Solubility shall generally be indicated at standard temperature.

The solubility in water shall be indicated.

The solubility in other polar and non-polar solvents may also be included.

As regards mixtures, it shall be indicated if the mixture is fully or only partially soluble in or miscible with water or other solvent.

As regards nanoforms, the dissolution rate in water or in other relevant biological or environmental media shall be indicated in addition to the water solubility.

(n) Partition coefficient n-octanol/water (log value)

Does not apply to inorganic and ionic liquids and does not generally apply to mixtures.

It shall be indicated whether the reported value is based on testing or on calculation.

As regards nanoforms of a substance for which the n-octanol/water partition coefficient does not apply, the dispersion stability in different media shall be indicated.

(o) Vapour pressure

Vapour pressure shall generally be indicated at standard temperature.

As regards volatile fluids, the vapour pressure at 50 °C shall also be indicated.

In cases where one safety data sheet is used to cover variants of a liquid mixture or liquefied gas mixture, a range for the vapour pressure shall be indicated.

As regards liquid mixtures or liquefied gas mixtures, a range for the vapour pressure or at least the vapour pressure of the most volatile ingredient(s), where the vapour pressure of the mixture is predominantly determined by that or those ingredient(s), shall be indicated.

The saturated vapour concentration may also be indicated.

(p) Density and/or relative density

Only apply to liquids and solids.

Density and relative density shall generally be indicated at standard conditions of temperature and pressure.

The absolute density and/or the relative density based on water at 4 °C as reference (also referred to as the specific gravity) shall be indicated.

In cases where variations in density are possible, e.g. due to batch manufacture, or where one safety data sheet is used to cover several variants of a substance or mixture, a range


<a id="echa-s9-page-82"></a>
**ECHA printed page 82** — [original PDF page 82](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=82)

may be indicated.

The safety data sheet shall indicate whether the absolute density (units e.g. g/cm3 or kg/m3) and/or the relative density (dimensionless) is being reported.

(q) Relative vapour density

Only applies to gases and liquids.

As regards gases, the relative density of the gas based on air at 20 °C as reference shall be indicated.

As regards liquids, the relative vapour density based on air at 20 °C as reference shall be indicated.

As regards liquids, the relative density Dm of the vapour/air-mixture at 20 °C may also be indicated.

(r) Particle characteristics

Only apply to solids.

The particle size (median equivalent diameter, method of calculation of the diameter (number-, surface- or volume-based) and the range in which this median value varies), shall be indicated. Other properties may also be indicated, such as size distribution (e.g. as a range), shape and aspect ratio, aggregation and agglomeration state, specific surface area and dustiness. If the substance is in nanoform or if the mixture supplied contains a nanoform, those characteristics shall be indicated in this subsection, or referred to if already specified elsewhere in the safety data sheet.

The 7th revision of the GHS, which Regulation (EU) 2020/878 implements, defines the requirements for describing each of the physical and chemical properties.

It needs to be emphasised that if information on a particular property is not available, this must be clearly indicated, and the reasons given where possible. Note that the legal text specifies in some detail what type of information should be provided for each of the properties, so additional guidance is only provided for some of the properties, where it may be considered helpful.

(h) Flash point

For information on test methods etc., see Section 2.6.4.4 of Annex I of Regulation (EC) No 1272/2008.

(j) Decomposition temperature

For determination of the SADT see test series H in section 28 of the UN Manual of Tests and Criteria, and for the decomposition onset temperature see also section 20.3.3.3 of the UN Manual of Tests and Criteria.

(k) pH

pH is not applicable to gases. It is linked to aqueous media by definition; measurements carried out in other media do not give the pH.

Where the pH is ≤ 2 or ≥ 11,5, see section 9.2.2(d) for information on acid/alkaline reserve.


<a id="echa-s9-page-83"></a>
**ECHA printed page 83** — [original PDF page 83](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=83)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 83](page_images/ECHA_2020_page_083.jpg)

It needs to be emphasised that if information on a particular property is not available, this must be clearly indicated, and the reasons given where possible.

The availability (and reason for the lack) of information  is of special relevance regarding the pH of a mixture, as this information must be available for the purpose of submitting information for emergency health response under Article 45 and Annex VIII of the CLP Regulation. The format to be used to submit information required by Annex VIII includes a closed list of acceptable reasons for not providing a precise pH value are86. The author of the SDS should consider referring to this list in order to facilitate the preparation of the emergency health response submission:

- Mixture is a gas

•   Mixture is non-polar/aprotic

•    Mixture is non-soluble (in water)

•   pH above 15

•   pH below -3

•   Mixture reacts violently with water

•   Mixture not stable

In some of these cases an indication of the alkaline, neutral or acidic properties (or a broad pH range) should still be provided if available, as this information is relevant for the personnel providing emergency response. 

(l) Kinematic viscosity

 The measurement unit shall be mm2/s, as the classification criteria for the hazard class ‘aspiration hazard’ are based on this unit.

The dynamic viscosity is not required in the SDS, but may be indicated in addition or may be calculated by the user. The kinematic viscosity is linked to the dynamic viscosity by the density:

)
/
(
Density
)
(
viscosity
Dynamic
)
/
(
viscosity
Kinematic
3
2
cm
g
s
mPa
s
mm
⋅
=

(o) Vapour pressure  The saturated vapour concentration (SVC) may be indicated, and it can be estimated as follows:

SVC in ml/m3:  SVC = VP ∙c1 SVC in g/m3:    𝑆𝑆𝑆𝑆𝑆𝑆= 𝑉𝑉𝑉𝑉∙𝑀𝑀𝑀𝑀∙c2 Where VP is the vapour pressure in hPa (= mbar), MW is the molecular weight in g/mol, and c1 and c2 are conversion factors (c1 = 987,2 ml

m3∙hPa and c2 = 0,0412 mol

m3∙hPa).

(q) Relative vapour density

Additionally, for liquids, the relative density Dm of the vapour/air-mixture at 20 °C (air = 1) may be indicated, and can be calculated as follows:

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   86 The list was discussed and agreed with the experts Working Group supporting the preparation of the ECHA Submission portal. Justified suggestions for changes to this list can be submitted via the ECHA contact from and considered in the first format update.


<a id="echa-s9-page-84"></a>
**ECHA printed page 84** — [original PDF page 84](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=84)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 84](page_images/ECHA_2020_page_084.jpg)

𝐷𝐷𝑚𝑚= 1 + (𝑉𝑉𝑉𝑉20 ∙(𝑀𝑀𝑀𝑀−𝑀𝑀𝑀𝑀𝑎𝑎𝑎𝑎𝑎𝑎) ∙c3) where VP20 is the vapour pressure at 20 °C in hPa (= mbar), MW is the molecular weight in g/mol, MWair is the molecular weight of air (= 29 g/mol), and c3 is a conversion factor (c3 = 34 ∙10−6 mol

g∙hPa).

For further information on the determination of physical and chemical properties in the context of classification and labelling see the Guidance on the Application of the CLP Criteria at: https://echa.europa.eu/guidance-documents/guidance-on-clp

For information on nanoforms see section 3.3 in this guidance and the Appendix for nanoforms applicable to the Guidance on Registration and Substance Identification87 which provides advice on how to characterise nanoforms and sets of nanoforms regarding the requirements of Annex VI. Please refer to the guidance for information on characterisation of nanoforms regarding particle size distribution, shape and morphology (including crystallinity), surface treatment and characterisation and specific surface area.

Further guidance in regard to available information on nanomaterials put on the market and their redox potential, radical formation potential and photocatalytic properties can be found from the OECD-WPMN available at: http://www.oecd.org/env/ehs/nanosafety/publications- series-safety-manufactured-nanomaterials.htm

<a id="echa-sds-9-2"></a>
### 9.2 Other information

Text Annex II

In addition to the properties mentioned in subsection 9.1, other physical and chemical parameters shall be indicated, such as the properties listed in subsections 9.2.1. and 9.2.2., if their indication is relevant for the safe use of the substance or mixture.

9.2.1. Information with regard to physical hazard classes

This subsection lists properties, safety characteristics and test results, which may be useful to include in the safety data sheet when a substance or mixture is classified in the respective physical hazard class. Data deemed relevant with regard to a specific physical hazard but not resulting in classification (e.g. negative test results close to the criterion), may also be appropriate to indicate.

The name of the hazard class to which the data relate may be indicated together with the data.

(a) Explosives

This point also applies to substances and mixtures referred to in Note 2 of  section 2.1.3. of Annex I of Regulation (EC) No 1272/2008, and to other  substances and mixtures which show a positive effect if heated under  confinement.

The following information may be provided:

(i) sensitivity to shock;

87 https://echa.europa.eu/documents/10162/13655/how_to_register_nano_en.pdf/


<a id="echa-s9-page-85"></a>
**ECHA printed page 85** — [original PDF page 85](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=85)

(ii) effect of heating under confinement;

(iii) effect of ignition under confinement;

(iv) sensitivity to impact;

(v) sensitivity to friction;

(vi) thermal stability;

(vii) package (type, size, net mass of substance or mixture), based on  which the ‘division’ within the explosive class was assigned, or based on which  the substance or mixture was exempted from classification as explosive.

(b) Flammable gases

As regards pure flammable gas, the following information may be provided in  addition to data on the explosion limits referred to in point (g) of  subsection  9.1.:

(i) the TCi (maximum content of flammable gas which, when mixed with  nitrogen, is not flammable in air, in mol. %);

(ii) the fundamental burning velocity if the gas is classified as Category 1B  based on fundamental burning velocity.

As regards a flammable gas mixture, the following information may be provided in  addition to data on the explosion limits referred to in point (g) of subsection 9.1.:

(i) explosion limits, if tested, or an indication of whether the classification and  category assignment is based on calculation;

(ii) fundamental burning velocity if the gas mixture is classified as Category 1B  based on fundamental burning velocity.

(c) Aerosols

The following total percentage (by mass) of flammable components may be  provided, unless the aerosol is classified as Aerosol category 1 because it contains  more than 1 % (by mass) flammable components or has a heat of combustion of at  least 20 kJ/g and is not submitted to the flammability classification procedures (see  the Note in Paragraph 2.3.2.2 of Annex I to Regulation (EC) No 1272/2008);

(d) Oxidising gases

As regards pure gas, the Ci (coefficient of oxygen equivalency) as per ISO

10156 ‘Gases and gas mixtures - Determination of fire potential and
oxidizing ability

for the selection of cylinder valve outlets’, or as per an equivalent method, may be

provided;

As regards a gas mixture, the words ‘oxidising gas Category 1 (tested as per ISO  10156 (or as per an equivalent method))’ may be indicated as regards tested  mixtures, or the calculated oxidising power as per ISO 10156 or as per ab  equivalent method;

(e) Gases under pressure


<a id="echa-s9-page-86"></a>
**ECHA printed page 86** — [original PDF page 86](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=86)

As regards pure gas, critical temperature may be provided.

As regards gas mixture, pseudo-critical temperature may be provided;

(f) Flammable liquids

When the substance or mixture is classified as flammable liquid, data on the  boiling point and flash point do not need to be provided under this point as that  data are to be indicated in accordance with the subsection 9.1. Information on  sustained combustibility may be provided.

(g) Flammable solids

The following information may be provided:

(i) burning rate, or burning time as regards metal powders,

(ii) statement on whether the wetted zone has been passed;

(h) Self-reactive substances and mixtures

In addition to the indication of the SADT as specified in point (j) of subsection  9.1, the following information may be provided:

(i) decomposition temperature,

(ii) detonation properties,

(iii) deflagration properties,

(iv) effect of heating under confinement,

(v) explosive power, if applicable;

(i) Pyrophoric liquids

Information on whether spontaneous ignition or charring of filter paper occurs  may be provided.

(j)    Pyrophoric solids

The following information may be provided:

(i) statement on whether spontaneous ignition occurs when poured or  within five minutes thereafter, as regards solids in powder form,

(ii) statement on whether pyrophoric properties could change over time.

(k) Self-heating substances and mixtures

The following information may be provided:

(i) statement on whether spontaneous ignition occurs and the maximum  temperature rise obtained,

(ii) results of screening tests referred to in section 2.11.4.2 of Annex I to


<a id="echa-s9-page-87"></a>
**ECHA printed page 87** — [original PDF page 87](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=87)

Regulation (EC) No 1272/2008, if relevant and available;

(l)   Substances and mixtures, which emit flammable gases in contact with water

The following information may be provided:

(i) identity of the emitted gas, if known,

(ii) statement on whether the emitted gas ignites spontaneously,

(iii) gas evolution rate;

(m)   Oxidising liquids

Information on whether spontaneous ignition occurs when mixed with cellulose  may be provided.

(n)   Oxidizing solids

Information on whether spontaneous ignition occurs when mixed with cellulose may be  provided.

(o) Organic peroxides

In addition to the indication of the SADT as specified in point (j) of subsection  9.1, the following information may be provided:

(i) decomposition temperature,

(ii) detonation properties,

(iii) deflagration properties,

(iv) effect of heating under confinement,

(v) explosive power;

(p) Corrosive to metals

The following information may be provided:

(i) metals that are corroded by the substance or mixture,

(ii.) corrosion rate and statement on whether it refers to steel or  aluminium,

(iii.) reference to other sections of the safety data sheet with regard to  compatible or incompatible materials.

(q) Desensitised explosives

The following information may be provided:

(i) desensitising agent used,

(ii) exothermic decomposition energy,


<a id="echa-s9-page-88"></a>
**ECHA printed page 88** — [original PDF page 88](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=88)

(iii) corrected burning rate (Ac);

(iv) explosive properties of the desensitised explosive in that state.

9.2.2. Other safety characteristics

Properties, safety characteristics and test results listed below may be useful to indicate as regards a substance or a mixture:

(a) mechanical sensitivity;

(b) self-accelerating polymerisation temperature;

(c) formation of explosible dust/air mixtures;

(d) acid/alkaline reserve;

(e) evaporation rate;

(f) miscibility;

(g) conductivity;

(h) corrosiveness;

(i) gas group;

(j) redox potential;

(k) radical formation potential;

(l) photocatalytic properties.

Other physical and chemical parameters shall be indicated if their indication is relevant for the safe use of the substance or mixture.

9.2.1. Information with regard to physical hazard classes

Further information is provided below on certain hazard classes in Section 9.2.1, in particular on applicable test methods for the purposes of hazard classification.

(a) Explosives

(i) the sensitivity to shock is generally determined by the UN gap test: test 1 (a) and/or test 2 (a) (section 11.4 or 12.4 of the UN Manual of Tests and Criteria) (indicate at least + or −);

(ii) the effect of heating under confinement is generally determined by the Koenen test: test 1

(b) and/or test 2 (b) (section 11.5 or 12.5 of the UN Manual of Tests and Criteria)

(indicate preferably the limiting diameter);

(iii) the effect of ignition under confinement is generally determined by test 1 (c) and/or test 2

(c) (section 11.6 or 12.6 of the UN Manual of Tests and Criteria) (indicate at least + or −);


<a id="echa-s9-page-89"></a>
**ECHA printed page 89** — [original PDF page 89](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=89)

(iv) the sensitiveness to impact is generally determined by test 3 (a) (section 13.4 of the UN Manual of Tests and Criteria) (indicate preferably the limiting impact energy);

(v) the sensitiveness to friction is generally determined by test 3 (b) (section 13.5 of the UN Manual of Tests and Criteria) (indicate preferably the limiting load);

(vi) the thermal stability is generally determined by test 3 (c) (section 13.6 of the UN Manual of Tests and Criteria) (indicate at least + or −);

(b) Flammable gases

As regards pure flammable gas:

(i) the TCi is indicated as per ISO 10156;

(ii) the fundamental burning velocity is generally determined by ISO 817:2014, Annex C;

As regards flammable gas mixture:

(i) the explosion limits: the reference to calculation is as per ISO 10156;

(ii) the fundamental burning velocity is generally determined by ISO 817:2014, Annex C;

(e) Gas under pressure

For gas mixtures the pseudo-critical temperature is estimated as the molar fraction weighted average of the critical temperatures of the components as follows:

∑= ⋅ n

1 i i Crit i T x

where xi is the molar fraction of component i and TCriti,i is the critical temperature of component i;

(f) Flammable liquids

The following additional information may be provided:

Information on sustained combustibility if an exemption is considered based on Test L.2 (section 32.5.2 of the UN Manual of Tests and Criteria), in accordance with Section 2.6.4.5 of Annex I of Regulation (EC) No 1272/2008;

(g) Flammable solids

For point (i) the burning rate (or burning time for metal powders) is generally determined by Test N.1 (section 33.2.4 of the UN Manual of Tests and Criteria);

(h) Self-reactive substances and mixtures

The following information may be provided (for more information on test methods see Part II of the UN Manual of Tests and Criteria88):

(i) Decomposition energy: value and method of determination, see section 20.3.3.3 in the

88 https://www.unece.org/fileadmin/DAM/trans/danger/publi/manual/Rev7/Manual_Rev7_E.pdf


<a id="echa-s9-page-90"></a>
**ECHA printed page 90** — [original PDF page 90](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=90)

referenced manual,

(ii) Detonation properties: indication of (Yes/Partial/No), also in packaging where relevant, see Test Series A in the referenced manual,

(iii) Deflagration properties: indication of (Yes rapidly/Yes slowly/No), also in packaging where relevant, see Test Series C in the referenced manual,

(iv) Effect of heating under confinement: indication of (Violent/Medium/Low/No), also in packaging where relevant, see Test Series E in the referenced manual,

(v) Explosive power if applicable: indication of (Not low/Low/None), see Test Series F in the referenced manual;

(i) Pyrophoric liquids

Spontaneous ignition or charring of the filter paper is generally determined by Test N.3 (Section 33.4.5 of the UN Manual of Tests and Criteria) (indicate e.g. "the liquid ignites spontaneously in air" or "a filter paper with the liquid chars in air");

(j) Pyrophoric solids

The statement referred to under point (i) of the legal text of this section is generally determined by Test N.2 (Section 33.4.4 of the UN Manual of Tests and Criteria) e.g. "the solid ignites spontaneously in air",

An example of the type of information corresponding to point (ii) of the legal text is: pyrophoric properties could change over time by formation of a protective surface layer through slow oxidation;

(k) Self-heating substances and mixtures

The statement referred to under point (i) of the legal text in this section, on whether spontaneous ignition occurs, could include possible screening data and/or method used (generally Test N.4, Section 33.4.6 of the UN Manual of Tests and Criteria);

(l) Substances and mixtures, which emit flammable gases in contact with water

The gas evolution rate, as indicated under point (iii), is generally determined by Test N.5 (section 33.5.4 of the UN Manual of Tests and Criteria), unless the test has not been completed e.g. because the gas ignites spontaneously;

(m) Oxidising liquids

Whether spontaneous ignition occurs when mixed with cellulose can be seen in the course of Test O.2 (section 34.4.2 of the UN Manual of Tests and Criteria) (e.g., "the mixture with cellulose (prepared for Test O.2) ignites spontaneously");

(n) Oxidizing solids

Whether spontaneous ignition occurs when mixed with cellulose can be seen in the course of Test O.1 or O.3 (section 34.4.1 or 34.4.3 of the UN Manual of Tests and Criteria) (e.g., "the mixture with cellulose (prepared for Test O.1 or O.3) ignites spontaneously");

(o) Organic peroxides

The following information may be provided (for more information on test methods see Part II


<a id="echa-s9-page-91"></a>
**ECHA printed page 91** — [original PDF page 91](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=91)

of the UN Manual of Tests and Criteria89):

(i) Decomposition energy: value and method of determination, if available, see section 20.3.3.3 in the referenced manual,

(ii) Detonation properties: indication of (Yes/Partial/No), also in packaging where relevant, see Test Series A in the referenced manual,

(iii) Deflagration properties: indication of (Yes rapidly/Yes slowly/No), also in packaging where relevant, see Test Series C in the referenced manual,

(iv) Effect of heating under confinement: indication of (Violent/Medium/Low/No), also in packaging where relevant, see Test Series E in the referenced manual,

(v) Explosive power: indication of (Not low/Low/None), if applicable, see Test Series F in the referenced manual;

(p) Corrosive to metals

(i) Some examples of what could be expected in this point (i) are: "corrosive to aluminium" or "corrosive to steel" etc.),

(ii) Corrosion rate and whether it refers to steel or aluminium is generally determined by Test C.1 (section 37.4 of the UN Manual of Tests and Criteria);

(iii) Some examples of references to other sections are: to packaging compatibilities in Section 7, or to incompatible materials in Section 10);

(q) Desensitized explosives

On point (iii) the corrected burning rate (Ac) has to be determined according to Part V, section 51.4 of the UN Manual of Tests and Criteria.

On point (iv) the explosive properties of the desensitised explosive (in that state) are generally determined by test series 1 and/or 2 (sections 11 and 12 of the UN Manual of Tests and Criteria).

9.2.2. Other safety characteristics

Further information on how certain properties or safety characteristics in subsection 9.2.2 are determined, or expected to be described, is provided below:

(a) Mechanical sensitivity

When the substance or mixture is an energetic substance or mixture with an exothermic decomposition energy ≥ 500 J/g in accordance with the UN Manual of Tests and Criteria, Appendix 6, section 3.3 (c), the following information may be provided:

(i) the sensitiveness to impact, generally determined by test 3 (a) (section 13.4 of the UN Manual of Tests and Criteria) (indicate preferably the limiting impact energy),

(ii) the sensitiveness to friction, generally determined by test 3 (b) (section 13.5 of the

89 https://www.unece.org/fileadmin/DAM/trans/danger/publi/manual/Rev7/Manual_Rev7_E.pdf


<a id="echa-s9-page-92"></a>
**ECHA printed page 92** — [original PDF page 92](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=92)

UN Manual of Tests and Criteria) (indicate preferably the limiting load);

(b) Self-accelerating polymerisation temperature (SAPT)

When the substance or mixture may self-polymerise thereby generating dangerous amounts of heat and gas or vapour, the following information may be provided:

- the SAPT and the volume for which the SAPT is given, see Test Series H in Part II of the UN Manual of Tests and Criteria;

(c) Formation of explosible dust/air mixtures

The formation of explosible dust/air mixtures is not applicable to gases and liquids, nor to solids containing only substances which are fully oxidised (e.g. silicon dioxide).

In case formation of explosible dust/air mixtures might be possible based on Section 2 of the SDS, the following relevant safety characteristics may be provided:

(i) Lower explosion limit / minimum explosible concentration,

(ii) Minimum ignition energy,

(iii) Deflagration index (Kst);

(iv) Maximum explosion pressure

(v) The particle characteristics to which the data apply if different from the particle characteristics as indicated in section 9.1;

Note 1: The ability to form explosible dust/air mixtures may be determined e.g. by Verein Deutscher Ingenieure, VDI  2263-1 "Dust Fires and Dust Explosions; Hazards - Assessment - Protective Measures; Test Methods for the Determination of the Safety Characteristics of Dusts" or by ISO/IEC 80079-20-2 "Explosive atmospheres - Part 20-2: Material characteristics - Combustible dusts test methods".

Note 2: Explosion characteristics are specific for the tested dust. Normally they cannot be transferred to other dusts even if these are comparable. Fine-sized dusts of a particular substance tend to react stronger than coarser dusts.

(d) Acid/alkaline reserve

When the substance or mixture has an extreme pH (pH < 2 or > 11.5), the following information may be provided:

- Acid/alkaline reserve when used for evaluating skin and eye hazards;

This section needs to be checked for consistency with the following sections:

- SECTION 2: Hazards identification

- SECTION 5: Fire fighting measures

- SECTION 6: Accidental release measures

- SECTION 7: Handling and storage

- SECTION 11: Toxicological information: (i.e. extreme pH/corrosive properties)

- SECTION 12: Ecological information: (i.e. log Kow / bioaccumulation)


<a id="echa-s9-page-93"></a>
**ECHA printed page 93** — [original PDF page 93](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=93)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 93](page_images/ECHA_2020_page_093.jpg)

- SECTION 13: Disposal considerations

- SECTION 14: Transport information


---

<a id="s10"></a>


# 3.10 SDS SECTION 10 — Stability and reactivity

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s10-page-93"></a>
**ECHA printed page 93** — [original PDF page 93](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=93)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 93](page_images/ECHA_2020_page_093.jpg)

3.10 SDS SECTION 10: Stability and Reactivity

Text Annex II

This section of the safety data sheet shall describe the stability of the substance or mixture and the possibility of hazardous reactions occurring under certain conditions of use and also if released into the environment, including, where appropriate, a reference to the test methods used. If it is stated that a particular property does not apply or if information on a particular property is not available, the reasons shall be given.

Stability and reactivity are a function of the physical and chemical properties measured to determine values quoted in Section 9 of the SDS. However, although not explicitly stated in the Regulation, historically the practice has been to use Section 9 to indicate measurable properties derived from test procedures whereas Section 10 gives (qualitative) descriptions of possible consequences. Thus, as already explained in subchapter 3.9, Section 9 invites information on “properties” or “parameters” whereas Section 10 specifies that a “description” should be given.

Similarly some information may also be given in Section 7 of the SDS (e.g. on incompatibilities in subsection 7.2). In such cases repetition may be avoided by cross-references, with the content of Section 10 focusing on description of hazards and their consequences. Where information is correctly already inserted in a different section of the SDS a cross-reference to it can be made without the need to repeat it. Thus, for example, certain information on hazard classes is included in Section 9 or Section 7. Additionally, information on protection measures is given under subsection 8.2. “exposure controls”. Therefore a lot of information relevant to Section 10 may already be given in other sections.

As the information must be written in a clear and concise manner, repetitions should be avoided.

<a id="echa-sds-10-1"></a>
### 10.1 Reactivity

Text Annex II

10.1.1. The reactivity hazards of the substance or mixture shall be described. Specific test data shall be provided for the substance or mixture as a whole, where available. However, the information may also be based on general data for the class or family of substance or mixture if such data adequately represent the anticipated hazard of the substance or mixture.

10.1.2. If data for mixtures are not available, data on substances in the mixture shall be provided. In determining incompatibility, the substances, containers and contaminants that the substance or mixture might be exposed to during transportation, storage and use shall be considered.

[The text above is considered as needing no further explanation]


<a id="echa-s10-page-94"></a>
**ECHA printed page 94** — [original PDF page 94](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=94)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 94](page_images/ECHA_2020_page_094.jpg)

<a id="echa-sds-10-2"></a>
### 10.2 Chemical stability

Text Annex II

It shall be indicated if the substance or mixture is stable or unstable under normal ambient and anticipated storage and handling conditions of temperature and pressure. Any stabilisers which are, or may need to be, used to maintain the chemical stability of the substance or mixture shall be described. The safety significance of any change in the physical appearance of the substance or mixture shall be indicated. As regards desensitised explosives, information on the shelf life and instructions on how to verify desensitisation shall be provided, and it shall be indicated that removal of the desensitising agent will turn the product into an explosive.

Examples of common standard phrases which may be used in this subsection for stable substances or mixtures include:

- “Under storage at normal ambient temperatures (minus 40° C to + 40° C), the product is stable.”

- “No hazardous reaction when handled and stored according to provisions.”

- “No known hazardous reactions”

<a id="echa-sds-10-3"></a>
### 10.3 Possibility of hazardous reactions

Text Annex II

If relevant, it shall be stated if the substance or mixture will react or polymerise, releasing excess pressure or heat, or creating other hazardous conditions. The conditions under which the hazardous reactions may occur shall be described.

Note that information e.g. on dust explosion hazard is given in Sections 2 and 9, and there is therefore a need to check for consistency/potential overlap.

There is also potential overlap between subsection “10.1 Reactivity” which also relates to reactivity hazards and the present 10.3 “Possibility of hazardous reactions”. Entry of information in subsection 10.3 may be restricted to hazardous outcomes resulting from specific reactivity. Thus clearly, for example, a substance may be described as a strong acid in subsection 10.1 which implies e.g. an intrinsic risk of hazardous reaction with bases. Subsection 10.3 may be reserved for the specific outcomes of reactivity listed (polymerisation leading to excess pressure or heat) and for information on reaction conditions. There is no need to duplicate content in both subsections.


<a id="echa-s10-page-95"></a>
**ECHA printed page 95** — [original PDF page 95](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=95)

<a id="echa-sds-10-4"></a>
### 10.4 Conditions to avoid

Text Annex II

Conditions such as temperature, pressure, light, shock, static discharge, vibrations or other physical stresses that might result in a hazardous situation shall be listed (‘conditions to avoid’) and if appropriate a brief description of measures to be taken to manage risks associated with such hazards shall be given. As regards desensitised explosives, information on measures to be taken in order to avoid the unintentional removal of the desensitising agent shall be provided, and conditions to avoid shall be listed if the substance or mixture is not sufficiently desensitised.

The content of this subsection potentially overlaps with subsection 7.2 “Conditions for safe storage, including any incompatibilities” and there is therefore a need to check for consistency/potential overlap,

The advice provided must be consistent with the physical and chemical properties described in Section 9 of the SDS. If relevant, advice must be provided on specific storage requirements including:

(a) How to manage risks associated with:

(i) explosive atmospheres;

(ii) corrosive conditions;

(iii) flammability hazards;

(iv) incompatible substances or mixtures;

(v) evaporative conditions; and

(vi) potential ignition sources (including electrical equipment).

(b) How to control the effects of:

(i) weather conditions;

(ii) ambient pressure;

(iii) temperature;

(iv) sunlight;

(v) humidity; and

(vi) vibration.

(c) How to maintain the integrity of the substance or mixture by the use of:

(i) stabilisers; and

(ii) anti-oxidants.

(d) Other advice including:


<a id="echa-s10-page-96"></a>
**ECHA printed page 96** — [original PDF page 96](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=96)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 96](page_images/ECHA_2020_page_096.jpg)

(i) ventilation requirements;

(ii) specific designs for storage rooms or vessels (including retention walls and ventilation);

(iii) quantity limits under storage conditions (if relevant); and

(iv) packaging compatibilities

<a id="echa-sds-10-5"></a>
### 10.5 Incompatible materials

Text Annex II

Families of substances or mixtures or specific substances, such as water, air, acids, bases, oxidising agents, with which the substance or mixture could react to produce a hazardous situation (like an explosion, a release of toxic or flammable materials, or a liberation of excessive heat) shall be listed and if appropriate a brief description of measures to be taken to manage risks associated with such hazards shall be given.

Note that it is not necessarily good practice to give a long list of “incompatible materials” which includes many substances with which the product is unlikely ever to come into contact. A balance should be sought between diluting the message about relevant incompatibilities with too long a list and the potential risks from omission of a specific incompatible material. Use of substance types or classes (e.g. “aromatic solvents”) rather than listing individual substances may be preferable and can avoid long lists of individual substances.

The content of this subsection potentially overlaps with elements dealing with handling of incompatible substances and mixtures within subsection 7.1 “Precautions for safe handling” and there is therefore a need to check for consistency/potential overlap.

<a id="echa-sds-10-6"></a>
### 10.6 Hazardous decomposition products

Text Annex II

Known and reasonably anticipated hazardous decomposition products produced as a result of use, storage, spill and heating shall be listed. Hazardous combustion products shall be included in section 5 of the safety data sheet.

The possibility of degradation to unstable products should be addressed in this subsection.

Examples of common standard phrases which may be used where appropriate in this subsection for stable substances or mixtures include:

- “Does not decompose when used for intended uses.”

- “No known hazardous decomposition products.”

An example of how the structure of this section could look is given below:


<a id="echa-s10-page-97"></a>
**ECHA printed page 97** — [original PDF page 97](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=97)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 97](page_images/ECHA_2020_page_097.jpg)

SECTION 10: Stability and reactivity

10.1 Reactivity

10.2 Chemical stability

10.3 Possibility of hazardous reactions

10.4 Conditions to avoid

10.5 Incompatible materials

10.6 Hazardous decomposition products

This section needs to be checked for consistency in particular with the following sections;

- SECTION 2: Hazards identification

- SECTION 5: Fire-fighting measures

- SECTION 6: Accidental release measures

- SECTION 7: Handling and storage

- SECTION 13: Disposal considerations


---

<a id="s11"></a>


# 3.11 SDS SECTION 11 — Toxicological information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s11-page-97"></a>
**ECHA printed page 97** — [original PDF page 97](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=97)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 97](page_images/ECHA_2020_page_097.jpg)

3.11 SDS SECTION 11: Toxicological information

Text Annex II

This section of the safety data sheet is meant for use primarily by medical professionals, occupational health and safety professionals and toxicologists. A concise but complete and comprehensible description of the various toxicological (health) effects and the available data used to identify those effects shall be provided, including where appropriate information on toxicokinetics, metabolism and distribution. The information in this section shall be consistent with the information provided in the registration and/or in the chemical safety report where required, and with the classification of the substance or mixture.

<a id="echa-sds-11-1"></a>
### 11.1. Information on hazard classes as defined in Regulation (EC) No 1272/2008

The relevant hazard classes, for which information shall be provided, are:

(a) acute toxicity;

(b) skin corrosion/irritation;

(c) serious eye damage/irritation;

(d) respiratory or skin sensitisation;

(e) germ cell mutagenicity;

(f) carcinogenicity;

(g) reproductive toxicity;


<a id="echa-s11-page-98"></a>
**ECHA printed page 98** — [original PDF page 98](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=98)

(h) STOT-single exposure;

(i) STOT-repeated exposure;

(j) aspiration hazard.

These hazards shall always be listed on the safety data sheet.

For substances subject to registration, brief summaries of the information derived from the application of Annexes VII to XI shall be given, including, where appropriate, a reference to the test methods used. For substances subject to registration, the information shall also include the result of the comparison of the available data with the criteria given in Regulation (EC) No 1272/2008 for CMR, categories 1A and 1B, following point 1.3.1 of Annex I to this Regulation.

11.1.1. Information shall be provided for each hazard class or differentiation. If it is stated that the substance or mixture is not classified for a particular hazard class or differentiation, the safety data sheet shall clearly state whether this is due to lack of data, technical impossibility to obtain the data, inconclusive data or data which are conclusive although insufficient for classification; in the latter case the safety data sheet shall specify “based on available data, the classification criteria are not met”.

11.1.2. The data included in this subsection shall apply to the substance or mixture as placed on the market. In the case of a mixture, the data should describe the toxicological properties of the mixture as a whole, except if Article 6(3) of Regulation (EC) No 1272/2008 applies. If available, the relevant toxicological properties of the hazardous substances in a mixture shall also be provided, such as the LD50, acute toxicity estimates or LC50.

11.1.3. Where there is a substantial amount of test data on the substance or mixture, it may be necessary to summarise results of the critical studies used, for example by route of exposure.

11.1.4. Where the classification criteria for a particular hazard class are not met, information supporting this conclusion shall be provided.

11.1.5. Information on likely routes of exposure

Information shall be provided on likely routes of exposure and the effects of the substance or mixture via each possible route of exposure, that is, through ingestion (swallowing), inhalation or skin/eye exposure. If health effects are not known, this shall be stated.

11.1.6. Symptoms related to the physical, chemical and toxicological characteristics

Potential adverse health effects and symptoms associated with exposure to the substance or mixture and its ingredients or known by-products shall be described. Available information shall be provided on the symptoms related to the physical, chemical, and toxicological characteristics of the substance or mixture following exposure. The first symptoms at low exposures through to the consequences of severe exposure shall be described, such as “headaches and dizziness may occur, proceeding to fainting or unconsciousness; large doses may result in coma and death”.

11.1.7. Delayed and immediate effects as well as chronic effects from short and long term exposure

Information shall be provided on whether delayed or immediate effects can be expected after short- or long-term exposure. Information on acute and chronic health effects relating to human exposure to the substance or mixture shall also be provided. Where human data are not available, information on the experimental data shall be summarised, with details on either animal data and the species clearly identified or the in vitro tests and the cell types clearly identified. It shall be indicated whether toxicological data is based on human or animal data or on in vitro tests.

11.1.8. Interactive effects


<a id="echa-s11-page-99"></a>
**ECHA printed page 99** — [original PDF page 99](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=99)

Information on interactions shall be included if relevant and available.

11.1.9. Absence of specific data

It may not always be possible to obtain information on the hazards of a substance or mixture. In cases where data on the specific substance or mixture are not available, data on similar substances or mixtures if appropriate, may be used, provided the relevant similar substance or mixture is identified. Where specific data are not used, or where data are not available, this shall be clearly stated.

11.1.10. Mixtures

For a given health effect, if a mixture has not been tested for its health effects as a whole, relevant information on relevant substances listed under section 3 shall be provided.

11.1.11. Mixture versus substance information

11.1.11.1. The substances in a mixture may interact with each other in the body resulting in different rates of absorption, metabolism and excretion. As a result, the toxic actions may be altered and the overall toxicity of the mixture may be different from that of the substances in it. This shall be taken into account when providing toxicological information in this section of the safety data sheet.

11.1.11.2. It is necessary to consider whether the concentration of each substance is sufficient to contribute to the overall health effects of the mixture. The information on toxic effects shall be presented for each substance, except for the following cases:

(a) if the information is duplicated, it shall be listed only once for the mixture overall, such as when two substances both cause vomiting and diarrhoea;

(b) if it is unlikely that these effects will occur at the concentrations present, such as when a mild irritant is diluted to below a certain concentration in a non-irritant solution;

(c) where information on interactions between substances in a mixture is not available, assumptions shall not be made and instead the health effects of each substance shall be listed separately.

<a id="echa-sds-11-2"></a>
### 11.2 Information on other hazards

11.2.1. Endocrine disrupting properties

Information on adverse health effects caused by endocrine disrupting properties shall be provided, where available, for the substances identified as having endocrine disrupting properties in Subsection 2.3. This information shall consist of brief summaries of the information derived from application of the assessment criteria laid down in the corresponding Regulations ((EC) No 1907/2006, (EU) 2017/2100, (EU) 2018/605), that is relevant to assess endocrine disrupting properties for human health.

11.2.2. Other information

Other relevant information on adverse health effects shall be included even when not required by the classification criteria.

This section is of great importance during the process of compilation of an SDS as it should reflect the information gathered and conclusions arrived at during the assessment of the substance or mixture for the purposes of determining its hazards and consequent classification and labelling.

It follows from the introductory text to Section 11 that, for mixtures containing substances


<a id="echa-s11-page-100"></a>
**ECHA printed page 100** — [original PDF page 100](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=100)

subject to registration the information given in this section for such substances should also be consistent with that given in the relevant registrations for the individual substances.

Since a large quantity of information may need to be provided under this section, particularly in an SDS for a mixture,  it is advisable to  arrange its layout in such a way that a clear separation is established between the data that apply to a mixture as a whole (where applicable) and that for individual (component) substances. Information concerning the different hazard classes should be clearly and separately reported.

Clear and concise presentation of key information and critical studies provided can, for example, be achieved by using text boxes or tables.

If no data are available for certain hazard classes or differentiations the reasons for the absence of data should be given90.

Note that for the requirements given under points 11.1.8 the phrase "if relevant and available" in the context of information on interactive effects is to be understood as meaning that the compiler of the SDS is expected to make a reasonable search for such information if he does not have it already.

According to subsection 11.2 Information on other hazards, information on adverse effects due to endocrine disrupting properties have to be indicated. Guidance on endocrine disruptors and their identification can be found at: https://echa.europa.eu/hot-topics/endocrine-disruptors  The type of information that might represent a “brief summary” of information on endocrine disrupting properties for human health can be found in the published Biocidal Products Committee (BPC) opinion on 2,2-Dibromo-2-cyanoacetamide (DBNPA)91, page 6:  DBNPA is considered to have endocrine-disrupting properties with respect to humans as it meets the criteria set out in section A of Regulation (EU) No 2017/2100. The conclusion is based on the observed adverse effects in the thyroid gland in the studies on rats and dogs combined with data obtained from a literature search conducted on bromide effects on the thyroid. Bromide may substitute iodide in the natrium/iodide symporter of the thyroid, thus creating a relative iodide insufficiency for further synthesis of thyroid hormones. This shows a link between the observed adverse effects in the thyroid and endocrine activity, which is relevant for humans and non-target species.  TOXICOLOGICAL (HEALTH) EFFECTS

In this subsection of the SDS the potential adverse health effects/symptoms after exposure to the substance, mixture and known by-products must be described. The symptoms caused by the physical, chemical, and toxicological characteristics of the substance or mixture must be listed. Symptoms occurring after exposure should be arranged in a sequential order of exposure levels (either from high to low or from low to high), indicating if occurrence of the effects is immediate or delayed.

FOR SUBSTANCES

Information (such as for example key results) must be provided, for the relevant hazard classes or differentiations, as specified in the legal text quoted above. This should be separated according to the route of exposure, species (rat, mouse, human …), and study duration and

90 As required by point 11.1.1 of the legal text quoted above .

91 https://echa.europa.eu/documents/10162/085a4896-b067-bdbc-e38c-8f794e60e4f3


<a id="echa-s11-page-101"></a>
**ECHA printed page 101** — [original PDF page 101](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=101)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 101](page_images/ECHA_2020_page_101.jpg)

study method. In the case of information on specific target organ toxicity (STOT), the information should obviously include indication of the specific target organ. If data are not available for a specific substance and read-across or QSAR’s are applied this should be clearly mentioned. For substances subject to registration brief summaries of the information derived from application of Annex VII to XI (to REACH – i.e. of the results of testing (including non- animal testing) or other alternative means of generating information  required for registration purposes) must be given with a short reference, where appropriate, to the test methods used.

It should be noted that it is a requirement that other relevant information on adverse health effects must be included even when not required by the classification criteria.

FOR MIXTURES

For mixtures, it should be noted that the requirements for information were different according to Annex I of Commission Regulation (EU) No 453/2010 and the Annex of Commission Regulation (EU) 2015/83092 (i.e. the versions of Annex II of REACH in force from 1 December 2010 and that in force from 1 June 2015). Until 1 June 2015 it was information on relevant effects (based on DPD), as listed above, which were to be provided. Since 1 June 2015, the relevant hazard classes (based on CLP) for which information must be provided are the same as for substances (indeed the corresponding legal text no longer differentiates between the requirements for substances and mixtures with respect to these hazard classes). However it should be noted that in the case of mixtures for which relevant information on the component substances is available (e.g. LD50, acute toxicity estimates (ATE), LC50) this must also be provided in addition to information applying to the mixture as placed on the market.

For further information on how mixtures should be classified reference should be made to the CLP regulation itself (in particular Article 6 of CLP).

When a mixture has been classified according to CLP using an acute toxicity estimate (ATE), the value of the calculated ATEmix should be included in this subsection, for example using a structure as follows:

ATEmix (oral)

=

xxx mg/kg

ATEmix (dermal)

=

yyy mg/kg

ATEmix (inhal.)

=

z mg/l/4 h (vapours)

If information on the mixture itself is not available for a certain hazard class or differentiation but several substances in it have the same health effect, this effect may be mentioned for the mixture and not for the individual substances.

In the absence of specific data on the mixture regarding interactions between component substances, assumptions must not be made and instead the relevant health effects of each substance must be listed separately (see Annex II point 11.1.11.2.)

It should be noted that, as for substances, it is a requirement that other relevant information on adverse health effects must be included even when not required by the classification criteria.

92 Which replaces Annex II to Regulation (EU) No 453/2010.


<a id="echa-s11-page-102"></a>
**ECHA printed page 102** — [original PDF page 102](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=102)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 102](page_images/ECHA_2020_page_102.jpg)

This section needs to be checked for consistency in particular with the following sections:

- SECTION 2: Hazards identification

- SECTION 4: First aid measures

- SECTION 6: Accidental release measures

- SECTION 7: Handling and storage

- SECTION 8: Exposure controls/personal protection

- SECTION 9: Physical and Chemical properties

- SECTION 13: Disposal considerations

- SECTION 14: Transport information

- SECTION 15: Regulatory information

An example of how the structure of this section could look for the case of a substance is given below:

SECTION 11: Toxicological information

11.1 Information on hazard classes as defined in Regulation (EC) No 1272/2008

- Acute toxicity:

- Skin corrosion/irritation:

- Serious eye damage/irritation:

- Respiratory or skin sensitisation

- germ cell mutagenicity;

- carcinogenicity;

- reproductive toxicity;

- Summary of evaluation of the CMR properties;

- STOT-single exposure;

- STOT-repeated exposure;

- aspiration hazard:

Within each of the above relevant hazard classes the sub-structure could then be as follows, using the entry for Acute Toxicity as an example:


<a id="echa-s11-page-103"></a>
**ECHA printed page 103** — [original PDF page 103](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=103)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 103](page_images/ECHA_2020_page_103.jpg)

11.1.193 Acute Toxicity:

Method:

Species:

Routes of exposure:

Effective Dose:

Exposure time:

Results:

In the case of mixtures the structure can be similar to that given above for a substance, but it should be made clear whether data that is given apply to the mixture or its components.


---

<a id="s12"></a>


# 3.12 SDS SECTION 12 — Ecological information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s12-page-103"></a>
**ECHA printed page 103** — [original PDF page 103](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=103)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 103](page_images/ECHA_2020_page_103.jpg)

3.12 SDS SECTION 12: Ecological information

Text Annex II

This section of the safety data sheet shall provide information to enable evaluation of the environmental impact of the substance or mixture where it is released to the environment. Subsections 12.1 to 12.7 of the safety data sheet shall provide a short summary of the data including, where available, relevant test data and clearly indicating species, media, units, test duration and test conditions. This information may assist in handling spills, and evaluating waste treatment practices, control of release, accidental release measures and transport. If it is stated that a particular property does not apply (because the available data shows that the substance or mixture does not meet the criteria for classification) or if information on a particular property is not available, the reasons shall be indicated. Additionally, if a substance or mixture is not classified for other reasons (for example, due to the technical impossibility of obtaining the data or to inconclusive data) this should be clearly stated on the safety data sheet.

Some properties are substance specific, i.e. bioaccumulation, persistence and degradability, and that information shall be given, where available and appropriate, for each relevant substance in the mixture (i.e. those which are required to be listed in Section 3 of the safety data sheet and are hazardous to the environment or PBT/vPvB substances). Information shall also be provided for hazardous transformation products arising from the degradation of substances and mixtures.

The information in this section shall be consistent with the information provided in the registration and/or in the chemical safety report where required, and with the classification of the substance or mixture.

Where reliable and relevant experimental data are available, that data shall be provided and take precedence over information obtained from models.

No further clarification considered necessary (see General comments on entries in Section 12 as a whole at the end of this section).

93 Note that additional numbering and sub-structuring below the subsection level is not a legal requirement.


<a id="echa-s12-page-104"></a>
**ECHA printed page 104** — [original PDF page 104](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=104)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 104](page_images/ECHA_2020_page_104.jpg)

<a id="echa-sds-12-1"></a>
### 12.1 Toxicity

Text Annex II

Information on toxicity using data from tests performed on aquatic and/or terrestrial organisms shall be provided when available. This shall include relevant available data on aquatic toxicity, both acute and chronic for fish, crustaceans, algae and other aquatic plants. In addition, toxicity data on soil micro- and macroorganisms and other environmentally relevant organisms, such as birds, bees and plants, shall be included when available. Where the substance or mixture has inhibitory effects on the activity of microorganisms, the possible impact on sewage treatment plants shall be mentioned.

Where experimental data are not available, the supplier shall consider whether reliable and relevant information obtained from models can be provided.

For substances subject to registration, summaries of the information derived from the application of Annexes VII to XI of this Regulation shall be included.

No further clarification considered necessary (see General comments on entries in Section 12 as a whole at the end of this section).

<a id="echa-sds-12-2"></a>
### 12.2 Persistence and degradability

Text Annex II

Degradability is the potential for the substance or the appropriate substances in a mixture to degrade in the environment, either through biodegradation or other processes, such as oxidation or hydrolysis. Persistence is the lack of demonstration of degradation in the situations defined in Sections 1.1.1 and 1.2.1 of Annex XIII. Test results relevant to assess persistence and degradability shall be given where available. If degradation half-lives are quoted it must be indicated whether these half-lives refer to mineralisation or to primary degradation. The potential of the substance or certain substances in a mixture to degrade in sewage treatment plants shall also be mentioned.

Where experimental data are not available, the supplier shall consider whether reliable and relevant information obtained from models can be provided.

This information shall be given where available and appropriate, for each individual substance in the mixture which is required to be listed in Section 3 of the safety data sheet.

No further clarification considered necessary (see General comments on entries in Section 12 as a whole at the end of this section).

<a id="echa-sds-12-3"></a>
### 12.3 Bioaccumulative potential

Text Annex II

Bioaccumulative potential is the potential of the substance or certain substances in a mixture to accumulate in biota and, eventually, to pass through the food chain. Test results relevant to assess the bioaccumulative potential shall be given. This shall include reference to the octanol-water


<a id="echa-s12-page-105"></a>
**ECHA printed page 105** — [original PDF page 105](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=105)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 105](page_images/ECHA_2020_page_105.jpg)

partition coefficient (Kow) and bioconcentration factor (BCF), or other relevant parameters related to bioaccumulation, if available.

Where experimental data are not available, it shall be considered whether model predictions can be provided.

This information shall be given where available and appropriate, for each individual substance in the mixture which is required to be listed in Section 3 of the safety data sheet.

No further clarification considered necessary (see General comments on entries in Section 12 as a whole at the end of this section).

<a id="echa-sds-12-4"></a>
### 12.4 Mobility in soil

Text Annex II

Mobility in soil is the potential of the substance or the components of a mixture, if released to the environment, to move under natural forces to the groundwater or to a distance from the site of release. The potential for mobility in soil shall be given where available. Information on mobility in soil can be determined from relevant mobility data such as adsorption studies or leaching studies, known or predicted distribution to environmental compartments, or surface tension. For example, Koc values can be predicted from octanol/water partition coefficients (Kow). Leaching and mobility can be predicted from models.

This information shall be given where available and appropriate, for each individual substance in the mixture which is required to be listed in Section 3 of the safety data sheet.

Where experimental data is available, that data shall, in general, take precedence over models and predictions.

No further clarification considered necessary (see General comments on entries in Section 12 as a whole at the end of this section).

<a id="echa-sds-12-5"></a>
### 12.5 Results of PBT and vPvB assessment

Text Annex II

Where a chemical safety report is required, the results of the PBT and vPvB assessment as set out in the chemical safety report shall be given.

It should be noted that it is not necessary to give detailed information on the data used to come to the conclusion about the PBT or vPvB properties, particularly where the conclusion is that the product does not have these properties. A simple statement to this effect should suffice, for example:

“According to the results of its assessment, this substance is not a PBT or a vPvB” or

“This mixture does not contain any substances that are assessed to be a PBT or a vPvB”

However, where the criteria for PBT are met it is recommended to briefly indicate here the


<a id="echa-s12-page-106"></a>
**ECHA printed page 106** — [original PDF page 106](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=106)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 106](page_images/ECHA_2020_page_106.jpg)

reasons for which these are met as part of the results of the assessment which must in any case be given.

<a id="echa-sds-12-6"></a>
### 12.6 Endocrine disrupting properties

Text Annex II

Information on adverse effects on the environment caused by endocrine disrupting properties shall be provided where available, for the substances identified as having endocrine disrupting properties in subsection 2.3. This information shall consist of brief summaries of the information derived from application of the assessment criteria laid down in the corresponding Regulations ((EC) No 1907/2006, (EU) 2017/2100, (EU) 2018/605), that is relevant to assess endocrine disrupting properties for the environment.

Guidance on endocrine disruptors and their identification can be found at: https://echa.europa.eu/hot-topics/endocrine-disruptors  The type of information that might represent a “brief summary” of information on endocrine disrupting properties for the environment can be found in the published Biocidal Products Committee (BPC) opinion on 2,2-Dibromo-2-cyanoacetamide (DBNPA)94, page 8:  DBNPA has endocrine disrupting properties with respect to non-target organisms as it meets the criteria set out in section B of Regulation (EU) No 2017/2100. This conclusion is based on evidence from studies conducted on DBNPA in rats and studies conducted on bromide in rat, guppy and medaka in combination with additional information showing that the postulated Mode of Action affects amphibian metamorphosis, which is considered relevant at population level.

For substances where there are no endocrine disrupting properties for the environment a simple statement to this effect should suffice, for example:

“This substance does not have endocrine disrupting properties with respect to non-target organisms as it does not meet the criteria set out in section B of Regulation (EU) No 2017/2100.”

<a id="echa-sds-12-7"></a>
### 12.7 Other adverse effects

Text Annex II

Information on any other adverse effects on the environment shall be included where available, such as environmental fate (exposure), photochemical ozone creation potential, ozone depletion potential, or global warming potential.

General comments on entries in Section 12 as a whole

When preparing SDS for mixtures, it needs to be clear whether the data applies to the ingredients or to the mixture in its totality.

Particular attention needs to be paid when the mixture as a whole has been tested to

94 https://echa.europa.eu/documents/10162/085a4896-b067-bdbc-e38c-8f794e60e4f3


<a id="echa-s12-page-107"></a>
**ECHA printed page 107** — [original PDF page 107](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=107)

determine its aquatic toxicity, in such a case adequate acute toxicity LC50 or EC50 can be used to determine acute hazard according to the criteria that have been agreed for substances, but not for long-term hazard. It is not possible to apply acute toxicity in combination with environment fate test data (degradability and bioaccumulation) for long-term hazard classification because the data from degradability and bioaccumulation tests of mixtures cannot be interpreted; these are meaningful only for single substances (See CLP Regulation points 4.1.3.3.1. and 4.1.3.3.2.).

CLP also allows for the classification of mixtures for long-term hazard based on adequate chronic toxicity data (see point 4.1.3.3.4.). For further information on classification of mixtures for environmental hazards, see the (draft update) to the ECHA Guidance on the Application of the CLP Criteria95.

When writing this section, it should be specified whether the mentioned data originates from experimental data (testing results) or models (bridging rules etc.).

This section needs to be checked for consistency in particular with the following sections:

- SECTION 2: Hazards identification

- SECTION 3: Composition/information on ingredients

- SECTION 6: Accidental release measures – (i.e. precautions for environmental protection)

- SECTION 7: Handling and storage – (i.e. measures to prevent emissions (filters…))

- SECTION 9: Physical and Chemical properties – (i.e. log Kow, miscibility)

- SECTION 13: Disposal considerations

- SECTION 14: Transport information

- SECTION 15: Regulatory information

An example of how the structure of this section could look is given below:

SECTION 12: Ecological information

12.1 Toxicity

Acute (short-term) toxicity:

Fish:

Crustacea:

Algae/aquatic plants:

Other organisms:

Chronic (long-term) toxicity:

Fish:

95 Available at: https://echa.europa.eu/guidance-documents/guidance-on-clp  (page 145 on “4.1.4.3 Classification criteria for mixtures hazardous to the aquatic environment based on test data on the mixture as a whole”.


<a id="echa-s12-page-108"></a>
**ECHA printed page 108** — [original PDF page 108](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=108)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 108](page_images/ECHA_2020_page_108.jpg)

Crustacea:

Algae/aquatic plants:

Other organisms:

12.2 Persistence and degradability

Abiotic Degradation:

Physical- and photo-chemical elimination:

Biodegradation:

12.3 Bioaccumulative potential

Partition coefficient n-octanol /water (log Kow):

Bioconcentration factor (BCF):

12.4 Mobility in soil

Known or predicted distribution to environmental compartments:

Surface tension:

Adsorption/Desorption:

12.5 Results of PBT and vPvB assessment

12.6 Endocrine disrupting properties

12.7 Other adverse effects

<a id="echa-sds-12-8"></a>
### 12.8 Additional information


---

<a id="s13"></a>


# 3.13 SDS SECTION 13 — Disposal considerations

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s13-page-109"></a>
**ECHA printed page 109** — [original PDF page 109](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=109)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 109](page_images/ECHA_2020_page_109.jpg)

3.13 SDS SECTION 13: Disposal considerations

Text Annex II

This section of the safety data sheet shall provide information for proper waste management of the substance or mixture and/or its container to assist in the determination of safe and environmentally preferred waste management options, consistent with the requirements of Directive 2008/98/EC of the European Parliament and of the Council (96) by the Member State in which the safety data sheet is being supplied. Information relevant for the safety of persons conducting waste management activities shall complement the information given in Section 8.

Where a chemical safety report is required and where a waste stage analysis has been performed, the information on the waste management measures shall be consistent with the identified uses in the chemical safety report and the exposure scenarios from the chemical safety report set out in the annex to the safety data sheet.

To ensure that risks are adequately controlled at the waste stage, disposal must be in accordance with current applicable laws and regulations and material characteristics at the time of disposal. It should be kept in mind that insofar as the substance becomes a waste, REACH ceases to apply and waste legislation becomes the correct legal framework within which to operate.

If the treatment of the substance or mixture at the waste stage (surplus or waste resulting from the foreseeable use) presents a hazard, a description of the hazards arising and information on how to ensure safe handling should be given.

The appropriate treatment methods for both the substance or mixture waste itself and (where applicable) for any contaminated packaging waste (including nominally “empty” but un-cleaned packaging waste which still contains some of the substance or mixture) should be indicated, taking into account the waste hierarchy as defined in the Waste Framework Directive (i.e. preparation for re-use; recycling; other recovery, e.g. energy recovery; disposal)97.

Where other recommendations are applicable to the disposal of the substance or mixture used for its intended purpose, these recommendations may be quoted separately.

Where the use recommended by the supplier permits prediction of the origin of the waste it may be considered desirable to specify the relevant List of Wastes (LoW) Code98 (or for Norway the European Waste List EAL code).

<a id="echa-sds-13-1"></a>
### 13.1 Waste treatment methods

Text Annex II

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   96 Directive 2008/98/EC of the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (OJ L 312, 22.11.2008,p.3).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 97 For more info: https://ec.europa.eu/environment/waste/framework/ 98  The European Waste Catalogue (EWC) was replaced by a combined European List of  Wastes (LoW) via the Commission Decision of 3 May 2000 replacing Decision 94/3/EC establishing a list of wastes pursuant to Article 1(a) of Council Directive 75/442/EEC on waste and Council Decision 94/904/EC establishing a list of hazardous waste pursuant to Article 1(4) of Council Directive 91/689/EEC on hazardous waste (OJ L 226, 6.9.2000, p. 3).


<a id="echa-s13-page-110"></a>
**ECHA printed page 110** — [original PDF page 110](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=110)

This subsection of the safety data sheet shall:

(a) specify waste treatment containers and methods including the appropriate methods of waste treatment of both the substance or mixture and any contaminated packaging (for example incineration, recycling, landfilling);

(b) specify the physical/chemical properties that may affect waste treatment options;

(c) discourage sewage disposal;

(d) identify, where appropriate, any special precautions for any recommended waste treatment option.

Any relevant Union provisions relating to waste or, in their absence, any relevant national or regional provisions in force shall be referred to.

It should be noted that the phrase “Discourage sewage disposal“ in the legal text above (which is carried-over from the GHS text) is of course intended to indicate that disposal of the substance or mixture into sewerage systems is to be discouraged, rather than disposal of sewage per se as a literal reading might imply. This requirement to positively discourage can, for example, be implemented by including a phrase such as “Waste should99 not be disposed of by release to sewers”.

Suitable means for neutralising or deactivating product residues and waste may be specified. Special risks to safety, health or the environment that can arise when handling waste should be specified, e.g. risk of self ignition arising from interaction with certain materials.

Means of handling waste from used product or contaminated packaging waste which are known to be unsuitable should be stated if applicable.

Relevant information (e.g. the related H-codes as defined in Annex III “Properties of waste which render it hazardous” of Directive 2008/98/EC100) may be given to indicate whether or not any remaining quantities of unused substance or mixture are to be regarded as hazardous waste. Where this is done it should be made clear to recipients that where additional contaminants may be present as a result of the use of the substance/mixture these will need to be taken into account and assigned any additional H-codes applicable.

Local, national and European waste management legislation for the particular form of containment used must be complied with.

It should be noted that final decisions on the appropriate waste management method, in line with regional, national and European legislation, and possible adaptation to local conditions, remains the responsibility of the waste treatment operator.

An example of how the structure of this section could look is given below101:

99 “should” is used here rather than “must” since the legal text requires such disposal to be discouraged, not for it to be prohibited.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 100 Directive 2008/98/EC of the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives.

101 Note that additional numbering  and sub-structuring below the subsection level is not a legal requirement.


<a id="echa-s13-page-111"></a>
**ECHA printed page 111** — [original PDF page 111](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=111)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 111](page_images/ECHA_2020_page_111.jpg)

SECTION 13: Disposal considerations

13.1 Waste treatment methods

13.1.1 Product / Packaging disposal:

Waste codes / waste designations according to LoW:

13.1.2 Waste treatment-relevant information:

13.1.3 Sewage disposal-relevant information:

13.1.4 Other disposal recommendations:


---

<a id="s14"></a>


# 3.14 SDS SECTION 14 — Transport information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s14-page-111"></a>
**ECHA printed page 111** — [original PDF page 111](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=111)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 111](page_images/ECHA_2020_page_111.jpg)

3.14 SDS SECTION 14: Transport Information

Text Annex II

This section of the safety data sheet shall provide basic classification information for the transport/shipment of substances or mixtures mentioned in Section 1 by road, rail, sea, inland waterways or air. Where such information is not available or relevant this shall be stated.

Where relevant, this section shall provide information on the transport classification for each of the following international agreements which are transposing the UN Model Regulations for specific transport modes: the Agreement concerning the International Carriage of Dangerous Goods by Road (ADR), the Regulations concerning the International Carriage of Dangerous Goods by Rail (RID) and the European Agreement concerning the International Carriage of Dangerous Goods by Inland Waterways (ADN), all three of which have been implemented by Directive 2008/68/EC of the European Parliament and of the Council (102), as well as the International Maritime Dangerous Goods (IMDG) Code(103) for the transport of packaged goods and the relevant IMO codes for the transport of bulk cargo by sea (104), and the Technical Instructions for the Safe Transport of Dangerous Goods by Air (ICAO) (105).

<a id="echa-sds-14-1"></a>
### 14.1. UN number or ID number

The UN number or the ID number (i.e. the four-figure identification number of the substance, mixture or article preceded by the letters ‘UN’ or ‘ID’) from the UN Model Regulations, IMDG, ADR, RID, ADN or ICAO TI shall be provided.

<a id="echa-sds-14-2"></a>
### 14.2. UN proper shipping name

The proper shipping name as provided in column 2, ‘Name and description’, of Table A of Chapter

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   102 Directive 2008/68/EC of the European Parliament and of the Council of 24 September 2008 on the inland transport of dangerous goods (OJ L 260, 30.9.2008, p. 13) 103 Compliance with the IMDG Code is mandatory for the carriage of packaged dangerous goods by sea as provided for in Chapter VII/ Reg. 3 of SOLAS and MARPOL Annex III Prevention of Pollution by Harmful Substances Carried by Sea in Packaged Form. 104 The IMO has developed various legal instruments related to dangerous and polluting goods differentiating between how the goods are carried (packaged and bulk) and by type of cargo (solid, liquid and liquefied gases). Rules on the carriage of dangerous cargoes and the ships that carry these cargoes are found in the International Convention for the Safety of Life at Sea (SOLAS, 1974), as amended, and the International Convention on Maritime Pollution (MARPOL 73/78), as amended. These conventions are supplemented by the following codes: IMDG, IMSBC, IBC and IGC. 105 IATA, 2007-2008 edition.


<a id="echa-s14-page-112"></a>
**ECHA printed page 112** — [original PDF page 112](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=112)

3.2 Dangerous Goods List of the UN Model Regulations, in ADR, in RID and in Tables A and C of Chapter 3.2 of ADN, supplemented, when applicable, with the technical name in brackets as required, shall be provided, unless it was used as the product identifier in subsection 1.1. If the UN number and the proper shipping name remain unchanged in different transport modes, it is not necessary to repeat this information. As regards maritime transport, in addition to the UN proper shipping name, the technical name for goods to be transported covered by the IMDG Code shall be indicated, where appropriate.

<a id="echa-sds-14-3"></a>
### 14.3. Transport hazard class(es)

The transport hazard class (and subsidiary risks) assigned to the substances or mixtures on the basis of the predominant hazard that they present according to the UN Model Regulations shall be provided. As regards inland transport, the transport hazard class (and subsidiary risks) assigned to the substances or mixtures on the basis of the predominant hazard that they present according to ADR, RID and ADN shall be provided.

<a id="echa-sds-14-4"></a>
### 14.4. Packing group

The packing group number from the UN Model Regulations shall be provided, if applicable, as required by the UN Model Regulations, ADR, RID and ADN. The packing group number is assigned to certain substances in accordance with their degree of hazard.

<a id="echa-sds-14-5"></a>
### 14.5. Environmental hazards

It shall be indicated whether the substance or mixture is environmentally hazardous according to the criteria of the UN Model Regulations (as reflected in ADR, RID and ADN), and whether it is a marine pollutant according to the IMDG Code and the Emergency Response Procedures for Ships Carrying Dangerous Goods. If the substance or mixture is authorised or intended for carriage by inland waterways in tank-vessels, it shall be indicated whether the substance or mixture is environmentally hazardous in tank-vessels only according to the ADN.

<a id="echa-sds-14-6"></a>
### 14.6. Special precautions for user

Information shall be provided on any special precautions which a user should or must take or be aware of in connection with transport or conveyance either within or outside his premises, for all relevant modes of transport.

<a id="echa-sds-14-7"></a>
### 14.7. Maritime transport in bulk according to IMO instruments

This subsection only applies when cargoes are intended to be carried in bulk according to IMO instruments: Chapter VI or Chapter VII of SOLAS (106), Annex II or Annex V of MARPOL, the IBC Code (107), the IMSBC Code (108), and the IGC Code (109) or its earlier versions, namely EGC Code

(110) or GC Code (111)).

As regards liquid bulk cargoes, the product name shall be provided (if different from that given in subsection 1.1.) as required by the shipment document and in accordance with the name used in the lists of product names given in chapters 17 or 18 of the IBC Code or the latest edition of the IMO’s Maritime Environment Protection Committee (MEPC).2/Circular (112). Ship type required and pollution category shall be indicated, as well as the IMO hazard class, in accordance with Annex I

106 SOLAS means the International Convention for the Safety of Life at Sea, 1974, as amended. 107 IBC Code means the International Code for the Construction and Equipment of Ships carrying dangerous Chemicals in Bulk, as amended. 108 IMSBC Code means the International Maritime Solid Bulk Cargoes Code, as amended. 109 IGC Code means the International Code for the Construction and Equipment of Ships Carrying Liquefied Gases in Bulk, including applicable amendments in accordance with which the vessel has been certified.

110 EGC Code means the Code for Existing Ships Carrying Liquefied Gases in Bulk, as amended. 111 GC Code means the Code for the Construction and Equipment of Ships Carrying Liquefied Gases in Bulk (Gas Carrier Code), as amended. 112 MEPC.2/Circular, Provisional categorisation of liquid substances, version 19, effective 17 December 2013.


<a id="echa-s14-page-113"></a>
**ECHA printed page 113** — [original PDF page 113](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=113)

(3) B (a) of Directive 2002/59/EC of the European Parliament and of the Council (113).

As regards solid bulk cargoes, the bulk cargo shipping name shall be provided. It shall be indicated whether or not the cargo is considered harmful to the marine environment (HME) according to Annex V of MARPOL, whether it is a material hazardous only in bulk (MHB) (114 ) according to the IMSBC Code, and as which cargo group it should be considered according to the IMSBC.

As regards liquefied gas cargoes in bulk, the product name and the ship type required according to the IGC Code or its earlier versions, namely EGC Code or GC Code shall be provided.

The text of Annex II to REACH specifies in point 0.5 the following recommendations, relevant to Section 14 of the SDS:

“Additional safety and environmental information is required to address the needs of seafarers and other transport workers in the bulk transport of dangerous goods in sea-going or inland navigation bulk carriers or tank-vessels subject to International Maritime Organisation (IMO) or national regulations. Subsection 14.7 recommends the inclusion of basic classification information when such cargoes are transported in bulk according to relevant IMO instruments. In addition, ships carrying oil or oil fuel, as defined in Annex I of MARPOL, in bulk or bunkering oil fuel are required, before loading, to be provided with a “material safety data sheet” in accordance with the IMO’s Maritime Safety Committee (MSC) resolution “Recommendations for Material Safety Data Sheets (MSDS) for MARPOL Annex I Oil Cargo and Oil Fuel” (MSC.286(86)). Therefore, in order to have one harmonised safety data sheet for maritime and non-maritime use, the additional provisions of Resolution MSC.286(86) may be included in the safety data sheets, where appropriate, for marine transport of MARPOL Annex I cargoes and marine fuel oils.”

It should be noted with respect to the air transport information that the IATA Dangerous Goods Regulations (IATA DGR) incorporate all the requirements of the ICAO (in fact the footnote in the legal text currently refers to an IATA publication rather than an ICAO original).

Information is specifically required on UN number, proper shipping name, transport hazard classes, packing group, environmental hazards, special precautions for users and information on transport in bulk by sea when applicable. The proper shipping name may slightly vary in different transport modes, but if it remains unchanged then it does not have to be repeated.

In practice, additional information which would normally be included in this Section could include:

- For ADR/RID/ADN: Digit of the hazard labels (main hazard and sub hazard if existing), classification code in case of class 1.

- For ADN tank vessels: The digits of the hazard labels and hazard Codes as shown in column 5 of table C in ADN chapter 3.2

- For IMDG Code: Class and subsidiary risks, and indication of marine pollutant if applicable.

- For ICAO-TI /IATA-DGR: Class and subsidiary risk.

Where information on “Special precautions for user” that would otherwise appear in subsection

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   113 Directive 2002/59/EC of the European Parliament and of the Council of 27 June 2002 establishing a Community vessel traffic monitoring and information system and repealing Council Directive 93/75/EEC (OJ L 208, 5.8.2002, p. 10). 114 Materials hazardous only in bulk (MHB) means materials which may possess chemical hazards when carried in bulk other than materials classified as dangerous goods in the IMDG Code.


<a id="echa-s14-page-114"></a>
**ECHA printed page 114** — [original PDF page 114](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=114)

14.6 is already given elsewhere in the SDS a cross-reference to its location may be made to avoid repetition. A subsection may not simply be left empty.

In addition, other applicable information (e.g. transport category; tunnel restriction code, segregation group, special provisions as well as exemptions (viscous substances, multilateral agreements, etc.) might be useful. Where such additional information is provided which goes beyond the actual requirements of the legislation the compiler should be confident that he will be able to keep it current. Otherwise reference can be made to the relevant effective amendments of the full text of the applicable regulations.

Additional information ADN:

According to ADN, extended classification criteria are required for liquids carried in tank vessels, e.g. for Environmental hazards the GHS criteria acute 2, acute 3 and chronic 3. This information is only relevant for bulk liquids filled into cargo tanks of tank vessels and classified as dangerous according the ADN criteria.

If applicable, this extended classification information is included as hazard code(s) in the dangerous goods description according to ADN 5.4.1.1.2, e.g.

UN 1114 BENZENE, 3 (N3, CMR), II

For materials only intended to be carried in packages or tanks (tank containers or tank vehicles), indication of classification for tank-vessels only is not necessary.

Additional information IMDG:

According to section 5.4.1.5.11.1 of the IMDG Code, the segregation group needs to be indicated for substances which belong - in the opinion of the consignor - to one of the segregation groups named in 3.1.4.4, but are classified under a “Not otherwise specified” (“N.O.S.”) entry not included in the list of substances listed under this segregation group115. There is, however, no explicit requirement under REACH to transfer this segregation group information to the SDS, although it may be desirable to do so.

"Further information on maritime transport in bulk according to IMO instruments:

Only substances named in the IMO instruments or intended to be included them, are allowed to be shipped in bulk. Therefore, this information is only necessary for substances, which are intended to be carried in bulk. Note that if it is not intended that the substance/mixture be transported in bulk a statement to this effect should be made under subsection 14.7 as it should not be left completely blank, for example: “Product is not transported in bulk.” or “Product is not allowed to be transported in bulk.”

Gaseous bulk cargoes

Provide product name, ship type e.g. “Methane (LNG), Ship Type: 2G”, or “Ammonia, anhydrous, Ship Type: 2G/2PG”.

Liquid bulk cargoes

Provide product name, ship type and pollution category given in IBC code e.g. “Acetic anhydride, Pollution Category: Z, Ship Type: 2”, or “Sulphuric acid, Pollution Category: Y, Ship

115 There is, however, no explicit requirement under REACH to transfer this segregation group information to the SDS, although it may be desirable to do so.


<a id="echa-s14-page-115"></a>
**ECHA printed page 115** — [original PDF page 115](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=115)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 115](page_images/ECHA_2020_page_115.jpg)

Type: 2”.

Solid bulk cargoes

Provide bulk cargo shipping name (BCSN) and information weather material is hazardous to marine environment (HME) or material hazardous in bulk (MHB), other information like Group information may be given. e.g. “COAL TAR PITCH, Group B, HME: yes, MHB: TX”, or “POTASSIUM SULPHATE, Group C, HME: no, MHB: no”.

An example illustrating the required subsection headings for Section 14 is given below:

"SECTION 14: Transport information

14.1. UN number or ID number

14.2. UN proper shipping name

14.3. Transport hazard class(es)

14.4. Packing group

14.5. Environmental hazards

14.6. Special precautions for user

14.7. Maritime transport in bulk according to IMO instruments


---

<a id="s15"></a>


# 3.15 SDS SECTION 15 — Regulatory information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s15-page-115"></a>
**ECHA printed page 115** — [original PDF page 115](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=115)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 115](page_images/ECHA_2020_page_115.jpg)

3.15 SDS SECTION 15: Regulatory information

Text Annex II

This section of the safety data sheet shall describe the other regulatory information on the substance or mixture that is not already provided in the safety data sheet (such as whether the substance or mixture is subject to Regulation (EC) No 1005/2009 of the European Parliament and of the Council of 16 September 2009 on substances that deplete the ozone layer (116), Regulation (EC) No 850/2004 of the European Parliament and of the Council of 29 April 2004 on persistent organic pollutants and amending Directive 79/117/EEC  (117) or Regulation (EC) No 649/2012 of the European Parliament and of the Council of 4 July 20012 concerning the export and import of dangerous chemicals (118).

<a id="echa-sds-15-1"></a>
### 15.1 Safety, health and environmental regulations/legislation specific for the

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   116 Regulation (EC) No 1005/2009 of the European Parliament and of the Council of 16 September 2009 on substances that deplete the ozone layer (OJ L 286, 31.10.2009, p.1).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 117 Regulation (EC) No 850/2004 of the European Parliament and of the Council of 29 April 2004 on persistent organic pollutants and amending Directive 79/117/EEC (OJ L 158, 30.4.2004, p.7). Note that Regulation (C) 850/2004 has been repealed and replaced by Regulation (EC) 2019/1021.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 118  Regulation (EU) No 649/2012 of the European Parliament and of the Council of 4 July 2012 concerning the export and import of hazardous chemicals (OJ L 201, 27.7.2012, p.60).


<a id="echa-s15-page-116"></a>
**ECHA printed page 116** — [original PDF page 116](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=116)

substance or mixture

Text Annex II

Information shall be provided regarding relevant Union safety, health and environmental provisions (for example Seveso category/named substances in Annex I to Council Directive 96/82/EC (119)) or regarding the national regulatory status of the substance or mixture (including the substances in the mixture), including advice on action that should be taken by the recipient as a result of these provisions. Where relevant the national laws of the relevant Member States which implement these provisions and any other national measures that may be relevant shall be mentioned.

If the substance or mixture covered by this safety data sheet is the subject of specific provisions in relation to the protection of human health or the environment at Union level (such as authorisations given under Title VII or restrictions under Title VIII) these provisions shall be mentioned. Where an authorisation granted under Title VII imposes conditions or monitoring arrangements to a downstream user of the substance or mixture, they shall be provided.

In addition to the information on specific provisions and regulations given in the legal text above the following type of information may be included in this subsection (this is a non- exhaustive list):

- national laws of the relevant Member States which implement provisions such as the young worker directive and directive on pregnant workers, since these may require that young workers or pregnant workers do not work with certain substances and mixtures;

- information from the plant protection and biocides legislation, such as approval/authorisation status/numbers, additional labelling information from the specific legislation;

- information on applicable elements of the Water Framework Directive;

- information on EU Directive(s) related to Environmental Quality Standards (EQS)  - e.g. Directive 2008/105/EC120 – where applicable;

- for paint and varnish products, if applicable a reference to Directive 2004/42/EC121 on the limitation of emissions of volatile organic compounds may be included here;

- for detergents, the ingredient declaration according to the Detergent Regulation 648/2004/EC122 (if not already given in subsection 3.2);

- national information on the regulatory status of the substance or mixture (including the substances in the mixture), including advice regarding action that should be taken by the recipient as a result of these provisions;

- national laws of the relevant Member States which implement these provisions;

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   119 Council Directive 96/82/EC of 9 December 1996 on the control of major-accident hazards involving dangerous substances (OJ L 10, 14.1.1997, p.13).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 120 Directive 2008/105/EC of the European Parliament and of the Council of 16 December 2008 on environmental quality standards in the field of water policy, amending and subsequently repealing Council Directives 82/176/EEC, 83/513/EEC, 84/156/EEC, 84/491/EEC, 86/280/EEC and amending Directive 2000/60/EC of the European Parliament and of the Council (O.J. L 348/84  24.12.2008, pages 84-97).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 121 Directive 2004/42/EC of the European Parliament and of the Council of 21 April 2004 on the limitation of emissions of volatile organic compounds due to the use of organic solvents in certain paints and varnishes and vehicle refinishing products and amending Directive 1999/13/EC (O.J. L 143/87 30.4.2004, pages 87-96).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 122 Regulation (EC) No 648/2004 of the European Parliament and of the Council of 31 March 2004 on detergents (O.J. L 104/1 8.4.2004, pages 1-35).


<a id="echa-s15-page-117"></a>
**ECHA printed page 117** — [original PDF page 117](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=117)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 117](page_images/ECHA_2020_page_117.jpg)

- any other national measures that may be relevant e.g. such as (this is a non- exhaustive list):

In Germany:

i. Water hazard classes (Wassergefährdungsklassen)

ii. Technical instruction air (TA-Luft)

iii. Technical rules for hazardous substances (Technische Regeln für Gefahrstoffe), e.g. TRGS 220 "National aspects when compiling safety data sheets".

In France:

i. tableaux de maladies professionnelles

ii. nomenclature des installations classées pour la protection de l‘environnement

In the Netherlands:

i. Lijst van kankerverwekkende, mutagene, en voor de voortplanting giftige stoffen SZW.

ii. De Algemenebeoordelingsmethodiek Water (ABM)

iii. De Nederlandse Emissierichtlijn (NeR)

In Denmark:

Lister over stoffer og processer, der anses for at være kræftfremkaldende

It should be noted that Section 15.1 requires knowledge of relevant Member States’ regulations and provisions, and as such cannot simply be translated from another language version. The national regulations should also be given in their original language.

Where an authorisation has been granted, the authorisation decision may contain obligations that concern the downstream user. These obligations have to be described in this section, as part of the required update without delay under Article 31(9), once an authorisation has been granted. These can be, for example, monitoring arrangements for downstream users including any requirement to transmit the information collected.

<a id="echa-sds-15-2"></a>
### 15.2 Chemical Safety Assessment

Text Annex II

This subsection of the safety data sheet shall indicate whether the supplier has carried out a chemical safety assessment for the substance or the mixture.

An example of how the structure of this section could look like is given below:

SECTION 15: Regulatory Information

15.1 Safety, health and environmental regulations/legislation specific for the substance or mixture


<a id="echa-s15-page-118"></a>
**ECHA printed page 118** — [original PDF page 118](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=118)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 118](page_images/ECHA_2020_page_118.jpg)

EU regulations

Authorisations and/or restrictions on use:

Authorisations:

Restrictions on use:

Other EU regulations:

Information according 1999/13/EC about limitation of emissions of volatile organic compounds (VOC-guideline)

National regulations (Germany):

Restrictions of occupation:

Störfallverordnung (12.BImSchV):

Wassergefährdungsklasse (water hazard class):

Technische Anleitung Luft (TA-Luft):

Other regulations, restrictions and prohibition regulations:

15.2 Chemical Safety Assessment:

No Chemical Safety Assessment has been carried out for this substance/mixture by the supplier.


---

<a id="s16"></a>


# 3.16 SDS SECTION 16 — Other information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-s16-page-118"></a>
**ECHA printed page 118** — [original PDF page 118](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=118)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 118](page_images/ECHA_2020_page_118.jpg)

3.16 SDS SECTION 16: Other information

Text Annex II

This section of the safety data sheet shall contain other information that is not included in Sections 1 to 15, including information on the revision of the safety data sheet such as:

(a) in the case of a revised safety data sheet, a clear indication of where changes have been made to the previous version of the safety data sheet, unless such indication is given elsewhere in the safety data sheet, with an explanation of the changes, if appropriate. A supplier of a substance or mixture shall be able to provide an explanation of the changes upon request;

(b) a key or legend to abbreviations and acronyms used in the safety data sheet;

(c) key literature references and sources for data;

(d) in the case of mixtures, an indication of which of the methods of evaluating information referred to in Article 9 of Regulation (EC) No 1272/2008 was used for the purpose of classification;

(e) a list of relevant hazard statements and/or precautionary statements. Write out the full text of any statements which are not written out in full under Sections 2 to 15;

(f) advice on any training appropriate for workers to ensure protection of human health and the environment.


<a id="echa-s16-page-119"></a>
**ECHA printed page 119** — [original PDF page 119](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=119)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 119](page_images/ECHA_2020_page_119.jpg)

This section must be used to include any additional relevant information, of the types listed in the legal text above that has not already been included in any of the previous Sections.

This section may additionally include an index table or table of contents for the attached exposure scenarios. If this is included here, a reference to it can be introduced in subsection 1.2.

In the case of mixtures, details must be provided here on the basis used to determine the classification of the mixture for the hazard classes where the classification criteria are met and where the classification(s) has been given under subsections 2.1 or 3.2 without the method used to derive it/them123. It is not necessary to list the basis for determining that a mixture does not meet the classification criteria for a particular hazard class. The example structure including the table below provides an example of how this information may be presented. Note that elements of information concerning the classification assigned and the procedure used to derive it, given in the heading and in the table under SECTION 16 bullet (iv) within the example below, could alternatively be placed in SECTION 2 of the SDS.

If companies wish to include disclaimers in the SDS, these may be placed outside any of the defined Sections to make clear that these are not part of the specified format and content. Note that disclaimers cannot be used to avoid the compliance of legal requirements set in Annex II.

Note that in the particular case of SECTION 16 there are no specified subsection numbers or titles in Part B of Annex II. Any additional numbering and sub-structuring within this SECTION is at the compiler’s discretion and not a legal requirement.

An example of how the structure of this SECTION could look is given below. The example is populated (under point (iv) only) to illustrate both a possible layout and content of the sub- structuring of the information on classification and procedure for classification of a simple mixture (e.g. an aqueous solution) within this SECTION.

SECTION 16: Other information

(i) Indication of changes:

(ii) Abbreviations and acronyms:

(ii) Key literature references and sources for data

(iv) Classification and procedure used to derive the classification for mixtures according to Regulation (EC) 1272/2008 [CLP]:

Classification according to Regulation (EC) Nr. 1272/2008 Classification procedure

Flam. Liq. 2, H225 On basis of test data

123 If both the relevant classifications and the methods used to derive them have already been given elsewhere in the SDS then this information need not be duplicated here.


<a id="echa-s16-page-120"></a>
**ECHA printed page 120** — [original PDF page 120](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=120)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 120](page_images/ECHA_2020_page_120.jpg)

Acute Tox. 3, H301 Calculation method

Acute Tox. 3, H311 Calculation method

Acute Tox. 3, H331 Calculation method

STOT SE 1, H370 Calculation method

(v) Relevant H-statements (number and full text):

(vi) Training advice:

(vii) Further information:

Other possible evaluation methods to be used for classifications (see Article 9 of the CLP Regulation) are for example:

- On basis of test data

- Calculation method.

- Bridging principle "Dilution".

- Bridging principle "Batching".

- Bridging principle "Concentration of highly hazardous mixtures".

- Bridging principle "Interpolation within one toxicity category".

- Bridging principle "Substantially similar mixtures".

- Bridging principle "Aerosols".

- Expert judgement

- Weight of evidence

- Human experience

- Minimum classification


---

<a id="app1"></a>


# Appendix 1 — Exposure scenario information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app1-page-121"></a>
**ECHA printed page 121** — [original PDF page 121](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=121)

Appendix 1. Including relevant exposure scenario information into safety data sheets

Possible options for inclusion of relevant exposure scenario information for a substance into a safety data sheet have been explained in chapters 2.22 and 2.23 of this guidance. This Appendix provides additional guidance on this topic.  Transmission of information on safe use down the supply chain  The CSR for a substance may include one or more exposure scenarios in its heading 9 Exposure Assessment. The exposure scenarios in the CSR are meant to document the conditions of safe use (operational conditions (OC) and risk management measures (RMM)) that have been assessed by the registrant. Each of the exposure scenarios addresses one or more identified uses. Exposure estimate and, where feasible, risk characterisation are required for each exposure scenario in order to demonstrate adequate control of risks for human health and for the environment. REACH requires that the registrant (or any actor in the supply chain who is required to prepare a CSR) places the relevant exposure scenarios in an annex to the SDS (making it an extended safety data sheet) he supplies his downstream users further down the supply chain. The purpose of the exposure scenario in the communication to downstream users is to provide guidance on how to use the substance in a way that control of risks is ensured. For this reason, the information in the exposure scenarios annexed to the SDS for a substance should be focused on what the recipients of the SDS need to know in order to ensure safe use of the substance. It is however also required that there be consistency between the exposure scenario information in the CSR and the exposure scenario(s) attached to the SDS. The exposure scenario(s) attached to the SDS must cover all uses at all life cycle stages that are relevant for the recipient of the substance. This means that the exposure scenario(s) has/(have) to address specific uses of immediate downstream users and uses further down the supply chain for which conditions of safe use have been documented in the CSR 124. In order to fulfil this requirement, registrants (or downstream users preparing the CSR) need to understand the supply chain of the substance in the market, the uses of the substance by their customers and foreseeable uses of the substance further down the supply chain. Conditions of safe use (and related exposure scenarios) may be different for each individual use or these may be the same for a group of uses. For this reason, the number of exposure scenarios included in the SDS for a specific substance may vary depending on the number of individual uses or groups of uses covered for the substance125. If a substance ends up in different supply chains (with different uses and conditions of use), exposure scenarios attached to the SDS have to cover uses and use conditions that are relevant for each supply chain. Communication within the supply chain and support from sector organizations are key elements to help registrants (or downstream users preparing the CSR) to identify relevant exposure scenarios to be attached to the SDSs. The attachment to SDSs of all exposure scenarios covering all identified uses without taking into account their relevance for downstream users to whom these are addressed should be avoided.

When a registrant considers the use of scaling to be applicable for his substance he has to explicitly indicate, for each specific use (and exposure scenario), applicable scaling options including which determinants of the exposure can be modified by scaling and the specific scaling tool(s) that can be used (e.g. an algorithm or an IT tool)126. It is furthermore important that information on scaling is communicated by downstream users when extended SDSs are

124 Additional information on ESs for SDS and exposure scenario for and CSR is available in the ECHA Guidance on information requirement and CSA Part D echa.europa.eu/guidance-documents/guidance-on-information-requirements- and-chemical-safety-assessment.

125 Note that for a supplier of a substance manufactured or imported at an annual volume of below 10 tpa and therefore not requiring a CSA there may legitimately be no ESs at all attached to the SDS.

126 See Guidance for downstream users for more details (echa.europa.eu/guidance-documents/guidance-on-reach).


<a id="echa-app1-page-122"></a>
**ECHA printed page 122** — [original PDF page 122](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=122)

prepared by them for communication of safety information to their customers further down the supply chain.

The information in the extended SDS may include advice that refers to uses and life cycle stages beyond “downstream uses” as intended by REACH (e.g. uses by consumers, life cycle of articles, waste stage etc..). In such a case, downstream users receiving extended SDS information are expected to:

- inform/instruct users of substances or mixtures who are members of the general public, i.e., consumers, even though no safety data sheet is required to be provided to them,

- fulfil their duties related to safety or emission behaviour of articles supplied by them, as laid down in other legislation (e.g. toys, construction products), and to comply with their duties under Article 33 (if they are article producers) and

- fulfil their duty to select appropriate waste disposal routes.

Inclusion into the SDS of exposure scenario information relevant for the immediate downstream user and subsequent users

The ultimate aim of a supplier of a substance who provides an extended SDS to his immediate downstream users is to communicate clear and understandable information on how the substance (either as such or in a mixture) can be used “safely” by them. Registrants or downstream users preparing a CSR for a substance for which an exposure scenario is required, are required to attach relevant exposure scenario(s) to the safety data sheet for the products (containing the substance) they deliver to their immediate downstream users. Additional information is available in chapters 2.22 and 2.23.

When a downstream user receives an exposure scenario for a substance from his supplier, he has to check if his use and conditions of use are covered by the exposure scenario. Practical advice on how to check whether a use is covered and how to choose and carry out the appropriate action is provided in chapters 4 and 5 of the Guidance for downstream users and in the Practical guide “How downstream users can handle exposure scenarios”127.

A downstream user of a substance may supply that substance in his products further down the supply chain. This is typically the case for formulators using substances in their mixtures and supplying mixtures to other formulators and/or to end users. A downstream user supplying a substance (e.g. in a mixture), for which an extended SDS has been provided by the supplier of the substance, has to check whether the foreseeable uses of his mixtures (containing the substance) are covered in the exposure scenarios he has received for the substance. If uses are covered, the downstream user has to include the exposure scenario (of the substance) into the SDS of his mixtures if:

- an SDS is required for the mixture and

- the concentration of the substance in the mixture exceeds the limits indicated in Article 14 of REACH.

Depending on how diverse the OCs and RMMs for the substances in the mixture will be further downstream, the inclusion of the exposure scenario can be carried out in different ways, as described in chapter 2.23.

Downstream users may have different levels of technical competence to identify, apply

127 At echa.europa.eu/practical-guides.


<a id="echa-app1-page-123"></a>
**ECHA printed page 123** — [original PDF page 123](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=123)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 123](page_images/ECHA_2020_page_123.jpg)

and recommend appropriate measures to control risks identified in the SDS supplied to them. Thus, when compiling the extended SDS for a substance, the supplier (manufacturer, importer or downstream user) will need to anticipate the role of his immediate downstream user in the supply chain and to present the information in a way that enables the immediate downstream user to identify the measures that are relevant to recommend to his own customers.

It is therefore crucial that the supplier prepares an exposure scenario that contains practically useful information related to the downstream user’s processes, structured in a “possibly standardized” format and written in a technical language that is understandable to the downstream user. More detailed information on exposure scenarios for communication can be found in Chesar user manual 2128. Furthermore, guidance for formulators on how to forward information on mixtures down the supply chain is provided in the Guidance for Downstream users129 (chapter 7).

The supplier is expected to phrase the OC and RMMs so that these can be included and recommended in the SDS for a mixture without need for re-phrasing130 by the immediate downstream users (e.g. using so called “standard phrases”131).

Distributors

Distributors, even though they are not downstream users under REACH, have a fundamental role in the communication flow up and down the supply chain, including via the SDS. They have a key position as they may have direct contact with the manufacturer/importer and the end-user of the substance. Under REACH, the customer of a distributor is considered as an immediate downstream user of the registrant. It is therefore recommended that the registrant actively approaches the distributors to seek agreement on how the registrant can increase his knowledge on the conditions of use in the distributor’s market, for the purposes of the exposure scenario and other SDS information without requiring the distributor to disclose confidential business information (CBI). More detailed information on the role and obligations of the distributor are provided in the Guidance for downstream users.

The exposure scenario and corresponding Sections in the safety data sheet.  Table 3 gives an overview of the relationship between the SDS sections and the standard entries of the exposure scenario.

Depending on the hazard profile of the substance, the broadness of the market and the structure of the supply chain, there is a variety of options to modify the principal organisation of information in the exposure scenarios and the extended SDSs, e.g.:

- Section 2 of the exposure scenario could be further differentiated into exposure routes and exposure patterns. It can also be useful to link the risk management advice per route of exposure and endpoint directly with the relevant DNEL and exposure prediction.

128 Available at chesar.echa.europa.eu/support. Please note that it is up to the individual registrant to decide which exposure scenario format he wants to use, as long as the content of the exposure scenario is compliant with the requirements set out in Annex I of REACH.

129 echa.europa.eu/guidance-documents/guidance-on-reach.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 130 The standard phrases for risk management measures (as contained in the RMM catalogue indicated in the last section of this Appendix) should therefore be constructed  in such a way that these are understandable to all actors in the supply chain.

131 See the last subchapter of this annex for more information on one available catalogue of standard phrases.


<a id="echa-app1-page-124"></a>
**ECHA printed page 124** — [original PDF page 124](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=124)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 124](page_images/ECHA_2020_page_124.jpg)

- In a broad exposure scenario for a substance with only one or two hazard endpoints of concern, it may also be possible to list the specific RMMs for certain activities in Section 2 of one  exposure scenario.

Table 2 Relationship between exposure scenario and SDS Sections

ES section SDS Section(s)

Short title of the exposure scenario 1.2

Operational conditions and risk management measures 7 + 8

Control of workers exposure

Product characteristic 7 + 8 + 9

Amounts used 7 + 8

Frequency and duration of use 7 + 8

Human factors not influenced by risk management 7 + 8

Technical conditions and measures at process level (source) to prevent release

7 + 8

Technical conditions and measures to control dispersion from source towards the worker

7 + 8

Organisational measures to prevent/limit releases, dispersion and exposure

(5, 6), 7, 8

Conditions and measures related to personal protection, hygiene and health evaluation

(5, 6), 7, 8

Other conditions affecting workers exposure 7 + 8

Control of consumer exposure132

Product characteristic 7 + 8 + 9

Amounts used 7 + 8

Frequency and duration of use 7 + 8

Other conditions affecting consumers exposure 7 + 8

Control of environmental exposure

Product characteristic 7 + 8 + 9

Amounts used 7 + 8

Frequency and duration of use 7 + 8

132 Note that specific information on consumer exposure in Section 8 of the SDS is not a legal requirement.


<a id="echa-app1-page-125"></a>
**ECHA printed page 125** — [original PDF page 125](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=125)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 125](page_images/ECHA_2020_page_125.jpg)

Environmental factors not influenced by risk management

Technical conditions and measures at process level (source) to prevent release

7

Technical onsite conditions and measures to reduce or limit discharges, air emissions and releases to soil

7 + 8

Organisational measures to prevent/limit release from site 6 + 7 + 8

Conditions and measures related to municipal sewage treatment plant 8 + 13

Conditions and measures related to external treatment of waste for disposal

13

Conditions and measures related to external recovery of waste 13

Other given operational conditions affecting environmental exposure 7

Annex II to REACH sets the requirements for how to structure the measures for safe handling, protecting the environment and controlling of risks in Sections 7 and 8 of the SDS. These Sections are described in detail in subchapters 3.7 and 3.8 of this guidance. Annex II of REACH indicates also (for Sections 7 and 8 of the SDS) that where a CSR is required for the substance, the information in these sections has to be consistent with the information given in the CSR for the identified uses and related exposure scenario and that where an exposure scenario is attached to the SDS, information on exposure controls (subsection 8.2) can be provided in the exposure scenario only and it does not have to be duplicated in subsection 8.2 of the SDS.

In order to implement these requirements in a consistent and user-friendly way, the following guidelines133 should be applied:

- Annex II distinguishes between occupational conditions in subsections 7.1 - “precautions for safe handling” of the substance or mixture - and “exposure controls” in subsection 8.2). Certain measures however are mentioned in both sections.

- Annex II requires that the language used in an SDS is clear and specific. For example statements like “avoid breathing vapours” or “avoid skin contact” would not fulfil the requirements for description of how prevention or control of exposure can be achieved134.

- The description of RMMs related to all uses covered in the annexed exposure scenarios must be included in Section 8 or in the exposure scenarios attached to the SDS (if applicable). When RMM information is provided in the exposure scenario, it is recommended to provide specific reference to relevant exposure scenarios containing the information in subsection 8.2 of the SDS. It is also recommended to provide a summary of RMM (e.g. type of RMM) in subsection 8.2. NOTE: REACH requires that all specific provisions for exposure controls indicated in Annex II (subsection 8.2 of Annex II and all related subsections) are to be provided either in subsection 8.2 of the SDS or in the attached exposure scenarios. In case part of the information

133 Please note that the recommendations reported here do not preclude that new and up to date practical recommendations for transferring exposure scenario information into the body of the SDS will be elaborated as outcome of current and future projects. In this case the present guidance will be updated.

134 See e.g. point 0.2.4 of Part A of Annex II.


<a id="echa-app1-page-126"></a>
**ECHA printed page 126** — [original PDF page 126](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=126)

required in subsection 8.2 of Annex II is not provided in the attached exposure scenario, it has to be provided in subsection 8.2 of the SDS.

- Subsection 7.1 of the SDS should contain measures to control risks during handling of substances and mixtures. This includes a whole range of actions, such as for example: design and organisation of work systems; suitable equipment and regular maintenance of it; minimisation of duration and extent of exposure through organisational measures; general ventilation and appropriate hygiene measures135. It is recommended not to repeat descriptions of these measures in each exposure scenario annexed to the SDS, since these are not geared to an individual use unless these are relevant for the specific exposure scenario (e.g. because these are derived from the assessment).

- Subsection 7.3 is of limited relevance in the case of an extended SDS since it contains specific guidance for specific end uses and information should be contained in the exposure scenario related to the end use of the substance (e.g. in a mixture) or article service life (in cases where the substance ends up in an article). In this subsection reference to the relevant exposure scenario should be made. However if a registrant has available information on safe use of his substance in end-products (e.g. a risk management package related to handling of isocyanides containing products) he can make a reference here.

- Subsection 8.2 contains measures related to use of individual protection measures (such as personal protective equipment (PPE)). Use of PPE is usually considered as the last resort to control risks, in existing Union legislation on occupational health. PPE should be used in conjunction with other control measures such as process design (e.g. level of containment, closed process, local extraction), product design (e.g. low dust grades), workplace (dilution ventilation) or work method (automation). PPE should be used as additional RMM when other measures are insufficient to guarantee control of risks or, as sole RMM in particular cases (e.g. short term low frequency activities, or use by professionals) such as cleaning and maintenance, installation of new equipment or manual spraying outside industrial settings. If several exposure scenarios are annexed to the SDSs, PPE may or may not be required depending on the OCs of each exposure scenario which may be different. It is therefore recommended to indicate, in each exposure scenario, the type and technical specification of PPE required (if it is required), for which tasks/activities it is needed (e.g. cleaning / maintenance) and its effectiveness, while in subsection 8.2 the types of PPE that are required to guarantee protection from substance-specific hazards should be indicated.

- Annex II does not specifically mention RMMs and OCs related to consumers but it is indicated that the RMMs for all identified uses must be described in Section 8 of the SDS. Potential exposure of consumers to a substance is to be covered in the CSR for a substance if it is foreseen that the substance may end up in consumer products (mixtures or articles). It is therefore recommended to add information (or to give an information that exposure scenarios for consumer uses are annexed) under subsection 8.2 (e.g. by adding a new headline “consumer uses” after the point 8.2.3 indicated in Annex II) in the extended SDS to include measures related to consumer uses of the substance (as such or in mixtures), to the service life of the substance in articles or to information in product label (e.g. in the case of biocides or plant protection products). This information is relevant under REACH for the DUs if i) they place mixtures for use by the general public on the market and/or ii) they process substances or mixtures into articles. It may also facilitate the communication related to substances of very high concern, for which risk management advice for consumer uses and substances in articles may be required under Article 7 and Article 33 of REACH.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   135 For further detail see part I Chapter 2 of the EU Practical Guidelines related to the Directive 98/24/EC.


<a id="echa-app1-page-127"></a>
**ECHA printed page 127** — [original PDF page 127](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=127)

Standard phrases for exposure scenario information  Sector organisations, registrants and downstream users at various levels are working for the creation of a “standard phrases catalogue” with the aim to streamline and improve the effectiveness of communication in the supply chain. The use of standard phrases facilitates harmonisation of risk communication and enables the translation of the risk management advice in all the national languages (as required by REACH). A harmonised catalogue of phrases for communication of risk management advice (ESCom) has been published and is available on the internet136. Users of ECHA’s tool for Chemical Safety Assessment and Reporting (Chesar) can import this catalogue for using the harmonised phrases when generating their exposure scenarios for communication137.

136 http://www.esdscom.eu/english/euphrac-phrases/. 137 The tool and supporting material is available at chesar.echa.europa.eu/.


---

<a id="app2"></a>


# Appendix 2 — SDS for special mixtures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app2-page-128"></a>
**ECHA printed page 128** — [original PDF page 128](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=128)

Appendix 2. SDS for Special Mixtures

Introduction: What are Special Mixtures?

Special Mixtures138 are those in which a common feature is that the properties of the constituent substances are modulated by their inclusion within the matrix of the mixture (polymer, ceramic, or metal matrices). In particular, the availability for exposure of the constituent substances and their potential to express any ecotoxicological/toxic properties may be affected following their inclusion in solid matrices. Examples of special mixtures are: alloys, rubber compounds.

Note: Most experience on special mixtures is with alloys, and consequently this Appendix mainly refers to the drafting of SDS for “alloys as Special Mixtures”. Supported by preliminary evidence, however, it is believed that a similar reasoning could be followed for the other Special Mixtures. It is nevertheless strongly recommended - and beyond the possibilities and scope of this Appendix based solely on the experiences of the metals sector to check the validity of the suggested way forward with the other examples of Special Mixtures.

The result of its inclusion in a matrix is that the simple presence of a metal or inorganic ion in a special mixture will not necessarily impart to that special mixture the biological properties of the metal/inorganic ion; it will be 1) the availability of the ion at the site of action in the organism that is the most important factor determining toxicity for metals and minerals, and 2) the potential for different toxicity properties of special mixture particles.

Information on availability can be derived from in vivo sources (toxicokinetic or toxicological tests providing exposure and effect data) or in vitro methods.  In vitro, the release of metal or mineral ion in simulated biological fluids (e.g. gastric juice, intestinal fluid, artificial sweat, lung lavage/alveolar fluid, etc. bioaccessibility tests) or in water (Transformation Dissolution Protocol) will be measured, as a reflection of their availability. Using these settings, it is possible to compare the release of ions from the individual constituents vs. that from the constituents included in the matrix (e.g. the metal constituents of the alloy vs. metals in the alloy).

Reliable data showing differences in release or toxicity expression should be used in exposure scenarios in order to refine the proposed RMMs and OCs, using e.g. the Critical Component Approach. Release estimates and how these are considered in the context of Exposure Scenarios will be documented in the CSR.

Where will the Special Mixture concept have an impact on the SDS content?

‘Inclusion in the matrix’ and its influence on availability of the constituents can currently be considered in Section 8 of the SDS “Exposure controls/personal protection”. Proposed risk management measures can be refined provided that there are reliable data and information documenting release, availability and/or different toxicity expression. In the absence of reliable data, the special mixture will be considered by default as a simple mixture, and the mixture rules will apply.

Placeholder: work is ongoing on assessing the possibility of including bioavailability considerations when classifying an alloy as a Special Mixture. This may have some impact on the information given in Section 2: Hazard identification.

138 “Special mixtures” are not defined as such in e.g. Article 3 of REACH. However, the type of compositions that the term is intended to refer to within the REACH regulation can be inferred from the text of Recital 31 of REACH (as amended – it originally referred to “special preparations”) and  Annex I on CSA (point 0.11).


<a id="echa-app2-page-129"></a>
**ECHA printed page 129** — [original PDF page 129](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=129)

How to refine the proposed measures for controlling exposure/personal protection with Special Mixtures data:

- Usually, the production of a Special Mixture can involve a series of constituents. The Special Mixture producer, who has to generate an SDS for the Special Mixture, may receive a significant amount of information from which it will be difficult to identify and to extract key and relevant information to include in his SDS because of different properties, different exposure scenarios, etc.

- As a first step, it is suggested that the formulator responsible for preparing an SDS for an alloy should compile all relevant information about the mixture’s constituents and the mixture as a whole in a spreadsheet or similar format (see the example table given for a substance in the discussions of DNELS and PNECS under subsection 8.1 in chapter 3 of this document) and then extract the information required for the respective constituents SDS sections.

Depending on the information collected and the quality/reliability of the information, the formulator will have to decide whether or not he has the knowledge to consider his mixture as a Special Mixture (with possible refinements of RMMs). This will need to be documented, to enable the user of the SDS to understand any refinements that result from the use of availability data.

Example: availability data can be used to refine RMMs and OC.

Exposure to alloy powders and massives

When coarser (non-respirable/inhalable) powders and massives (>20 µm) are handled, the inhalation route is less relevant. In this case, oral and dermal exposures are more relevant for human health hazards. Toxicity resulting from these exposure routes depends on the availability of ions at target sites. This availability can be estimated in vitro by measuring ion release from the alloy in the gastric fluid and sweat and compared with release from the constituents. The results of availability tests on alloys can be used to refine actual exposure considerations from the “alloy” versus actual exposure from the “metals in the alloy. If exposure is reduced by inclusion in the matrix, then less stringent risk reduction measures could be applied.


---

<a id="app3"></a>


# Appendix 3 — Recovered substances and mixtures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app3-page-130"></a>
**ECHA printed page 130** — [original PDF page 130](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=130)

Appendix 3. Specific issues relevant to the compilation of SDSs for recovered substances and mixtures.139

Reason for the inclusion of this Appendix

Article 2(2) of REACH provides that "waste as defined in Directive 2008/98/EC 140 of the European Parliament and of the Council is not a substance, mixture or article within the meaning of Article 3 of this Regulation." Therefore, REACH requirements for substances, mixtures and articles do not apply to waste141.

However, where a substance or mixture is recovered from waste and material ‘ceases to be waste’, REACH requirements in principle apply in the same way as to any other material, with a number of conditionally granted exceptions. The relevant legislation applying to these transitions and the conditions for granting of exceptions are discussed in more detail in the Guidance on waste and recovered substances. In particular the Guidance on waste and recovered substances includes a decision tree which allows confirmation of whether or not an SDS is required for a recovered substance under REACH. These criteria, and the required content of the resulting SDS are essentially the same as for any other substance or mixture (as discussed in further detail in the rest of this guidance document) once it has been established that the recovered substance or mixture has ceased to be waste.

If a “new” substance is generated during the recovery process then it is subject to the normal provisions for registration under REACH.

Where it has been established that a substance or mixture has indeed ceased to be waste Article 2(7) (d) of REACH allows certain exemptions as follows:

“2.7. The following shall be exempted from Titles II, V and VI:

[…]

(d) Substances, on their own, in mixtures or in articles, which have been registered in accordance with Title II and which are recovered in the Community if:

(i) the substance that results from the recovery process is the same as the substance that has been registered in accordance with Title II; and

(ii) the information required by Articles 31 or 32 relating to the substance that has been registered in accordance with Title II is available to the establishment undertaking the recovery.”

As a consequence a recovery operator may produce an SDS which quotes no registration number. He may wish to explain why this is so within the SDS142.

Similarly, the requirement to carry out a CSA, complete a CSR and potentially to generate an exposure scenario for certain substances which arises in particular from Article 14(4) of REACH (which is also part of Title II), can be the subject of an exemption under Article 2(7)(d).

Title II refers to the Registration of substances, Title V to requirements for Downstream users

139 This Appendix should be read in conjunction with the ECHA Guidance on waste and recovered substances (available at: echa.europa.eu/guidance-documents/guidance-on-reach).

140 Repealed by Directive 2008/98/ECof the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (Waste Framework Directive).

141 Further explanation on this exemption is given in the Guidance on registration,

echa.europa.eu/guidance-documents/guidance-on-reach  (chapter 1.6.3.4).

142 See the text and examples given in chapter 3 in the discussion of subsection 1.1 in this guidance.


<a id="echa-app3-page-131"></a>
**ECHA printed page 131** — [original PDF page 131](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=131)

and Title VI to Evaluation. These exemptions notably do not cover Title IV (Information in the supply chain) which includes Article 31 requirements (as well as Article 32 requirements) for the provision of SDSs where applicable for recovered substances and mixtures which have ceased to be waste (as well as Article 32 requirements).

However although, by definition, to benefit from the exemptions the information on the substance or mixture required by Article 31 or 32 has to be available to the establishment undertaking the recovery there are some specific issues arising (e.g. from changes in the impurity profile or other aspects of the composition of the recovered substance by comparison with the substances as originally registered) which may affect the content of the SDS compiled for a recovered substance or mixture. There are also issues arising from the discontinuity in transfer of information on exposure scenarios down a supply chain which is interrupted by temporary change of a substance or mixture’s status as waste or “ceased to be waste”. These issues are considered in more detail below insofar as these affect the content of the SDS.

Composition of recovered substances and mixtures

For recovered materials that are composed primarily of substances which are not chemically modified by the recovery process,  these component substances on their own or in mixtures will generally be known and have been registered.

However, during original manufacture various other substances (potentially including stabilizing additives) may have been combined with the primary substance(s). Most of the substances (or additives) will still be in production and will therefore be registered under REACH. However, others will have been phased-out of production, either through voluntary or regulatory action, although these may continue to be present in waste materials for a number of years.

Some sectors carrying out recovery activities already have relatively easy access to the necessary information on the substances/mixtures that they produce and supply, to allow them to compile an SDS complying with Art 31 and Annex II of REACH. For others, further consideration of issues such as “sameness” may be needed.

Evaluating the applicability of available SDS information and the "sameness" of recovered substances

Even when compiling their own SDS based on available SDSs for substances recovered from the waste, the recovery operator would need to satisfy themselves that any information they rely upon to compile the SDS relates to substances which are the same as those in the recovered material.

Further discussion of “sameness” in the context of recovered substances is given in the ECHA Guidance on waste and recovered substances. This in particular notes that “the decision on the sameness should be based on the main constituents. Information about the impurities does not in principle change the conclusion about the sameness”143.

Compilation of SDSs using generic information

In case generic information on the input material is used to produce an SDS, there should be a process to establish confidence in the reliability of this information. Such a process could for example comprise:

143 Information about the impurities must be taken into account for issues such as Classification and Labelling and drafting of SDSs.


<a id="echa-app3-page-132"></a>
**ECHA printed page 132** — [original PDF page 132](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=132)

- Assess what is known about the waste material from which the substance is to be recovered.  This includes information on the composition of the waste, and any known relevant history of the material such as, where applicable:

- the previous application,

- handling and storage during the use, waste and transport stages

- any treatment carried out (e.g. during reprocessing).

- Assess and where relevant record all known content, including the original material(s) as well as anything likely to be present from additives used in the original application (e.g. alloying substances, coatings, colorants, or stabilisers). Information on the substances and mixtures present in the waste and their relative quantities will enable SDS information on relevant materials to be obtained and used as the basis of the SDS for the recycled material.  For example, if there are substances subject to restriction, meeting the classification criteria as hazardous according to CLP, CMR, PBT, vPvB or candidate list substances in the recycled material then the chemical composition of all such content should be established

- Characterise the incoming raw material and the recovered substance(s) to establish average content for each relevant substance and the likely range of its content in any mixture (maximum and minimum). Alternatively the hazard profile of the recovered mixture as such could be established. This information can be used to assess risks and set out risk management measures in the SDS for accepted uses.

For recovered substances (as for other substances) containing impurities that are classified and contribute to the classification, the impurities have to be indicated.

It is worth noting that the presence of impurities as such does not itself give rise to an obligation to supply an SDS under Article 31(1) of REACH. Such obligations may only arise through Article 31(3) requirements.

Other consequences of an Article 2(7)(d) exemption relevant to SDSs

A recovery operator who has the required information available for the same substance and can therefore rely on exemptions according to Article 2(7)(d) of REACH (even if the use of a recovered substance is not covered by the registration of the same substance), is not required to:

- generate an exposure scenario for the use of the recovered substance;

- register the recovered substance;

- notify the use of the recovered substance.

However he should take account of the available information and must provide information on appropriate risk management measures in the SDS, if applicable.

The SDS should be compiled in accordance with the text of Article 31 and Annex II of REACH. Where appropriate guidance set out in the main body of this document together with additional guidance for specific issues set out in this Appendix or in the Guidance on waste and recovered substances should be consulted.

Trade Associations representing specific material recovery sectors may provide their members with examples of how to use this guidance. They may wish to develop further guidance for any issues specific to their material stream.


---

<a id="app4"></a>


# Appendix 4 — Glossary and acronyms

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app4-page-133"></a>
**ECHA printed page 133** — [original PDF page 133](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=133)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 133](page_images/ECHA_2020_page_133.jpg)

Appendix 4. Glossary / List of acronyms

List of Acronyms

ATE Acute Toxicity Estimate

ADR European Agreement concerning the International Carriage of Dangerous Goods by Road

ADN European Agreement concerning the International Carriage of Dangerous Goods by Inland Waterways

CEN European Committee for Standardisation

C&L Classification and Labelling

CLP Classification Labelling Packaging Regulation; Regulation (EC) No 1272/2008

CAS# Chemical Abstracts Service number

CMR Carcinogen, Mutagen, or Reproductive Toxicant

CSA Chemical Safety Assessment

CSR Chemical Safety Report

DNEL Derived No Effect Level

DPD Dangerous Preparations Directive 1999/45/EC

DSD Dangerous Substances Directive 67/548/EEC

DU Downstream User

EC European Community

ECHA European Chemicals Agency

EC-Number EINECS and ELINCS Number (see also EINECS and ELINCS)

EEA European Economic Area (EU + Iceland, Liechtenstein and Norway)


<a id="echa-app4-page-134"></a>
**ECHA printed page 134** — [original PDF page 134](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=134)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 134](page_images/ECHA_2020_page_134.jpg)

EEC European Economic Community

EINECS European Inventory of Existing Commercial Substances

ELINCS European List of notified Chemical Substances

EN European Standard

EQS Environmental Quality Standard

EU European Union

Euphrac European Phrase Catalogue

EWC European Waste Catalogue (replaced by LoW – see below)

GES Generic Exposure Scenario

GHS Globally Harmonized System

IATA International Air Transport Association

ICAO-TI Technical Instructions for the Safe Transport of Dangerous Goods by Air

IMDG International Maritime Dangerous Goods

IMSBC International Maritime Solid Bulk Cargoes

IT Information Technology

IUCLID International Uniform Chemical Information Database

IUPAC International Union for Pure Applied Chemistry

JRC Joint Research Centre

Kow octanol-water partition coefficient

LC50 Lethal Concentration to 50 % of a test population


<a id="echa-app4-page-135"></a>
**ECHA printed page 135** — [original PDF page 135](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=135)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 135](page_images/ECHA_2020_page_135.jpg)

LD50 Lethal Dose to 50% of a test population (Median Lethal Dose)

LE Legal Entity

LoW List of Wastes (see http://ec.europa.eu/environment/waste/framework/list.htm)

LR Lead Registrant

M/I Manufacturer / Importer

MS Member States

MSDS Material Safety Data Sheet

OC Operational Conditions

OECD Organization for Economic Co-operation and Development

OEL Occupational Exposure Limit

OJ Official Journal

OR Only Representative

OSHA European Agency for Safety and Health at work

PBT Persistent, Bioaccumulative and Toxic substance

PEC Predicted Effect Concentration

PNEC(s) Predicted No Effect Concentration(s)

PPE Personal Protection Equipment

(Q)SAR Qualitative Structure Activity Relationship

REACH Registration, Evaluation, Authorisation and Restriction of Chemicals Regulation (EC) No 1907/2006

RID Regulations concerning the International Carriage of Dangerous Goods by Rail


<a id="echa-app4-page-136"></a>
**ECHA printed page 136** — [original PDF page 136](original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=136)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 136](page_images/ECHA_2020_page_136.jpg)

RIP REACH Implementation Project

RMM Risk Management Measure

SCBA Self-Contained Breathing Apparatus

SDS Safety data sheet

SIEF Substance Information Exchange Forum

SME Small and Medium sized Enterprises

STOT Specific Target Organ Toxicity

(STOT) RE Repeated Exposure

(STOT) SE Single Exposure

SVHC Substances of Very High Concern

UFI Unique Formula Identifier

UN United Nations

vPvB Very Persistent and Very Bioaccumulative
