---
title: "Appendix 2 \u2014 SDS for special mixtures"
document_id: "echa-sds-guidance-v4-2020-app2"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "128–129"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# Appendix 2 — SDS for special mixtures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app2-page-128"></a>
**ECHA printed page 128** — [original PDF page 128](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=128)

Appendix 2. SDS for Special Mixtures

Introduction: What are Special Mixtures?

Special Mixtures138 are those in which a common feature is that the properties of the constituent substances are modulated by their inclusion within the matrix of the mixture (polymer, ceramic, or metal matrices). In particular, the availability for exposure of the constituent substances and their potential to express any ecotoxicological/toxic properties may be affected following their inclusion in solid matrices. Examples of special mixtures are: alloys, rubber compounds.

Note: Most experience on special mixtures is with alloys, and consequently this Appendix mainly refers to the drafting of SDS for “alloys as Special Mixtures”. Supported by preliminary evidence, however, it is believed that a similar reasoning could be followed for the other Special Mixtures. It is nevertheless strongly recommended - and beyond the possibilities and scope of this Appendix based solely on the experiences of the metals sector to check the validity of the suggested way forward with the other examples of Special Mixtures.

The result of its inclusion in a matrix is that the simple presence of a metal or inorganic ion in a special mixture will not necessarily impart to that special mixture the biological properties of the metal/inorganic ion; it will be 1) the availability of the ion at the site of action in the organism that is the most important factor determining toxicity for metals and minerals, and 2) the potential for different toxicity properties of special mixture particles.

Information on availability can be derived from in vivo sources (toxicokinetic or toxicological tests providing exposure and effect data) or in vitro methods.  In vitro, the release of metal or mineral ion in simulated biological fluids (e.g. gastric juice, intestinal fluid, artificial sweat, lung lavage/alveolar fluid, etc. bioaccessibility tests) or in water (Transformation Dissolution Protocol) will be measured, as a reflection of their availability. Using these settings, it is possible to compare the release of ions from the individual constituents vs. that from the constituents included in the matrix (e.g. the metal constituents of the alloy vs. metals in the alloy).

Reliable data showing differences in release or toxicity expression should be used in exposure scenarios in order to refine the proposed RMMs and OCs, using e.g. the Critical Component Approach. Release estimates and how these are considered in the context of Exposure Scenarios will be documented in the CSR.

Where will the Special Mixture concept have an impact on the SDS content?

‘Inclusion in the matrix’ and its influence on availability of the constituents can currently be considered in Section 8 of the SDS “Exposure controls/personal protection”. Proposed risk management measures can be refined provided that there are reliable data and information documenting release, availability and/or different toxicity expression. In the absence of reliable data, the special mixture will be considered by default as a simple mixture, and the mixture rules will apply.

Placeholder: work is ongoing on assessing the possibility of including bioavailability considerations when classifying an alloy as a Special Mixture. This may have some impact on the information given in Section 2: Hazard identification.

138 “Special mixtures” are not defined as such in e.g. Article 3 of REACH. However, the type of compositions that the term is intended to refer to within the REACH regulation can be inferred from the text of Recital 31 of REACH (as amended – it originally referred to “special preparations”) and  Annex I on CSA (point 0.11).


<a id="echa-app2-page-129"></a>
**ECHA printed page 129** — [original PDF page 129](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=129)

How to refine the proposed measures for controlling exposure/personal protection with Special Mixtures data:

- Usually, the production of a Special Mixture can involve a series of constituents. The Special Mixture producer, who has to generate an SDS for the Special Mixture, may receive a significant amount of information from which it will be difficult to identify and to extract key and relevant information to include in his SDS because of different properties, different exposure scenarios, etc.

- As a first step, it is suggested that the formulator responsible for preparing an SDS for an alloy should compile all relevant information about the mixture’s constituents and the mixture as a whole in a spreadsheet or similar format (see the example table given for a substance in the discussions of DNELS and PNECS under subsection 8.1 in chapter 3 of this document) and then extract the information required for the respective constituents SDS sections.

Depending on the information collected and the quality/reliability of the information, the formulator will have to decide whether or not he has the knowledge to consider his mixture as a Special Mixture (with possible refinements of RMMs). This will need to be documented, to enable the user of the SDS to understand any refinements that result from the use of availability data.

Example: availability data can be used to refine RMMs and OC.

Exposure to alloy powders and massives

When coarser (non-respirable/inhalable) powders and massives (>20 µm) are handled, the inhalation route is less relevant. In this case, oral and dermal exposures are more relevant for human health hazards. Toxicity resulting from these exposure routes depends on the availability of ions at target sites. This availability can be estimated in vitro by measuring ion release from the alloy in the gastric fluid and sweat and compared with release from the constituents. The results of availability tests on alloys can be used to refine actual exposure considerations from the “alloy” versus actual exposure from the “metals in the alloy. If exposure is reduced by inclusion in the matrix, then less stringent risk reduction measures could be applied.
