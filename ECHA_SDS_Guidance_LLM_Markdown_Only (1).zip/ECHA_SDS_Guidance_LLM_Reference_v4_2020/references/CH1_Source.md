---
title: "1. General introduction"
document_id: "echa-sds-guidance-v4-2020-ch1"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "8–12"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# 1. General introduction

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-ch1-page-8"></a>
**ECHA printed page 8** — [original PDF page 8](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=8)

1 General Introduction

1.1 The safety data sheet

Safety data sheets (SDSs) have been a well-accepted and effective method for the provision of information to recipients of substances and mixtures in the EU. These have been made an integral part of the system of Regulation (EC) No 1907/2006 (REACH)1. The original requirements of REACH for SDSs have been further adapted to take into account the rules for safety data sheets of the Globally Harmonized System (GHS)2 and the implementation of other elements of the GHS into EU legislation that were introduced by Regulation (EC) No 1272/2008 (CLP)3 via amendments to Annex II of REACH4.

The SDS provides a mechanism for transmitting appropriate safety information on substances and mixtures where:

- a substance or a mixture meets the criteria for classification as hazardous according to CLP; or

- a substance is persistent, bioaccumulative and toxic (PBT) or very persistent and very bioaccumulative (vPvB), according to the criteria given in Annex XIII of REACH, or;

- a substance is included in the candidate list for eventual authorisation according to Article 59 (1) of REACH for any other reasons.  (See Article 31(1) of REACH).

Under certain conditions some mixtures which do not meet the criteria for classification as hazardous according to CLP also require an SDS to be prepared or be made available on request (See Article 31(3) of REACH, and notes to tables 3.4.6, 3.6.2, 3.7.2, 3.8.3 and 3.9.4 of Annex I of CLP extracted below):

Skin Sensitiser:  Table 3.4.6 Concentration limits for elicitation of components of a mixture  Note 1: This concentration limit for elicitation is used for the application of the special labelling requirements of section 2.8 of Annex II to protect already sensitised individuals. A SDS is required for the mixture containing a component at or above this concentration. For sensitising substances with specific concentration limit lower than 0,1 %, the concentration limit for elicitation should be set at one tenth of the specific concentration limit.  Carcinogenicity: Table 3.6.2 Generic concentration limits of ingredients of a mixture classification as carcinogen that trigger classification of a mixture

1 Regulation (EC) No 1907/2006 of the European Parliament and of the Council of 18 December 2006 concerning the Registration, Evaluation, Authorisation and Restriction of Chemicals (REACH), establishing a European Chemicals Agency, amending Directive 1999/45/EC and repealing Council Regulation (EEC) No 793/93 and Commission Regulation (EC) No 1488/94 as well as Council Directive 76/769/EEC and Commission Directives 91/155/EEC, 93/67/EEC, 93/105/EC and 2000/21/EC (OJ L 396, 30.12.2006, corrected version in OJ L136, 29.5.2007, p.3).

2 All editions of the GHS are accessible at: https://www.unece.org/trans/danger/publi/ghs/ghs_welcome_e.html

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 3 Regulation (EC) No 1272/2008 of the European Parliament and of the Council of 16 December 2008 on classification, labelling and packaging of substances and mixtures amending and repealing Directives 67/548/EEC and 1999/45/EC, and amending Regulation (EC) No 1907/2006 (OJ L 353, 31.12.2008, p.1).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 4 Commission Regulation (EU) No 453/2010 of 20 May 2010 amending Regulation (EC) No 1907/2006 of the European Parliament and of the Council on the Registration, Evaluation, Authorisation and Restriction of Chemicals (REACH) (O.J. L133 31.05.2010, p1-43) and Commission Regulation (EU) 2015/830 amending Regulation (EC) No 1907/2006 of the European Parliament and of the Council on the Registration, Evaluation, Authorisation and Restriction of Chemicals  (REACH).


<a id="echa-ch1-page-9"></a>
**ECHA printed page 9** — [original PDF page 9](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=9)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 9](../page_images/ECHA_2020_page_009.jpg)

Note 1:   If a Category 2 carcinogen is present in the mixture as an ingredient at a concentration ≥ 0,1 % a SDS shall be available for the mixture upon request

Reproductive Toxicity Table 3.7.2 : Generic concentration limits of ingredients of a mixture classified as reproduction toxicants or for effects on or via lactation that trigger classification of the mixture

Note 1: If a Category 1 or Category 2 reproductive toxicant or a substance classified for effects on or via lactation is present in the mixture as an ingredient at a concentration at or above 0,1 %, a SDS shall be available for the mixture upon request.

Specific target organ toxicity-single exposure : Table 3.8.3 : Generic concentration limits of ingredients of a mixture classified as a specific target organ toxicant that trigger classification of the mixture as Category 1 or 2

Note 1: If a Category 2 specific target organ toxicant is present in the mixture as an ingredient at a concentration ≥ 1,0 % a SDS shall be available for the mixture upon request.

Specific target organ toxicity-repeated exposure :  Table 3.9.4 : Generic concentration limits of ingredients of a mixture classified as a specific target organ toxicant that trigger classification of the mixture

Note1: If a Category 2 specific target organ toxicant is present in the mixture as an ingredient at a concentration ≥ 1,0 % a SDS shall be available for the mixture upon request.

SDSs do not have to be provided for articles. Although the SDS format may, for a few specific articles, be used to convey safety information down the supply chain, it is not adapted to most articles5.

The SDS follows a 16-section format which is internationally agreed. The SDS must be supplied in an official language of the Member State(s) where the substance or mixture is placed on the market, unless the Member State(s) concerned provide(s) otherwise (Article 31(5) of REACH)6.

Where a Chemical Safety Report (CSR) is required to be prepared for a substance, the information in the SDS for the substance must be consistent with that provided in the CSR, as well as with that provided in the registration dossier (when the CSR is prepared according to Article 14). In addition, according to Article 31(7) of REACH, registrants and downstream users that are required to prepare a CSR, must place the relevant exposure scenario(s) into an annex to the safety data sheet. Also, according to Article 62(4)(d) as part of the application for authorisation, the applicant has to prepare a CSR, including an exposure scenario for the use that is being applied for (Annex I, section 5.1.2). According to Annex I section 0.7 if the substance is placed on the market, the relevant exposure scenario(s), including the risk management measures and operational conditions shall be included in an annex to the safety

5 Although according to Article 4(8) and Section 2.1 of Annex I of CLP certain objects described in CLP using the word “article” (specifically in the combinations “explosive articles”, “pyrotechnic article”  or “substances, mixtures and articles … …  which are manufactured with a view to producing a practical, explosive or pyrotechnic effect” as defined via point 2.1.1.1 (b) or (c) and 2.1.1.2 of Annex I to CLP) should be classified and labelled according to CLP, the usage of the word “article” in this combined context differs from the stand-alone definition of an “article” both under REACH (Article 3 (3)) and under CLP (Article 2 (9)). For the purposes of REACH these are more likely to be considered as a combination of an article (the container/packaging) and a substance/mixture (see ECHA Guidance on requirements for substances in articles). If appropriate, in such cases the SDS would be supplied for the corresponding substance/mixture. Note that Directive 2013/29/EU requires an SDS for the pyrotechnic article for vehicles: https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32013L0029

6 ECHA has published the table “Languages required for labels and safety data sheets” which is available on the SDSs webpage of the ECHA website at:  https://echa.europa.eu/safety-data-sheets


<a id="echa-ch1-page-10"></a>
**ECHA printed page 10** — [original PDF page 10](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=10)

data sheet. Downstream users have to consider relevant exposure information received from suppliers when compiling their safety data sheets. For mixtures, there are several options for placing relevant exposure scenarios into an annex or for including relevant exposure information in the core Sections 1 – 16 of the SDS. If however, a downstream user is required to prepare his own CSR under Article 37 of REACH and this results in the generation of an exposure scenario, this exposure scenario must be placed in an annex to the SDS7.

1.2 Aim of this guidance

The aim of this guidance is to assist industry in determining which tasks and requirements have to be complied with in order to fulfil their obligations under Article 31 of REACH (Requirements for safety data sheets) and Annex II of REACH, as replaced by:

- Commission Regulation (EU) 2020/878: amending Annex II by introducing specific requirements regarding nanoforms of substances, adapting to the 6th and 7th revision of the GHS, and adding requirements regarding the Unique Formula Identifier (as set by Annex VIII to Regulation (EC) 1272/2008), endocrine disrupting properties, specific concentration limits, M-factors and acute toxicity estimates.

This guidance provides information especially on:

- issues to consider when compiling an SDS;

- details of the requirements for information to be included in each Section of an SDS;

- who should compile the SDS and what competences the author should have.

The references to the legal text have been updated to reflect the latest version of Annex II (i.e. the Annex to Regulation (EU)  2020/878).  Furthermore, as of 1 June 2017, substances and mixtures must be classified and labelled according to CLP only, and this has to be reflected in the appropriate sections of the SDS. Therefore, references and advice related to the obsolete DSD/DPD classification system have been removed from this Guidance.

1.3 Transitional provision to implement the latest version of Annex II to REACH

In accordance with Article 2 of Regulation (EU)  2020/878, safety data sheets compiled in accordance with Regulation (EC) No 1907/2006, as amended by Commission Regulation (EU) 2015/830, can continue to be used until 31 December 2022. This is without prejudice to the obligation to update the safety data sheets in accordance with Article 31(9) of Regulation (EC) No 1907/2006, and to the cases where the Unique Formula Identifier (UFI) is added to safety data sheets as provided for in section 5 of Part A of Annex VIII to Regulation (EC) No 1272/2008 (CLP).  In other words, until 31 December 2022, all safety data sheets provided after 1st January 2021, including new and updated safety data sheets, can be provided in the current format according to Regulation (EU) 2015/830 or in the new format according to Regulation (EU) 2020/878, including the following scenarios:

- No change to safety data sheet

7 Detailed information on how downstream users can fulfil their obligations under REACH is provided in the Guidance for downstream users available at echa.europa.eu/guidance-documents/guidance-on-reach.


<a id="echa-ch1-page-11"></a>
**ECHA printed page 11** — [original PDF page 11](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=11)

•
Small change to safety data sheets not within scope of Article 31(9)
•
Update to safety data sheets within the scope of Article 31(9) or introducing the UFI
•
New safety data sheets authored for the first time after 1st January 2021

All safety data sheets provided after 31 December 2022 have to be in the format according to
Regulation (EU) 2020/878. It is recommended that the new format, as set out in Regulation
(EU) 2020/878,  is adopted, as soon as practicable, to ensure that all SDSs comply by the 31
December 2022 deadline.

1.4 Target audience of this guidance

The main target audience of this guidance is those compiling SDSs for use by suppliers of substances and mixtures for which SDSs are required by Article 31 of REACH. While the REACH requirements regarding SDSs are directed at suppliers of substances and mixtures, this document also provides useful information for recipients of an SDS. It is noted in this context that the information provided by SDS will also help employers to meet their obligations under Directive 98/24/EC8 on the protection of the health and safety of workers from the risks related to chemical agents at work.

The SDS should enable users to take the necessary measures relating to protection of human health and safety at the workplace, and protection of the environment.

1.5 Relation with CLP and GHS

Regulation (EC) No 1272/2008 on classification, labelling and packaging of substances and mixtures (CLP) harmonises the provisions and criteria for the classification and labelling of substances and mixtures within the Union9, taking into account the classification criteria and labelling rules of the UN Globally Harmonised System of Classification and Labelling of Chemicals (GHS). The CLP Regulation contributes to the UN GHS aim of describing and communicating the same hazards in the same way around the world. The CLP Regulation entered into force on the 20th of January 2009.

On 12 April 2017, Commission Regulation (EU) 2017/54210 entered into force, adding a new Annex VIII to the CLP Regulation. It harmonises the information relating to emergency health response that companies placing certain hazardous mixtures on the EU market are required to submit to the national appointed bodies. The information submitted needs to be consistent with the information in the SDS. Furthermore, the Unique Formula Identifier (UFI) required by the same Annex may need to be indicated in the SDS of certain hazardous mixtures11.

In the EEA, the required SDS format and content are defined by Article 31 and Annex II to REACH. These have been adapted to align them with the GHS requirements, in particular with

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   8 Council Directive 98/24/EC of 7 April 1998 on the protection of the health and safety of workers from the risks related to chemical agents at work (fourteenth individual Directive within the meaning of Article 16(1) of Directive 89/391/EEC), OJ L131, 5..5.1998, p.11).

9 With the entry into force of the Treaty of Lisbon in 2009, the term “Community” was  replaced by “Union”. Please, note that the CLP Regulation had not been amended to implement this change and therefore the term “Community” is still used in some quotes from the legal text made within this document.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 10 Commission Regulation (EU) 2017/542 of 22 March 2017 amending Regulation (EC) No 1272/2008 of the European Parliament and of the Council on classification, labelling and packaging of substances and mixtures by adding an Annex on harmonised information relating to emergency health response.

11 See Guidance on harmonised information relating to emergency health response – Annex VIII to CLP: https://echa.europa.eu/documents/10162/13643/guidance_on_annex_viii_to_clp_en.pdf/


<a id="echa-ch1-page-12"></a>
**ECHA printed page 12** — [original PDF page 12](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=12)

the “guidance on the preparation of safety data sheets (SDS)” given in Annex 4 of the GHS12, as well as to be fully in line with the CLP Regulation. This version of the Guidance on the compilation of SDSs reflects the text of the revision of Annex II to REACH, as replaced by the Annex to Regulation (EU)  2020/878 (amending REACH) with effect from 1 January 2021.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   12 The current version of the GHS and all previous versions are available at: https://www.unece.org/trans/danger/publi/ghs/ghs_welcome_e.html
