---
title: "Appendix 1 \u2014 Exposure scenario information"
document_id: "echa-sds-guidance-v4-2020-app1"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "121–127"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# Appendix 1 — Exposure scenario information

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app1-page-121"></a>
**ECHA printed page 121** — [original PDF page 121](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=121)

Appendix 1. Including relevant exposure scenario information into safety data sheets

Possible options for inclusion of relevant exposure scenario information for a substance into a safety data sheet have been explained in chapters 2.22 and 2.23 of this guidance. This Appendix provides additional guidance on this topic.  Transmission of information on safe use down the supply chain  The CSR for a substance may include one or more exposure scenarios in its heading 9 Exposure Assessment. The exposure scenarios in the CSR are meant to document the conditions of safe use (operational conditions (OC) and risk management measures (RMM)) that have been assessed by the registrant. Each of the exposure scenarios addresses one or more identified uses. Exposure estimate and, where feasible, risk characterisation are required for each exposure scenario in order to demonstrate adequate control of risks for human health and for the environment. REACH requires that the registrant (or any actor in the supply chain who is required to prepare a CSR) places the relevant exposure scenarios in an annex to the SDS (making it an extended safety data sheet) he supplies his downstream users further down the supply chain. The purpose of the exposure scenario in the communication to downstream users is to provide guidance on how to use the substance in a way that control of risks is ensured. For this reason, the information in the exposure scenarios annexed to the SDS for a substance should be focused on what the recipients of the SDS need to know in order to ensure safe use of the substance. It is however also required that there be consistency between the exposure scenario information in the CSR and the exposure scenario(s) attached to the SDS. The exposure scenario(s) attached to the SDS must cover all uses at all life cycle stages that are relevant for the recipient of the substance. This means that the exposure scenario(s) has/(have) to address specific uses of immediate downstream users and uses further down the supply chain for which conditions of safe use have been documented in the CSR 124. In order to fulfil this requirement, registrants (or downstream users preparing the CSR) need to understand the supply chain of the substance in the market, the uses of the substance by their customers and foreseeable uses of the substance further down the supply chain. Conditions of safe use (and related exposure scenarios) may be different for each individual use or these may be the same for a group of uses. For this reason, the number of exposure scenarios included in the SDS for a specific substance may vary depending on the number of individual uses or groups of uses covered for the substance125. If a substance ends up in different supply chains (with different uses and conditions of use), exposure scenarios attached to the SDS have to cover uses and use conditions that are relevant for each supply chain. Communication within the supply chain and support from sector organizations are key elements to help registrants (or downstream users preparing the CSR) to identify relevant exposure scenarios to be attached to the SDSs. The attachment to SDSs of all exposure scenarios covering all identified uses without taking into account their relevance for downstream users to whom these are addressed should be avoided.

When a registrant considers the use of scaling to be applicable for his substance he has to explicitly indicate, for each specific use (and exposure scenario), applicable scaling options including which determinants of the exposure can be modified by scaling and the specific scaling tool(s) that can be used (e.g. an algorithm or an IT tool)126. It is furthermore important that information on scaling is communicated by downstream users when extended SDSs are

124 Additional information on ESs for SDS and exposure scenario for and CSR is available in the ECHA Guidance on information requirement and CSA Part D echa.europa.eu/guidance-documents/guidance-on-information-requirements- and-chemical-safety-assessment.

125 Note that for a supplier of a substance manufactured or imported at an annual volume of below 10 tpa and therefore not requiring a CSA there may legitimately be no ESs at all attached to the SDS.

126 See Guidance for downstream users for more details (echa.europa.eu/guidance-documents/guidance-on-reach).


<a id="echa-app1-page-122"></a>
**ECHA printed page 122** — [original PDF page 122](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=122)

prepared by them for communication of safety information to their customers further down the supply chain.

The information in the extended SDS may include advice that refers to uses and life cycle stages beyond “downstream uses” as intended by REACH (e.g. uses by consumers, life cycle of articles, waste stage etc..). In such a case, downstream users receiving extended SDS information are expected to:

- inform/instruct users of substances or mixtures who are members of the general public, i.e., consumers, even though no safety data sheet is required to be provided to them,

- fulfil their duties related to safety or emission behaviour of articles supplied by them, as laid down in other legislation (e.g. toys, construction products), and to comply with their duties under Article 33 (if they are article producers) and

- fulfil their duty to select appropriate waste disposal routes.

Inclusion into the SDS of exposure scenario information relevant for the immediate downstream user and subsequent users

The ultimate aim of a supplier of a substance who provides an extended SDS to his immediate downstream users is to communicate clear and understandable information on how the substance (either as such or in a mixture) can be used “safely” by them. Registrants or downstream users preparing a CSR for a substance for which an exposure scenario is required, are required to attach relevant exposure scenario(s) to the safety data sheet for the products (containing the substance) they deliver to their immediate downstream users. Additional information is available in chapters 2.22 and 2.23.

When a downstream user receives an exposure scenario for a substance from his supplier, he has to check if his use and conditions of use are covered by the exposure scenario. Practical advice on how to check whether a use is covered and how to choose and carry out the appropriate action is provided in chapters 4 and 5 of the Guidance for downstream users and in the Practical guide “How downstream users can handle exposure scenarios”127.

A downstream user of a substance may supply that substance in his products further down the supply chain. This is typically the case for formulators using substances in their mixtures and supplying mixtures to other formulators and/or to end users. A downstream user supplying a substance (e.g. in a mixture), for which an extended SDS has been provided by the supplier of the substance, has to check whether the foreseeable uses of his mixtures (containing the substance) are covered in the exposure scenarios he has received for the substance. If uses are covered, the downstream user has to include the exposure scenario (of the substance) into the SDS of his mixtures if:

- an SDS is required for the mixture and

- the concentration of the substance in the mixture exceeds the limits indicated in Article 14 of REACH.

Depending on how diverse the OCs and RMMs for the substances in the mixture will be further downstream, the inclusion of the exposure scenario can be carried out in different ways, as described in chapter 2.23.

Downstream users may have different levels of technical competence to identify, apply

127 At echa.europa.eu/practical-guides.


<a id="echa-app1-page-123"></a>
**ECHA printed page 123** — [original PDF page 123](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=123)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 123](../page_images/ECHA_2020_page_123.jpg)

and recommend appropriate measures to control risks identified in the SDS supplied to them. Thus, when compiling the extended SDS for a substance, the supplier (manufacturer, importer or downstream user) will need to anticipate the role of his immediate downstream user in the supply chain and to present the information in a way that enables the immediate downstream user to identify the measures that are relevant to recommend to his own customers.

It is therefore crucial that the supplier prepares an exposure scenario that contains practically useful information related to the downstream user’s processes, structured in a “possibly standardized” format and written in a technical language that is understandable to the downstream user. More detailed information on exposure scenarios for communication can be found in Chesar user manual 2128. Furthermore, guidance for formulators on how to forward information on mixtures down the supply chain is provided in the Guidance for Downstream users129 (chapter 7).

The supplier is expected to phrase the OC and RMMs so that these can be included and recommended in the SDS for a mixture without need for re-phrasing130 by the immediate downstream users (e.g. using so called “standard phrases”131).

Distributors

Distributors, even though they are not downstream users under REACH, have a fundamental role in the communication flow up and down the supply chain, including via the SDS. They have a key position as they may have direct contact with the manufacturer/importer and the end-user of the substance. Under REACH, the customer of a distributor is considered as an immediate downstream user of the registrant. It is therefore recommended that the registrant actively approaches the distributors to seek agreement on how the registrant can increase his knowledge on the conditions of use in the distributor’s market, for the purposes of the exposure scenario and other SDS information without requiring the distributor to disclose confidential business information (CBI). More detailed information on the role and obligations of the distributor are provided in the Guidance for downstream users.

The exposure scenario and corresponding Sections in the safety data sheet.  Table 3 gives an overview of the relationship between the SDS sections and the standard entries of the exposure scenario.

Depending on the hazard profile of the substance, the broadness of the market and the structure of the supply chain, there is a variety of options to modify the principal organisation of information in the exposure scenarios and the extended SDSs, e.g.:

- Section 2 of the exposure scenario could be further differentiated into exposure routes and exposure patterns. It can also be useful to link the risk management advice per route of exposure and endpoint directly with the relevant DNEL and exposure prediction.

128 Available at chesar.echa.europa.eu/support. Please note that it is up to the individual registrant to decide which exposure scenario format he wants to use, as long as the content of the exposure scenario is compliant with the requirements set out in Annex I of REACH.

129 echa.europa.eu/guidance-documents/guidance-on-reach.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 130 The standard phrases for risk management measures (as contained in the RMM catalogue indicated in the last section of this Appendix) should therefore be constructed  in such a way that these are understandable to all actors in the supply chain.

131 See the last subchapter of this annex for more information on one available catalogue of standard phrases.


<a id="echa-app1-page-124"></a>
**ECHA printed page 124** — [original PDF page 124](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=124)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 124](../page_images/ECHA_2020_page_124.jpg)

- In a broad exposure scenario for a substance with only one or two hazard endpoints of concern, it may also be possible to list the specific RMMs for certain activities in Section 2 of one  exposure scenario.

Table 2 Relationship between exposure scenario and SDS Sections

ES section SDS Section(s)

Short title of the exposure scenario 1.2

Operational conditions and risk management measures 7 + 8

Control of workers exposure

Product characteristic 7 + 8 + 9

Amounts used 7 + 8

Frequency and duration of use 7 + 8

Human factors not influenced by risk management 7 + 8

Technical conditions and measures at process level (source) to prevent release

7 + 8

Technical conditions and measures to control dispersion from source towards the worker

7 + 8

Organisational measures to prevent/limit releases, dispersion and exposure

(5, 6), 7, 8

Conditions and measures related to personal protection, hygiene and health evaluation

(5, 6), 7, 8

Other conditions affecting workers exposure 7 + 8

Control of consumer exposure132

Product characteristic 7 + 8 + 9

Amounts used 7 + 8

Frequency and duration of use 7 + 8

Other conditions affecting consumers exposure 7 + 8

Control of environmental exposure

Product characteristic 7 + 8 + 9

Amounts used 7 + 8

Frequency and duration of use 7 + 8

132 Note that specific information on consumer exposure in Section 8 of the SDS is not a legal requirement.


<a id="echa-app1-page-125"></a>
**ECHA printed page 125** — [original PDF page 125](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=125)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 125](../page_images/ECHA_2020_page_125.jpg)

Environmental factors not influenced by risk management

Technical conditions and measures at process level (source) to prevent release

7

Technical onsite conditions and measures to reduce or limit discharges, air emissions and releases to soil

7 + 8

Organisational measures to prevent/limit release from site 6 + 7 + 8

Conditions and measures related to municipal sewage treatment plant 8 + 13

Conditions and measures related to external treatment of waste for disposal

13

Conditions and measures related to external recovery of waste 13

Other given operational conditions affecting environmental exposure 7

Annex II to REACH sets the requirements for how to structure the measures for safe handling, protecting the environment and controlling of risks in Sections 7 and 8 of the SDS. These Sections are described in detail in subchapters 3.7 and 3.8 of this guidance. Annex II of REACH indicates also (for Sections 7 and 8 of the SDS) that where a CSR is required for the substance, the information in these sections has to be consistent with the information given in the CSR for the identified uses and related exposure scenario and that where an exposure scenario is attached to the SDS, information on exposure controls (subsection 8.2) can be provided in the exposure scenario only and it does not have to be duplicated in subsection 8.2 of the SDS.

In order to implement these requirements in a consistent and user-friendly way, the following guidelines133 should be applied:

- Annex II distinguishes between occupational conditions in subsections 7.1 - “precautions for safe handling” of the substance or mixture - and “exposure controls” in subsection 8.2). Certain measures however are mentioned in both sections.

- Annex II requires that the language used in an SDS is clear and specific. For example statements like “avoid breathing vapours” or “avoid skin contact” would not fulfil the requirements for description of how prevention or control of exposure can be achieved134.

- The description of RMMs related to all uses covered in the annexed exposure scenarios must be included in Section 8 or in the exposure scenarios attached to the SDS (if applicable). When RMM information is provided in the exposure scenario, it is recommended to provide specific reference to relevant exposure scenarios containing the information in subsection 8.2 of the SDS. It is also recommended to provide a summary of RMM (e.g. type of RMM) in subsection 8.2. NOTE: REACH requires that all specific provisions for exposure controls indicated in Annex II (subsection 8.2 of Annex II and all related subsections) are to be provided either in subsection 8.2 of the SDS or in the attached exposure scenarios. In case part of the information

133 Please note that the recommendations reported here do not preclude that new and up to date practical recommendations for transferring exposure scenario information into the body of the SDS will be elaborated as outcome of current and future projects. In this case the present guidance will be updated.

134 See e.g. point 0.2.4 of Part A of Annex II.


<a id="echa-app1-page-126"></a>
**ECHA printed page 126** — [original PDF page 126](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=126)

required in subsection 8.2 of Annex II is not provided in the attached exposure scenario, it has to be provided in subsection 8.2 of the SDS.

- Subsection 7.1 of the SDS should contain measures to control risks during handling of substances and mixtures. This includes a whole range of actions, such as for example: design and organisation of work systems; suitable equipment and regular maintenance of it; minimisation of duration and extent of exposure through organisational measures; general ventilation and appropriate hygiene measures135. It is recommended not to repeat descriptions of these measures in each exposure scenario annexed to the SDS, since these are not geared to an individual use unless these are relevant for the specific exposure scenario (e.g. because these are derived from the assessment).

- Subsection 7.3 is of limited relevance in the case of an extended SDS since it contains specific guidance for specific end uses and information should be contained in the exposure scenario related to the end use of the substance (e.g. in a mixture) or article service life (in cases where the substance ends up in an article). In this subsection reference to the relevant exposure scenario should be made. However if a registrant has available information on safe use of his substance in end-products (e.g. a risk management package related to handling of isocyanides containing products) he can make a reference here.

- Subsection 8.2 contains measures related to use of individual protection measures (such as personal protective equipment (PPE)). Use of PPE is usually considered as the last resort to control risks, in existing Union legislation on occupational health. PPE should be used in conjunction with other control measures such as process design (e.g. level of containment, closed process, local extraction), product design (e.g. low dust grades), workplace (dilution ventilation) or work method (automation). PPE should be used as additional RMM when other measures are insufficient to guarantee control of risks or, as sole RMM in particular cases (e.g. short term low frequency activities, or use by professionals) such as cleaning and maintenance, installation of new equipment or manual spraying outside industrial settings. If several exposure scenarios are annexed to the SDSs, PPE may or may not be required depending on the OCs of each exposure scenario which may be different. It is therefore recommended to indicate, in each exposure scenario, the type and technical specification of PPE required (if it is required), for which tasks/activities it is needed (e.g. cleaning / maintenance) and its effectiveness, while in subsection 8.2 the types of PPE that are required to guarantee protection from substance-specific hazards should be indicated.

- Annex II does not specifically mention RMMs and OCs related to consumers but it is indicated that the RMMs for all identified uses must be described in Section 8 of the SDS. Potential exposure of consumers to a substance is to be covered in the CSR for a substance if it is foreseen that the substance may end up in consumer products (mixtures or articles). It is therefore recommended to add information (or to give an information that exposure scenarios for consumer uses are annexed) under subsection 8.2 (e.g. by adding a new headline “consumer uses” after the point 8.2.3 indicated in Annex II) in the extended SDS to include measures related to consumer uses of the substance (as such or in mixtures), to the service life of the substance in articles or to information in product label (e.g. in the case of biocides or plant protection products). This information is relevant under REACH for the DUs if i) they place mixtures for use by the general public on the market and/or ii) they process substances or mixtures into articles. It may also facilitate the communication related to substances of very high concern, for which risk management advice for consumer uses and substances in articles may be required under Article 7 and Article 33 of REACH.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   135 For further detail see part I Chapter 2 of the EU Practical Guidelines related to the Directive 98/24/EC.


<a id="echa-app1-page-127"></a>
**ECHA printed page 127** — [original PDF page 127](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=127)

Standard phrases for exposure scenario information  Sector organisations, registrants and downstream users at various levels are working for the creation of a “standard phrases catalogue” with the aim to streamline and improve the effectiveness of communication in the supply chain. The use of standard phrases facilitates harmonisation of risk communication and enables the translation of the risk management advice in all the national languages (as required by REACH). A harmonised catalogue of phrases for communication of risk management advice (ESCom) has been published and is available on the internet136. Users of ECHA’s tool for Chemical Safety Assessment and Reporting (Chesar) can import this catalogue for using the harmonised phrases when generating their exposure scenarios for communication137.

136 http://www.esdscom.eu/english/euphrac-phrases/. 137 The tool and supporting material is available at chesar.echa.europa.eu/.
