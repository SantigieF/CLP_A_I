---
title: "Appendix 3 \u2014 Recovered substances and mixtures"
document_id: "echa-sds-guidance-v4-2020-app3"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "130–132"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# Appendix 3 — Recovered substances and mixtures

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app3-page-130"></a>
**ECHA printed page 130** — [original PDF page 130](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=130)

Appendix 3. Specific issues relevant to the compilation of SDSs for recovered substances and mixtures.139

Reason for the inclusion of this Appendix

Article 2(2) of REACH provides that "waste as defined in Directive 2008/98/EC 140 of the European Parliament and of the Council is not a substance, mixture or article within the meaning of Article 3 of this Regulation." Therefore, REACH requirements for substances, mixtures and articles do not apply to waste141.

However, where a substance or mixture is recovered from waste and material ‘ceases to be waste’, REACH requirements in principle apply in the same way as to any other material, with a number of conditionally granted exceptions. The relevant legislation applying to these transitions and the conditions for granting of exceptions are discussed in more detail in the Guidance on waste and recovered substances. In particular the Guidance on waste and recovered substances includes a decision tree which allows confirmation of whether or not an SDS is required for a recovered substance under REACH. These criteria, and the required content of the resulting SDS are essentially the same as for any other substance or mixture (as discussed in further detail in the rest of this guidance document) once it has been established that the recovered substance or mixture has ceased to be waste.

If a “new” substance is generated during the recovery process then it is subject to the normal provisions for registration under REACH.

Where it has been established that a substance or mixture has indeed ceased to be waste Article 2(7) (d) of REACH allows certain exemptions as follows:

“2.7. The following shall be exempted from Titles II, V and VI:

[…]

(d) Substances, on their own, in mixtures or in articles, which have been registered in accordance with Title II and which are recovered in the Community if:

(i) the substance that results from the recovery process is the same as the substance that has been registered in accordance with Title II; and

(ii) the information required by Articles 31 or 32 relating to the substance that has been registered in accordance with Title II is available to the establishment undertaking the recovery.”

As a consequence a recovery operator may produce an SDS which quotes no registration number. He may wish to explain why this is so within the SDS142.

Similarly, the requirement to carry out a CSA, complete a CSR and potentially to generate an exposure scenario for certain substances which arises in particular from Article 14(4) of REACH (which is also part of Title II), can be the subject of an exemption under Article 2(7)(d).

Title II refers to the Registration of substances, Title V to requirements for Downstream users

139 This Appendix should be read in conjunction with the ECHA Guidance on waste and recovered substances (available at: echa.europa.eu/guidance-documents/guidance-on-reach).

140 Repealed by Directive 2008/98/ECof the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (Waste Framework Directive).

141 Further explanation on this exemption is given in the Guidance on registration,

echa.europa.eu/guidance-documents/guidance-on-reach  (chapter 1.6.3.4).

142 See the text and examples given in chapter 3 in the discussion of subsection 1.1 in this guidance.


<a id="echa-app3-page-131"></a>
**ECHA printed page 131** — [original PDF page 131](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=131)

and Title VI to Evaluation. These exemptions notably do not cover Title IV (Information in the supply chain) which includes Article 31 requirements (as well as Article 32 requirements) for the provision of SDSs where applicable for recovered substances and mixtures which have ceased to be waste (as well as Article 32 requirements).

However although, by definition, to benefit from the exemptions the information on the substance or mixture required by Article 31 or 32 has to be available to the establishment undertaking the recovery there are some specific issues arising (e.g. from changes in the impurity profile or other aspects of the composition of the recovered substance by comparison with the substances as originally registered) which may affect the content of the SDS compiled for a recovered substance or mixture. There are also issues arising from the discontinuity in transfer of information on exposure scenarios down a supply chain which is interrupted by temporary change of a substance or mixture’s status as waste or “ceased to be waste”. These issues are considered in more detail below insofar as these affect the content of the SDS.

Composition of recovered substances and mixtures

For recovered materials that are composed primarily of substances which are not chemically modified by the recovery process,  these component substances on their own or in mixtures will generally be known and have been registered.

However, during original manufacture various other substances (potentially including stabilizing additives) may have been combined with the primary substance(s). Most of the substances (or additives) will still be in production and will therefore be registered under REACH. However, others will have been phased-out of production, either through voluntary or regulatory action, although these may continue to be present in waste materials for a number of years.

Some sectors carrying out recovery activities already have relatively easy access to the necessary information on the substances/mixtures that they produce and supply, to allow them to compile an SDS complying with Art 31 and Annex II of REACH. For others, further consideration of issues such as “sameness” may be needed.

Evaluating the applicability of available SDS information and the "sameness" of recovered substances

Even when compiling their own SDS based on available SDSs for substances recovered from the waste, the recovery operator would need to satisfy themselves that any information they rely upon to compile the SDS relates to substances which are the same as those in the recovered material.

Further discussion of “sameness” in the context of recovered substances is given in the ECHA Guidance on waste and recovered substances. This in particular notes that “the decision on the sameness should be based on the main constituents. Information about the impurities does not in principle change the conclusion about the sameness”143.

Compilation of SDSs using generic information

In case generic information on the input material is used to produce an SDS, there should be a process to establish confidence in the reliability of this information. Such a process could for example comprise:

143 Information about the impurities must be taken into account for issues such as Classification and Labelling and drafting of SDSs.


<a id="echa-app3-page-132"></a>
**ECHA printed page 132** — [original PDF page 132](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=132)

- Assess what is known about the waste material from which the substance is to be recovered.  This includes information on the composition of the waste, and any known relevant history of the material such as, where applicable:

- the previous application,

- handling and storage during the use, waste and transport stages

- any treatment carried out (e.g. during reprocessing).

- Assess and where relevant record all known content, including the original material(s) as well as anything likely to be present from additives used in the original application (e.g. alloying substances, coatings, colorants, or stabilisers). Information on the substances and mixtures present in the waste and their relative quantities will enable SDS information on relevant materials to be obtained and used as the basis of the SDS for the recycled material.  For example, if there are substances subject to restriction, meeting the classification criteria as hazardous according to CLP, CMR, PBT, vPvB or candidate list substances in the recycled material then the chemical composition of all such content should be established

- Characterise the incoming raw material and the recovered substance(s) to establish average content for each relevant substance and the likely range of its content in any mixture (maximum and minimum). Alternatively the hazard profile of the recovered mixture as such could be established. This information can be used to assess risks and set out risk management measures in the SDS for accepted uses.

For recovered substances (as for other substances) containing impurities that are classified and contribute to the classification, the impurities have to be indicated.

It is worth noting that the presence of impurities as such does not itself give rise to an obligation to supply an SDS under Article 31(1) of REACH. Such obligations may only arise through Article 31(3) requirements.

Other consequences of an Article 2(7)(d) exemption relevant to SDSs

A recovery operator who has the required information available for the same substance and can therefore rely on exemptions according to Article 2(7)(d) of REACH (even if the use of a recovered substance is not covered by the registration of the same substance), is not required to:

- generate an exposure scenario for the use of the recovered substance;

- register the recovered substance;

- notify the use of the recovered substance.

However he should take account of the available information and must provide information on appropriate risk management measures in the SDS, if applicable.

The SDS should be compiled in accordance with the text of Article 31 and Annex II of REACH. Where appropriate guidance set out in the main body of this document together with additional guidance for specific issues set out in this Appendix or in the Guidance on waste and recovered substances should be consulted.

Trade Associations representing specific material recovery sectors may provide their members with examples of how to use this guidance. They may wish to develop further guidance for any issues specific to their material stream.
