---
title: "Front matter and version history"
document_id: "echa-sds-guidance-v4-2020-front"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "1–7"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# Front matter and version history

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-front-page-1"></a>
**ECHA printed page 1** — [original PDF page 1](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=1)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 1](../page_images/ECHA_2020_page_001.jpg)

G U I D A N C E

Guidance on the compilation of safety data sheets

Version 4.0 December 2020


<a id="echa-front-page-2"></a>
**ECHA printed page 2** — [original PDF page 2](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=2)

LEGAL NOTICE   This document aims to assist users in complying with their obligations under the REACH Regulation. However, users are reminded that the text of the REACH Regulation is the only authentic legal reference and that the information in this document does not constitute legal advice. Usage of the information remains under the sole responsibility of the user. The European Chemicals Agency does not accept any liability with regard to the use that may be made of the information contained in this document.

Reference: ECHA-20-H-25-EN ISBN: 978-92-9481-787-7 Publ. date: December 2020 Cat. Number: ED-01-20-770-EN-N DOI: 10.2823/77155 Language: EN

© European Chemicals Agency, 2020

If you have any questions or comments in relation to this document, please send them (quote the reference and issue date) using the information request form. The information request form can be accessed via the Contact ECHA page at: http://echa.europa.eu/contact

European Chemicals Agency

Mailing address: P.O. Box 400, FI-00121 Helsinki, Finland Visiting address: Telakkakatu 6, Helsinki, Finland


<a id="echa-front-page-3"></a>
**ECHA printed page 3** — [original PDF page 3](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=3)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 3](../page_images/ECHA_2020_page_003.jpg)

Version Changes Date

Version 1.0 First edition. September 2011

Version 1.1 Corrigendum covering the following:

December 2011

(1) Footnote 25 on page 24 has been corrected by expanding it to include a full listing of hazard classes or categories under (b), (c), (d) as well as those under (a) already given.

(2) In the discussion of M-factors for mixture components under 3.2 on page 51 a reference to preference for listing in 2.1 (which applies for substances) has been corrected to clarify that for mixtures M-factors for components should be indicated together with their classification information under 3.2.

Version 1.2 Corrigendum of Spanish language version. April 2013

Version 2.0 Update of the guidance covering in particular the extension of Appendix 2 of this guidance by transfer and update of information previously included in a separate guidance document (Part G of the Guidance for IR&CSA). The updated Appendix provides guidance on how to include exposure scenario information in an SDS and on how to extend an SDS by attaching the exposure scenario. Updated guidance is provided on the correlation between the exposure scenario and SDS sections.

December 2013

The update also covers the following issues:

(1) Addition of a note in chapter 3.14 concerning the provision under Regulation No 649/2012 (PIC regulation) to provide an SDS in the language of the country or area of destination.

(2) Update of chapter 3.22 by deleting information already covered by the updated Guidance for downstream users (version 2.0).

(3) Update of chapter 3.23 to ensure consistency with the updated Guidance for downstream users (version 2.0). In particular one additional option for downstream users who need to forward information on mixtures has been added.

(4) Update of table 2 in Appendix 1 to delete information on transition periods which have already expired and to add clarifying detail in improved format on the retained information.

(5) Minor corrections to update hyperlinks and typographical errors.

(6) Change of format to a new ECHA corporate identity.

Version 2.1 Corrigendum to the English language version only.

February 2014

Deletion of the final part of the sentence within brackets in the second paragraph of chapter 3.22.  It now reads as follows: ”(i.e. those fulfilling the PBT/vPvB criteria or the criteria for any of the listed hazard classes in Article 14(4) of REACH as amended by Article 58 of CLP)”.

Version 2.2 Corrigendum to the following language versions only: BG, DA, DE, GR, ES, ET, FI, FR, HR,HU, LT, MT, NL, RO, SL, SV.

December 2014


<a id="echa-front-page-4"></a>
**ECHA printed page 4** — [original PDF page 4](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=4)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 4](../page_images/ECHA_2020_page_004.jpg)

Replacement in chapters 4.2, 4.3 and 4.16 of the translated Hazards Class and Category Codes with the correct versions (i.e. English-based code text) as appear in Annex VI and VII of the CLP Regulation.

Version 3.0 Update of the Guidance to take into account the end of the transitional period for labelling mixtures according to the Dangerous Preparation Directive (DPD), the need to indicate the classification of their components according to the Dangerous Substances Directive (DSD) and reflect the full implementation of the CLP regulation.

August 2015

The update is limited to the following:

(1) Deletion of the reference to obsolete version of Annex II (replaced by Annex II to Commission Regulation No 453/2010 and the Annex to Commission Regulation (EU) 2015/830);

(2) Addition of references to Commission Regulation (EU) 2015/830 which applies form 1 June 2015;

(3) Update of references to legal text as amended by Commission Regulation (EU) 2015/830;

(4) Addition in chapter 1.1 of reference to tables 3.4.6, 3.6.2, 3.7.2, 3.8.3 and 3.9.4 of Annex I of CLP defining the conditions under which some mixtures which do not meet the criteria for classification as hazardous according to CLP also require an SDS to be prepared or be made available on request;

(5) Addition in chapter 1.2 of a clarification of the scope of the updated guidance;

(6) Addition of a new subchapter 1.3 with explanatory text on the transitional provisions in Commission Regulation (EU) 2015/830;

(7) Deletion of original chapter 2 (and renumbering of chapter 3 and its subchapters) containing out of date information, no longer relevant for this document whose scope is now only to provide guidance on the compilation of SDSs according to the requirements in place from 1 June 2015;

(8) Addition in chapter 2.14 of the clarification that the Hazard Class and Category Codes (as given in Annex VI and VII of the CLP Regulation) must not be translated when used in the SDS;

(9) Addition in chapter 2.15 of clarification of the requirement to provide an SDS for non-hazardous mixtures meeting the requirements set out in Table 3.4.6 of Annex I of CLP;

(10) Addition in chapter 2.16 of a clarification regarding the obligation to provide SDS on request for non-classified mixtures containing substances with EU-level workplaces exposure limits regardless of their concentration;

(11) Addition in chapter 3.2 of the full reference to point 0.5 of Annex II of REACH according to Regulation (EU) 2015/830;

(12) Deletion of Appendix 1 on the transitional period for the application of CLP labelling and corresponding SDS requirements;

(13) Deletion of out of date information and minor linguistic corrections of the English language version.


<a id="echa-front-page-5"></a>
**ECHA printed page 5** — [original PDF page 5](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=5)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 5](../page_images/ECHA_2020_page_005.jpg)

Version 3.1 Corrigendum to:

November 2015

- Correct legal text of (EU) 2015/830 and correct highlighting of new legal text (BG, CS, DE, EL, ES, FI, FR, HR, HU, LT, LV, MT, NL, PL, PT, RO, SK, SL, SV);

- Correct which text was highlighted in blue (ET);

- Correct some punctuation and formatting (IT)

- Delete the number of the MARPOL convention from example in chapter 3.14 (EN, BG, CS, EL, ES, FR, HR, HU, IT, LT, LV, MT, NL, PL, PT, SK, SL, SV).

Version 4.0 Update of the guidance to take into account the revised Annex II applicable as of 1 January 2021.

The update includes advice on the provisions regarding:

- Nanoforms (various sections)

- The unique formula identifier (UFI) (SDS Section 1.1)

- Details of the supplier of the safety data sheet (SDS Section 1.3)

- Endocrine disrupting properties (various sections)

- The specific concentration limit, the M-factor and the acute toxicity estimate (SDS Sections 3.1 and 3.2)

- An expansion of SDS Section 9: Physical and chemical properties, in line with the GHS

- An update of SDS Section 14: Transport information

- Application of the transition period (Art 2 of Regulation (EU) 2020/878)

The update has also enabled minor corrections (e.g. updating of hyperlinks), and editing/removal of out-of-date advice (e.g. advice on the CLP transition period).


<a id="echa-front-page-6"></a>
**ECHA printed page 6** — [original PDF page 6](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=6)

Table of Contents  1 General Introduction ............................................................................................ 8

1.1 The safety data sheet ........................................................................................................... 8

1.2 Aim of this guidance ........................................................................................................... 10

1.3 Transitional provision to implement the latest version of Annex II to REACH .............................. 10

1.4 Target audience of this guidance .......................................................................................... 11

1.5 Relation with CLP and GHS .................................................................................................. 11

2 Issues to consider when compiling an SDS ......................................................... 13

2.1 Definition of a safety data sheet (an SDS) ............................................................................. 13

2.2 Responsibility for the content of an SDS ............................................................................... 13

2.3 Claiming an SDS as confidential ........................................................................................... 14

2.4 Possibility of charging for supply of an SDS ........................................................................... 14

2.5 Who should compile an SDS ................................................................................................ 14

2.5.1 Definition of a competent person .................................................................................... 14

2.5.2 Training and continued education of competent persons .................................................... 14

2.6 The sequence, naming and numbering of sections and subsections which must be used in an SDS ....................................................................................................................................... 16

2.7 Necessary degree of completeness when providing information in an SDS ................................. 17

2.8 Need to update SDSs ......................................................................................................... 17

2.9 Need to communicate changes in the SDS ............................................................................ 18

2.10 Potential need to keep records of SDSs and their amendments ................................................ 19

2.11 Example of sequence for collecting and collating information for compiling the SDS ................... 19

2.12 How to help to ensure consistency and completeness of the SDS ............................................. 20

2.13 Ways in which, and by when, the SDS must be provided ......................................................... 20

2.14 Language(s) in which the SDS must be provided.................................................................... 21

2.15 Substances and mixtures for which an SDS must be provided without prior request ................... 22

2.16 Certain mixtures for which an SDS must be provided on request.............................................. 22

2.17 Labelling required for a mixture not classified as hazardous and not intended for the general public for which an SDS must be available and supplied on request ................................................... 23

2.18 SDSs for hazardous substances and mixtures made available to the general public .................... 24

2.19 Access to information in the SDS by workers ......................................................................... 25

2.20 Products for which an SDS is not required ............................................................................. 25

2.21 Possible compilation of an SDS for substances and mixtures even when not legally required ....... 26

2.22 When attachment of Exposure Scenarios to the SDS is required ............................................... 26

2.23 Alternative ways to include the Exposure Scenario information into the SDS for substance and mixtures ........................................................................................................................... 27

2.24 Forms of assistance available in the compilation of SDSs ........................................................ 29

2.25 Selected sources of substance data useful for the compilation of SDSs ..................................... 30

2.26 How to compile an SDS for a recovered substance or mixtures containing such a substance ........ 31

2.27 Testing for the purposes of generation of information for an SDS ............................................. 31

3 Detailed information, section by section ............................................................. 33


<a id="echa-front-page-7"></a>
**ECHA printed page 7** — [original PDF page 7](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=7)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 7](../page_images/ECHA_2020_page_007.jpg)

3.1 SDS SECTION 1: Identification of the substance/mixture and of the company/undertaking ......... 33

3.2 SDS SECTION 2: Hazards identification................................................................................. 41

3.3 SDS SECTION 3: Composition/information on ingredients ....................................................... 46

3.4 SDS SECTION 4: First aid measures ..................................................................................... 57

3.5 SDS SECTION 5: Firefighting measures ................................................................................ 59

3.6 SDS SECTION 6: Accidental release measures ....................................................................... 61

3.7 SDS SECTION 7: Handling and storage ................................................................................. 63

3.8 SDS SECTION 8: Exposure controls/personal protection.......................................................... 68

3.9 SDS SECTION 9: Physical and chemical properties ................................................................. 77

3.10 SDS SECTION 10: Stability and Reactivity ............................................................................. 93

3.11 SDS SECTION 11: Toxicological information .......................................................................... 97

3.12 SDS SECTION 12: Ecological information ............................................................................ 103

3.13 SDS SECTION 13: Disposal considerations .......................................................................... 109

3.14 SDS SECTION 14: Transport Information ............................................................................ 111

3.15 SDS SECTION 15: Regulatory information ........................................................................... 115

3.16 SDS SECTION 16: Other information .................................................................................. 118

Appendix 1. Including relevant exposure scenario information into safety data sheets ......................................................................................................................... 121

Appendix 2. SDS for Special Mixtures ..................................................................... 128

Appendix 3. Specific issues relevant to the compilation of SDSs for recovered substances and mixtures. ................................................................................. 130

Appendix 4. Glossary / List of acronyms ................................................................ 133

Figures  Figure 1: Example sequence for compiling an SDS ................................................................... 20

Tables  Table 1 Relationship between exposure scenario and SDS Sections ...................................... 124
