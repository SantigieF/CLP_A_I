---
title: "Appendix 4 \u2014 Glossary and acronyms"
document_id: "echa-sds-guidance-v4-2020-app4"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "133–136"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# Appendix 4 — Glossary and acronyms

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-app4-page-133"></a>
**ECHA printed page 133** — [original PDF page 133](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=133)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 133](../page_images/ECHA_2020_page_133.jpg)

Appendix 4. Glossary / List of acronyms

List of Acronyms

ATE Acute Toxicity Estimate

ADR European Agreement concerning the International Carriage of Dangerous Goods by Road

ADN European Agreement concerning the International Carriage of Dangerous Goods by Inland Waterways

CEN European Committee for Standardisation

C&L Classification and Labelling

CLP Classification Labelling Packaging Regulation; Regulation (EC) No 1272/2008

CAS# Chemical Abstracts Service number

CMR Carcinogen, Mutagen, or Reproductive Toxicant

CSA Chemical Safety Assessment

CSR Chemical Safety Report

DNEL Derived No Effect Level

DPD Dangerous Preparations Directive 1999/45/EC

DSD Dangerous Substances Directive 67/548/EEC

DU Downstream User

EC European Community

ECHA European Chemicals Agency

EC-Number EINECS and ELINCS Number (see also EINECS and ELINCS)

EEA European Economic Area (EU + Iceland, Liechtenstein and Norway)


<a id="echa-app4-page-134"></a>
**ECHA printed page 134** — [original PDF page 134](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=134)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 134](../page_images/ECHA_2020_page_134.jpg)

EEC European Economic Community

EINECS European Inventory of Existing Commercial Substances

ELINCS European List of notified Chemical Substances

EN European Standard

EQS Environmental Quality Standard

EU European Union

Euphrac European Phrase Catalogue

EWC European Waste Catalogue (replaced by LoW – see below)

GES Generic Exposure Scenario

GHS Globally Harmonized System

IATA International Air Transport Association

ICAO-TI Technical Instructions for the Safe Transport of Dangerous Goods by Air

IMDG International Maritime Dangerous Goods

IMSBC International Maritime Solid Bulk Cargoes

IT Information Technology

IUCLID International Uniform Chemical Information Database

IUPAC International Union for Pure Applied Chemistry

JRC Joint Research Centre

Kow octanol-water partition coefficient

LC50 Lethal Concentration to 50 % of a test population


<a id="echa-app4-page-135"></a>
**ECHA printed page 135** — [original PDF page 135](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=135)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 135](../page_images/ECHA_2020_page_135.jpg)

LD50 Lethal Dose to 50% of a test population (Median Lethal Dose)

LE Legal Entity

LoW List of Wastes (see http://ec.europa.eu/environment/waste/framework/list.htm)

LR Lead Registrant

M/I Manufacturer / Importer

MS Member States

MSDS Material Safety Data Sheet

OC Operational Conditions

OECD Organization for Economic Co-operation and Development

OEL Occupational Exposure Limit

OJ Official Journal

OR Only Representative

OSHA European Agency for Safety and Health at work

PBT Persistent, Bioaccumulative and Toxic substance

PEC Predicted Effect Concentration

PNEC(s) Predicted No Effect Concentration(s)

PPE Personal Protection Equipment

(Q)SAR Qualitative Structure Activity Relationship

REACH Registration, Evaluation, Authorisation and Restriction of Chemicals Regulation (EC) No 1907/2006

RID Regulations concerning the International Carriage of Dangerous Goods by Rail


<a id="echa-app4-page-136"></a>
**ECHA printed page 136** — [original PDF page 136](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=136)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 136](../page_images/ECHA_2020_page_136.jpg)

RIP REACH Implementation Project

RMM Risk Management Measure

SCBA Self-Contained Breathing Apparatus

SDS Safety data sheet

SIEF Substance Information Exchange Forum

SME Small and Medium sized Enterprises

STOT Specific Target Organ Toxicity

(STOT) RE Repeated Exposure

(STOT) SE Single Exposure

SVHC Substances of Very High Concern

UFI Unique Formula Identifier

UN United Nations

vPvB Very Persistent and Very Bioaccumulative
