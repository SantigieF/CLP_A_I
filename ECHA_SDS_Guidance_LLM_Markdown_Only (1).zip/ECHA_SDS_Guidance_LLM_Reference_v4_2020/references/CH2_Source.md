---
title: "2. Issues to consider when compiling an SDS"
document_id: "echa-sds-guidance-v4-2020-ch2"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "13–32"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# 2. Issues to consider when compiling an SDS

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-ch2-page-13"></a>
**ECHA printed page 13** — [original PDF page 13](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=13)

2 Issues to consider when compiling an SDS

2.1 Definition of a safety data sheet (an SDS)

An SDS is a document for which the purpose and role within the harmonised system can be described as follows (based on the text in chapter 1.5 of the UN GHS revision 713):

The SDS should provide comprehensive information about a substance or mixture for use in workplace chemical control regulatory frameworks. Both employers and workers14 use it as a source of information about hazards, and to obtain advice on safety precautions. The SDS is product related and usually [in the absence of relevant attached exposure scenario(s)] is not able to provide specific information that is relevant for any given workplace where the product may finally be used, although where products have specialized end uses the SDS information may be more worker-specific. The information therefore enables the employer (a) to develop an active programme of worker protection measures, including training, which is specific to the individual workplace; and (b) to consider any measures which may be necessary to protect the environment.

In addition, the SDS provides an important source of information for other target audiences. So certain elements of information may be used by those involved with the transport of dangerous goods, emergency responders including poison centres, those involved in the professional use of pesticides and consumers. However, these audiences receive additional information from a variety of other sources such as the UN Recommendations on the Transport of Dangerous Goods, Model Regulations and package inserts for consumers and will continue to do so. The introduction of a harmonised labelling system therefore, is not intended to affect the primary use of the SDS which is for workplace users.

Furthermore, the content of the SDS is an important source of information for the preparation of the submission required under Annex VIII to Regulation (EC) 1272/2008 (CLP).

The required format and content of an SDS within the EU Member States in which the REACH Regulation directly applies (and in other countries which have adopted the REACH Regulation) is defined in Annex II of REACH.

All information contained in the SDS must be written in a clear and concise manner.

2.2 Responsibility for the content of an SDS

Where there is a chain of supply, the requirements of REACH in relation to the provision of safety data sheets apply at each stage of the supply chain. The initial responsibility for drawing up the safety data sheet falls on the first supplier of the substance onto the EU market. In practice, this can be the manufacturer, importer or – in some cases – the only representative who should anticipate, so far as it is reasonably practicable, the uses to which the substance or mixture may be put. Actors further down the supply chain should also provide a safety data sheet, drawing on, checking the adequacy of, and adding to, the information provided by their suppliers to cater for the specific needs of their customers. In all cases, suppliers of a

13 http://www.unece.org/trans/danger/publi/ghs/ghs_rev07/07files_e.html; Globally Harmonized system of Classification and Labelling of Chemicals (GHS). Seventh Revised Edition, 2017.United Nations.

14 It should be noted that in the European Union regulatory framework the SDS is clearly targeted at the employer who should use it as the basis of information and instructions which he transmits to the employee under Article 8.1 4th indent of Directive 98/24/EC. However, the employee is NOT the primary target of the document and its provision to the employee does not release the employer from his obligations under Directive 98/24/EC.


<a id="echa-ch2-page-14"></a>
**ECHA printed page 14** — [original PDF page 14](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=14)

substance or a mixture which requires a safety data sheet have the responsibility for its contents, even though they may not have prepared the safety data sheet themselves. In such cases, the information provided by their suppliers is clearly a useful and relevant source of information for them to use when compiling their own safety data sheets. However, they will remain responsible for the accuracy of the information on the safety data sheets they provide (this also applies to SDSs distributed in languages other than the original language of compilation). It should be noted that the supplier always needs to add their contact details in Section 1.3 of the SDS, even when they use the SDS from their supplier without changing any content (see section 3.1 of this guidance document for more details).

2.3 Claiming an SDS as confidential

The information that is required to appear in an SDS cannot be claimed as confidential.

2.4 Possibility of charging for supply of an SDS

According to Article 31(8) and 31(9) of REACH, the SDS and any required updates to it must be provided free of charge.

2.5 Who should compile an SDS

The text of Annex II specifies in point 0.2.3 that:

“[…] The safety data sheet shall be prepared by a competent person who shall take into account the specific needs and knowledge of the user audience, as far as they are known. Suppliers of substances and mixtures shall ensure that such competent persons have received appropriate training, including refresher training.”

2.5.1 Definition of a competent person

No specific definition of the “competent person” is given in the Regulation. However the term may usefully be defined in this context as meaning a person (or combination of persons) – or a coordinator of a group of people - who has or have, as a result of their training, experience and continued education, sufficient knowledge for the compilation of the respective sections of the SDS or of the entire SDS.

The supplier of the SDS can delegate this function to his own staff or to third parties. It is not necessary that the expert knowledge be provided in full by one single competent person.

It is understood that a single person very rarely has extensive knowledge in all the fields covered by an SDS. It is thus necessary that the competent person rely upon additional competences, either internal or external. The competent person should ensure the consistency of the SDS, especially if he acts as the coordinator of a group of people.

2.5.2 Training and continued education of competent persons

It should be noted (from the text quoted above) that there is a specific duty on the supplier of the substances and mixtures to ensure that the competent persons have received appropriate training and refresher training. There is no specific indication in the REACH Regulation of the training which the competent person should have or that he should attend a special course or pass an official examination. However attendance at such courses and any examination and certification may be useful in demonstrating the required competence.


<a id="echa-ch2-page-15"></a>
**ECHA printed page 15** — [original PDF page 15](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=15)

Training and continued education for these persons may be given internally or externally. It is recommended to document the organisational flow in the compilation and update of SDSs within a company, e.g. by way of internal guidelines or operating procedures.

If SDSs are to be compiled for explosives, biocides, plant protection products15, or surfactants, additional knowledge on specific product legislation applicable to them is needed.

The following (non-exhaustive) list gives an indication of various fields, a knowledge of which a person wishing to demonstrate their competence could refer to:

1. Chemical nomenclature

2. European Regulations and Directives relevant to chemicals and their implementations into MS national legislation, applicable national legislation (in their valid current versions), to the extent that these are relevant in the compilation of SDSs, for instance (non-exhaustive list, shortened titles):

- REACH: Regulation (EC) No 1907/2006 (in particular as amended by Commission Regulation (EU) 2020/878with respect to SDSs)

- CLP: Regulation (EC) No 1272/2008

- Chemical Agents Directive: Directive 98/24/EC

- Indicative Occupational exposure limits: Directives 2000/39/EC, 2006/15/EC, 2009/161/EU, 2017/164/EU and  2019/1831/EU

- Protection of workers from the risks related to exposure to carcinogens or mutagens at work: Directive 2004/37/EC

- Improvements in the safety and health of pregnant workers, workers who have recently given birth and women who are breastfeeding: Directive 92/85/EEC

- Personal protective equipment: Regulation (EU) 2016/425

- Inland transport of dangerous goods: Directive 2008/68/EC

- Detergent Regulation: Regulation(EC) No 648/2004

- Protection of young people at work: Directive 94/33/EC

- Waste: Directive 2008/98/EC

3. Relevant national or international guidelines of the respective sector association

4. First aid measures

- (See chapter 3.4 of this document)

5. Accident prevention

- Fire and explosion prevention, fire fighting, extinguishing media

- Measures in the event of accidental release

- (See chapter 3.6 of this document)

6. Measures for safe handling and storage

- (See in particular chapter 3.7 of this document)

7. Physical and chemical properties:

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   15 For a list of relevant legislation on plant protection and biocidal products see Article 15 of REACH.


<a id="echa-ch2-page-16"></a>
**ECHA printed page 16** — [original PDF page 16](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=16)

- Particularly properties as listed and discussed in the legal text below under Subsection 9.1 of Annex II (see chapter 3.9 of this document).

8. Toxicology/eco-toxicology:

- Particularly properties as listed and discussed in the legal text below under Section 11 and 12 of Annex II (see chapter 3.11 and 3.12 of this document).

9. Transport provisions

- Particularly as listed and discussed in the legal text below under Section 14 of Annex II (see chapter 3.14 of this document).

10. National provisions

- Relevant national provisions, such as (this is a non-exhaustive list)

In Germany:

- Water hazard classes (Wassergefährdungsklassen)

- Technical instruction air (TA-Luft)

- Technical rules for hazardous substances (Technische Regeln für Gefahrstoffe)

In France:

- Tableaux de maladies professionnelles

- Nomenclature des installations classées pour la protection de l‘environnement

In the Netherlands:

- De Algemene Beoordelingsmethodiek Water (ABM)

- National product registers (for example Denmark, Finland, Italy, Sweden etc.)

2.6 The sequence, naming and numbering of sections and subsections which must be used in an SDS

The name of each section and subsection heading, of individual headings and sub-headings in the SDS is specified in Annex II. In particular Part B of the Annex II requires that:

“The safety data sheet shall include the following 16 headings in accordance with Article 31(6) and in addition the subheadings also listed except Section 3, where only subsection 3.1 or 3.2 need to be included as appropriate:”

(See legal text for the full list of headings and sub-headings).

It should be noted that for the Section headings themselves the word “SECTION” is a part of the heading specified as being required. For example, the full heading for Section 1 of the SDS is:

“SECTION 1: Identification of the substance/mixture and of the company/undertaking”

No numbering at a level lower than the sub-heading is legally required, but this may be introduced by the supplier in the interest of clarity (e.g. in Section 14 to differentiate between different modes of transport).

In particular, the numbering of the sub-paragraphs and points in Part A of the Annex II legal text should not be confused with the required numbering of sections and subsections according


<a id="echa-ch2-page-17"></a>
**ECHA printed page 17** — [original PDF page 17](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=17)

to Part B.

Thus, for example in the case of SECTION 11 toxicological information, according to Part B the following heading and sub-headings must be used:

“SECTION 11: Toxicological information

11.1. Information on hazard classes as defined in Regulation (EC) No 1272/2008”

The presence of points (”sub-sub-paragraphs”) numbered 11.1.1, 11.1.2, … …  11.1.12.2, … … etc in Part A under the heading of SECTION 11 to facilitate distinguishing of the individual elements does not mean that the information required under these points needs to be included under an identical description or heading to that given in Part A at any level below the subsection level. The structure of the SDS, as defined by the section and subsection headings is only pre-defined to the extent given in Part B.

This also applies to all the examples given for the structuring of data within any sections and subsections of an SDS contained in this document. Any sub-structuring or titles of further subsections of data given beyond the parent SECTION and the first subsection numbering is only an example of a possible structure.

The information that the SDS must contain within each of these headings and sub-headings is discussed in more detail in chapter 3 of this document. With the exception of subsections 3.1 and 3.2 (where either one or the other should contain information) some information must be entered in every subsection, even if this “information” is only an explanation of why data is not available or confirmation of non-applicability etc. Information should be inserted into subsections, not directly under the parent section heading.

Where a document using the format of an SDS is produced for a substance or mixture that does not require an SDS according to Article 31 of REACH (e.g. as a convenient way of supplying information required by Article 32 or based on a commercial decision to supply “SDS-like” documents for all substances and mixtures supplied by an actor) the requirements for content in each of the sections would not apply. In such cases it may be advisable to explain that the document is outside the scope of Article 31 of REACH for the convenience of recipients and enforcing authorities.

2.7 Necessary degree of completeness when providing information in an SDS

The information requirements are explained in detail in chapter 3. It should be noted that where specific data are not applicable or where data are not available, this must be clearly stated. Where the legal text states “if available”, this means not only that the information exists but that it is accessible to the safety data sheet provider.

2.8 Need to update SDSs

The conditions under which an SDS must be updated and re-issued are given in Article 31(9) of REACH as follows:

“9. Suppliers shall update the safety data sheet without delay on the following occasions:

(a) as soon as new information which may affect the risk management measures, or new information on hazards becomes available;

(b) once an authorisation has been granted or refused;

(c) once a restriction has been imposed.


<a id="echa-ch2-page-18"></a>
**ECHA printed page 18** — [original PDF page 18](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=18)

The new, dated version of the information, identified as ‘Revision: (date)’, shall be provided free of charge on paper or electronically to all former recipients to whom they have supplied the substance or mixture within the preceding 12 months. Any updates following registration shall include the registration number.”

Thus, although there are industry documents available which give recommendations on when a change in an SDS is considered a “major” or a “minor” change, this terminology is not used in the REACH Regulation. Only the changes according to Article 31 (9) of REACH give rise to a legal obligation to provide updated versions to all recipients to whom the substance or mixture has been supplied within the preceding 12 months. Paragraph 42 of the general court ruling T- 268/10 RENV16 from 2015 (confirmed by the court case C-650/15-P in 2017), provides that the addition of a substance to the candidate list (Article 59 of REACH) fulfils Article 31(9)(a) and requires an update of the SDS, with specific additional advice for the recipient of the SDS (for the substance as such or in a mixture) related to the new candidate list status of the substance. Sector and branch organisations may provide their own guidance on when it is desirable to additionally send updated versions of SDSs which are not specifically required by Article 31(9) of REACH, but such additional updates are not a legal requirement.

According to Article 31(9)(b) an SDS shall be updated without delay, once an authorisation has been granted. Authorisations, granted according to Article 60 of REACH, impose conditions on the use of the authorised substance. These conditions include not only the risk management measures and operational conditions, described in the exposure scenarios of the chemical safety report, referred to in the authorisation decision, but also any monitoring arrangements or additional conditions affecting risk management measures indicated in the authorisation decision. In line with Article 31(9)(a) the new information which affects risk management measures by downstream users has to be provided in the update of the SDS without delay (see also the clarification in section 3.15 of this guidance, on authorisation decisions containing obligations for downstream users).

Nevertheless, it is recommended to review the totality of the contents of an SDS at regular intervals. It might be expected that the frequency of such reviews would be commensurate with the hazards of the substance or mixture and that the review would be carried out by a competent person.  In addition to the update requirements outlined in Article 31(9), an SDS will need to be updated due to a legislative change in the new Annex II to REACH, following the timelines provided in the amending regulation.

2.9 Need to communicate changes in the SDS

The text of point 0.2.5 of Annex II to REACH specifies that:

“0.2.5. The date of compilation of the safety data sheet shall be given on the first page. When a safety data sheet has been revised and the new, revised version is provided to recipients, the changes shall be brought to the attention of the recipient in Section 16 of the safety data sheet, unless they have been indicated elsewhere. For the revised safety data sheets, the date of compilation, identified as ‘Revision: (date)’, shall appear on the first page, as well as one or more indications of which version is replaced, such as version number, revision number, or supersedes date.”

Thus, revisions must be identified as such on the first page and information on the changes must be given either in Section 16 or elsewhere in the SDS.

As indicated in 2.8 above, for any revision to an SDS according to Article 31(9) of REACH or

16 https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:62010TJ0268&from=EN


<a id="echa-ch2-page-19"></a>
**ECHA printed page 19** — [original PDF page 19](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=19)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 19](../page_images/ECHA_2020_page_019.jpg)

due to a legislative change in Annex II to REACH, the revised SDS must be provided to all former recipients who received the substance or mixture within the preceding 12 months. A supplier may also choose to (additionally) re-issue SDSs retrospectively for other revisions which he may consider warrant such additional action. It is suggested that an incremental numbering system be used to identify new versions of an SDS. In such a system, changes to versions requiring provision of updates according to Article 31(9) could be identified by an increment by an integer, while other changes could be identified by an increment by a decimal, e.g.:

Version 1.0: initial issue

Version 1.1: first change(s) not requiring update and re-issue to former recipients

Version 1.2: second change(s) not requiring update and re-issue to former recipients

Version 2.0: first change requiring provision of update according to Article 31(9) to former recipients.

Etc.

This is just an example of how to facilitate traceability of versions. There are many other systems.

2.10 Potential need to keep records of SDSs and their amendments

The first sentence of Article 36(1) of REACH requires that:

“1. Each manufacturer, importer, downstream user and distributor shall assemble and keep available all the information he requires to carry out his duties under this Regulation for a period of at least 10 years after he last manufactured, imported, supplied or used the substance or mixture”.

As the compilation and supply of safety data sheets, as well as taking into account the information from the SDS in using substances and mixtures, are obligations under REACH, SDSs are for both the suppliers of SDSs and their recipients “information he requires to carry out his duties under this Regulation”, which is to be retained for a minimum period of 10 years. Furthermore, the information used in the compilation of the SDS is itself likely to constitute information required to carry out duties under REACH and may in any case be required to be kept independently of its relation to the content of the SDS. Holders of both SDSs and other information may in any case decide that it should be retained for product liability and other legal requirements and it might be considered appropriate (for example for substances and mixtures with chronic effects) to keep this information for a period of more than 10 years, depending on the applicable national laws and regulations.

2.11 Example of sequence for collecting and collating information for compiling the SDS

A suggestion for a step-wise approach to the creation of an SDS to ensure its internal consistency is given in Figure 1 below (the numbers refer to the sections of the SDS):

Figure 1 below shows the process as a linear one to stress that, for example, the final identification of hazards in Section 2 of the SDS is not likely to be possible until the inputs to other sections have been considered. In reality the process is likely to be an iterative one involving consideration of some aspects in different sequences to that shown or even in parallel.


<a id="echa-ch2-page-20"></a>
**ECHA printed page 20** — [original PDF page 20](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=20)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 20](../page_images/ECHA_2020_page_020.jpg)

9. Physical and chemical
properties incl.
classification
10. Stability and reactivity
11. Toxicological
information incl.
classification
12. Ecological information
incl. classification

3. Composition and determination of hazard classification of components

1. Identification

14. Transport 15. Regulatory information 8. Exposure controls 7. Handling and storage

4. First aid 5. Fire-fighting 6. Accidental release

13. Disposal 16. Other information

2. Hazard identification

Figure 1: Example sequence for compiling an SDS

2.12 How to help to ensure consistency and completeness of the SDS

The SDS gives information on a very wide range of aspects of occupational health and safety, transport safety and environmental protection. As SDSs are frequently not compiled by just one person but rather by several members of staff, unintended gaps or overlaps cannot be ruled out. Consequently, it is useful to subject the finished SDS and its annex (if applicable) to a consistency and plausibility check before providing it to recipients. It may be desirable for the final review to be carried out by a single competent person rather than separate individuals to allow an overview of the document as a whole. As part of a completeness check, it is recommended to also verify that the information in the SDS is consistent with the information on the label and with the REACH registration dossier in the case of compilation made by a manufacturer or importer of registered substances.

2.13 Ways in which, and by when, the SDS must be provided

According to Article 31 (8) of REACH “A safety data sheet shall be provided free of charge on paper or electronically no later than the date on which the substance or mixture is first supplied.”


<a id="echa-ch2-page-21"></a>
**ECHA printed page 21** — [original PDF page 21](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=21)

Thus, the safety data sheet can be provided on paper, for example by letter, by fax or electronically, for example by email.

It should be noted however that in this context the wording “shall be provided” is to be understood as a proactive duty on the supplier to actually deliver the SDS (and every required update) rather than just make it available passively, for example on the internet or reactively by delivering it on request. Therefore, ECHA’s Forum comprising national enforcement representatives agreed that, for example, simply posting a copy of an SDS (or an update to one) on a web site alone would not be considered as having complied with the duty to “provide”. In the case of electronic “provision”, supply of the SDS (and any corresponding exposure scenario attachments) as an attachment to an e-mail in a format which is generally accessible to all recipients would therefore be acceptable. By contrast, sending an e-mail with a link to a general web-site where the SDS (or latest updated SDS) needs to be found and downloaded from would not be acceptable. Most national enforcement authorities agree that supplying an SDS by providing a link must fulfil the following pre-conditions (indicative list of requirements):

1) The link is direct and leads to the specific SDS for the chemical supplied 2) The link is reliable and functioning, and should remain active continuously and, preferably, permanently 3) If permanent activity cannot be ensured, supplier should warn the customer about temporary accessibility and its duration to allow the customer to download the SDS 4) Updates to the link (e.g. due to changes in the website) should be actively sent to the customer 5) Updates to the SDS itself must also be actively communicated to the customer 6) There should be no hindrance in accessing the SDS when using the link – e.g., no login or registration can be required.

Once an SDS has been supplied for a first delivery of a substance or mixture to a particular recipient, there is no need to supply a further copy of the SDS with subsequent deliveries to the same recipient unless the SDS is revised. Further information on communication of changes resulting from revisions is given in chapter 2.9 above.

2.14 Language(s) in which the SDS must be provided

According to REACH Article 31(5), “The safety data sheet shall be supplied in an official language of the Member State(s) where the substance or mixture is placed on the market, unless the Member State(s) concerned provide otherwise”. It should be noted that it is for the recipient Member State (MS) to provide otherwise – i.e. for example the existence of an exemption in the MS of manufacture does not give an exemption in a different MS where the substance or mixture is placed on the market. Even if the MS provides otherwise, it may be desirable to always provide (potentially in addition) the SDS in the language of the country.

It should be noted that certain Member States require that the SDS be provided in additional official MS languages (of that MS, where there is more than one official language)17.

It should also be noted that as the annexed exposure scenario is considered to be an integral part of the SDS it is subject to the same translation requirements as the SDS itself – i.e. it must be supplied in an official language of the Member State(s) where the substance or mixture is placed on the market, unless the recipient Member State(s) concerned provide

17 ECHA has published the table “Languages required for labels and safety data sheets”, and it is available at: http://echa.europa.eu/safety-data-sheets


<a id="echa-ch2-page-22"></a>
**ECHA printed page 22** — [original PDF page 22](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=22)

otherwise.

It is important to highlight that in Section 2 of the SDS, either the full wording of the hazard classification and of the hazard statements or the “Hazard Class and Category Code(s)” (listed in Table 1.1 of Annex VI to CLP and appearing in Table 3 of Annex VI to CLP) and hazard statement codes18 may be used. If the full wording is used, it needs to be in the language of the SDS. If the Hazard Class and Category code(s) are used, the abbreviations given for each hazard class must not be translated (these are language-independent codes based on [abbreviated] English words, but not “English-language text”). The codes must thus remain as these are given in Annex VI to CLP. If codes, other abbreviations or acronyms are used, their full text and explanation must be given in Section 16 of the SDS, in the language of the SDS.

For example, for a flammable substance, if the Hazard Class and Category Code “Flam.Liq.1, H224” (corresponding to Flammable liquid, Category 1) is used, this must not be translated. The full text corresponding to that code, however, has to be given in the language of the SDS, in Section 16. If, however, the classification, including the hazard statements, is written out in full, then further explanation in Section 16 is not required.

It should be further noted that according to the provisions of Article 17 (4) of the Prior Informed Consent (PIC) Regulation19, for substances for which an SDS is required (in the format of Annex II to REACH) according to Article 17 (3) of the same regulation: “The information on the label and on the safety data sheet shall as far as practicable be given in the official languages, or in one or more of the principal languages, of the country of destination or of the area of intended use” i.e. in such cases the language(s) in which the SDS is to be supplied may include (where practicable) languages which are not official languages of any EU Member State.

2.15 Substances and mixtures for which an SDS must be provided without prior request

According to Article 31 (1) of REACH (as amended by Article 59(2)(a) of CLP), the criteria for when an SDS must be provided (even without request) are:

“(a) where a substance or mixture meets the criteria for classification as hazardous in accordance with Regulation (EC) No 1272/2008; or

(b) where a substance is persistent, bioaccumulative and toxic or very persistent and very bioaccumulative in accordance with the criteria set out in Annex XIII; or

(c) where a substance is included in the list established in accordance with Article 59(1) for reasons other than those referred to in points (a) and (b).” (where the latter list corresponds to the so called “candidate list”20 for authorisation (list published on ECHA website, see link in the footnote).

2.16 Certain mixtures for which an SDS must be provided on request

Article 31(3) of REACH (as amended by Article 59(2)(b) of CLP) specifies the conditions under which an SDS must be supplied on request (for certain mixtures). The text specifying these

18 It is important to underline that in CLP different types of codes are used. Thus, “Hazard Class and Category Codes” (e.g. ‘Acute Tox.4’) should not be confused with “Hazard statement codes” (e.g. H312). 19 Regulation (EU) No 649/2012 of the European Parliament and of the Council of 4 July 2012 concerning the export and import of hazardous chemicals (recast); OJ L 201 27.07.2012 p 60. Available at https://eur- lex.europa.eu/legal-content/EN/ALL/?uri=CELEX%3A32012R0649  20 https://echa.europa.eu/candidate-list-table


<a id="echa-ch2-page-23"></a>
**ECHA printed page 23** — [original PDF page 23](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=23)

conditions is the following:

“3. The supplier shall provide the recipient at his request with a safety data sheet compiled in accordance with Annex II, where a mixture does not meet the criteria for classification as hazardous in accordance with Titles I and II of Regulation (EC) No 1272/2008, but contains:

(a) in an individual concentration of ≥ 1 % by weight for non-gaseous mixtures and ≥ 0,2 % by volume for gaseous mixtures at least one substance posing human health or environmental hazards; or

(b) in an individual concentration of ≥ 0,1 % by weight for non-gaseous mixtures at least one substance that is carcinogenic category 2 or toxic to reproduction category 1A, 1B and 2, skin sensitiser category 1, respiratory sensitiser category 1, or has effects on or via lactation or is persistent, bioaccumulative and toxic (PBT) in accordance with the criteria set out in Annex XIII or very persistent and very bioaccumulative (vPvB) in accordance with the criteria set out in Annex XIII or has been included for reasons other than those referred to in point (a) in the list established in accordance with Article 59(1); or

(c) a substance for which there are Community workplace exposure limits.”

It is important to note that the obligation triggered by point (c) is not dependent on the concentration of the substance in the mixture. The obligation to supply an SDS on request applies to a mixture containing a substance for which there is an EU-level workplace exposure limit21, present at any concentration. It is recommended to always indicate in the SDS for the mixture which substance triggers the requirement (even if the substance only needs to be stated and its precise concentration indicated if it is present in a concentration equal or greater than the threshold indicated in point 3.2.2 of Annex II, see chapter 3.2).

On the obligation triggered by point (b), suppliers will need to provide, upon request, a safety data sheet for a non-classified mixture that contains certain hazardous substances in concentrations above or equal to the specified value but will not be obliged to indicate the substances present nor the concentrations in which they are present if no limits are specified in subsection 3.2.2. of Annex II to REACH or if any specified limits are not reached.

The obligation to provide an SDS on request is also laid down in the CLP Regulation. According to Note 1 in tables 3.4.6, 3.6.2, 3.7.2, 3.8.3 and 3.9.4 of Annex I to the CLP Regulation, this requirement applies to mixtures not classified but containing at least one substance classified as skin sensitiser category 1, sub-category 1A or 1B, respiratory sensitiser category 1, sub-category 1A or 1B, carcinogenic category 2, reproductive toxicant category 1 or 2 or for effects on/via lactation and specific target organ toxicant category 2 (single or repeated exposure) above the threshold defined in the Notes to the same tables.

2.17 Labelling required for a mixture not classified as hazardous and not intended for the general public for which an SDS must be available and supplied on request

For mixtures not classified as hazardous under CLP and not intended for the general public but which contain certain specified classified components at and above specified limits, for which an SDS must be provided on request, the label on the packaging must bear information indicating the availability of such SDSs.

The text required to indicate the availability of an SDS is the statement EUH210: “Safety data sheet available on request”.

The concentration limits specified in CLP Annex II, point 2.10, are the following:

For mixtures not classified as hazardous but which contain:

21 https://osha.europa.eu/en/legislation/directive/directive20191831-indicative-occupational-exposure-limit-values


<a id="echa-ch2-page-24"></a>
**ECHA printed page 24** — [original PDF page 24](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=24)

≥ 0,1 % of a substance classified as skin sensitiser category 1, 1B, respiratory sensitiser category 1, 1B, or carcinogenic category 2, or

≥ 0,01 % of a substance classified as skin sensitiser category 1A, respiratory sensitiser category 1A, or

≥ one tenth of the specific concentration limit for a substance classified as skin sensitiser or respiratory sensitiser with specific concentration limit lower than 0,1 %, or

≥ 0,1  % of a substance classified as toxic to reproduction categories 1A, 1B or 2, or with effects on or via lactation; or

at least one substance in an individual concentration of ≥ 1 % by weight for non-gaseous mixtures and ≥ 0,2  % by volume for gaseous mixtures either:

classified with other health or environmental hazards; or

for which there are Community workplace exposure limits

2.18 SDSs for hazardous substances and mixtures made available to the general public

Article 31 (4) of REACH states for substances and mixtures sold to the general public:

“The safety data sheet need not be supplied where hazardous substances or mixtures offered or sold to the general public are provided with sufficient information to enable users to take the necessary measures as regards the protection of human health, safety and the environment, unless requested by a downstream user or distributor.”

Thus, it is not mandatory for a safety data sheet to be supplied for a hazardous substance or mixture made available to the general public22 if the above conditions are complied with. However, if the product is also supplied to a downstream user or distributor and he requests an SDS, it must be supplied to him. It may be recommendable for the distributor (e.g. retailer) offering or selling these substances or mixtures to be in possession of an SDS for each hazardous substance or mixture which he sells. These SDSs also contain important information for him as he has to store the substance or mixture and can give important information e.g. on measures in case of an accident (or fire etc.). If the downstream user or distributor feels that he needs an SDS for these or other purposes he can request one.

It should be noted that the actor who is specifically allowed to request the SDS by this provision is the downstream user or distributor – it is not the member of the public (“consumer”). The question of whether a particular customer for such a substance or mixture is entitled to request and receive an SDS for it can therefore be addressed on the basis of whether he qualifies as either a ‘downstream user’ or a ‘distributor’ under the definitions given in Article 3 (13) and 3 (14) of the REACH regulation respectively. A “consumer” is specifically excluded from the definition of a downstream user. Whether a recipient qualifies as a downstream user with respect to use of the substance or mixture “in the course of his industrial or professional activities” may be determined for example on the basis of his professional background. A reliable proof of the right to request an SDS could be an excerpt from the trade register/register of companies or other professional accreditation or potentially

22 There are no provisions in REACH under which an SDS ever has to be supplied to a member of the general public (a “consumer”); there is also no provision to stop this being done on a voluntary basis by any actor in the supply chain.


<a id="echa-ch2-page-25"></a>
**ECHA printed page 25** — [original PDF page 25](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=25)

a VAT number (or holding of an account with the supplier), rather than depending solely on quantities (which itself may serve as a first indicator).

2.19 Access to information in the SDS by workers

According to Article 35 of REACH:

“Workers and their representatives shall be granted access by their employer to the information provided in accordance with Articles 31 and 32 in relation to substances or mixtures that they use or may be exposed to in the course of their work.”

The SDS (in the EU) is aimed at the employer and the self-employed. The employer has a responsibility to transform the information into suitable formats to manage risks at the specific workplace. Nonetheless access must be given to relevant SDS information to workers and their representatives according to Article 35 of REACH (as well as according to Article 8 of Directive 98/24/EC).

2.20 Products for which an SDS is not required

The requirements to provide an SDS arise from Article 31 of the REACH Regulation.

Certain general exemptions from the need to supply information according to Title IV (therefore including SDSs according to Article 31) are given in Article 2 (6):

“The provisions of Title IV shall not apply to the following mixtures in the finished state, intended for the final user:

(a) medicinal products for human or veterinary use, within the scope of Regulation (EC) No 726/2004 and Directive 2001/82/EC and as defined in Directive 2001/83/EC;

(b) cosmetic products as defined in Directive 76/768/EEC;

(c) medical devices which are invasive or used in direct physical contact with the human body in so far as Community measures lay down provisions for the classification and labelling of dangerous substances and mixtures which ensure the same level of information provision and protection as Directive 1999/45/EC;

(d) food or feedingstuffs in accordance with Regulation (EC) No 178/2002 including use:

(i) as a food additive in foodstuffs within the scope of Directive 89/107/EEC;

(ii) as a flavouring in foodstuffs within the scope of Directive 88/388/EEC and Decision 1999/217/EC;

(iii) as an additive in feedingstuffs within the scope of Regulation (EC) No 1831/2003;

(iv) in animal nutrition within the scope of Directive 82/471/EEC.”

Even more general exemptions from the whole of the REACH apply to other classes of products via Article 2(1) (radioactive substances, substances under customs supervision, non-isolated intermediates, products during carriage by rail, road, inland waterway, sea or air).

Waste as defined in Directive 2008/98/EC 23 is also exempted in general by virtue of being excluded by Article 2(2) from being defined as a substance, mixture or article within the meaning of Article 3 of the REACH Regulation.

SDSs are also of course not required for products that do not conform either to the criteria

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   23 Directive 2006/12/EC - repealed by Directive 2008/98/EC of the European Parliament and of the Council of 19 November 2008 on waste and repealing certain Directives (Waste Framework Directive).


<a id="echa-ch2-page-26"></a>
**ECHA printed page 26** — [original PDF page 26](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=26)

given in Article 31(1) (a), (b) and (c) or to those in Article 31(3) for when SDSs are required (see Section 1.1 of the General Introduction above and the text of REACH for more detail on what the criteria are).

2.21 Possible compilation of an SDS for substances and mixtures even when not legally required

From marketing and/or logistical aspects it may in certain cases be useful for suppliers to have SDS available for all substances and mixtures, including those for which there is no legal obligation to provide an SDS. In such cases, it may be desirable to indicate in the document that the substance or mixture does not legally require an SDS to avoid unnecessary compliance and conformity issues arising. It is not generally desirable to compile SDSs for articles.

It may also be useful to supply information required according to Article 32 of REACH concerning the duty to communicate information down the supply chain for substances on their own or in mixtures for which a SDS is not required in the SDS format. However, it should be noted that this is not required by the REACH Regulation, and again in these cases it may be desirable to indicate in the document that the substance or mixture does not legally require an SDS, to avoid unnecessary compliance and conformity issues arising. Similarly, it may be specifically indicated when such a document is being used to communicate information according to Article 32.

2.22 When attachment of Exposure Scenarios to the SDS is required

According to the first paragraph of Article 31(7) of REACH:

“Any actor in the supply chain who is required to prepare a chemical safety report according to Articles 14 or 37 shall place the relevant exposure scenarios (including use and exposure categories where appropriate) in an annex to the safety data sheet covering identified uses and including specific conditions resulting from the application of Section 3 of Annex XI.”

Thus, whenever there is a requirement for an actor (e.g. a registrant or a downstream user preparing a CSR according to Articles 14 or 37(4) of REACH) to include exposure scenarios in their CSR, the actor has an obligation to place the relevant exposure scenarios in an Annex to the SDS. It should be noted however that not all registrants who are required to carry out a CSA and prepare a CSR24 are necessarily required to prepare an exposure scenario. Thus, for example, although a CSA and a CSR are generally required for all substances subject to registration in quantities of 10 tonnes or more, an exposure scenario is only required for those for which the further criteria given in Article 14 (4) also apply (i.e. those fulfilling the PBT/vPvB criteria or the criteria for any of the listed hazard classes in Article 14(4) of REACH as amended by Article 58 of CLP). These criteria are25:

24 Note that  there are cases where no CSA/CSR is needed at all (and thereby no ESs are to be provided), for instance in the case of substances exempted from registration under annex IV or V or for recovered substances exempted from presenting a registration dossier under art 2(7) (d).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 25 The hazard classes or categories corresponding to the listing (where not already named in full in the text above) are: (a) explosives (2.1), flammable gases (2.2), aerosols (2.3), oxidising gases (2.4), flammable liquids (2.6), flammable solids (2.7), self-reactive substances and mixtures types A and B (2.8 A + B), pyrophoric liquids (2.9), pyrophoric solids (2.10), substances and mixtures which in contact with water emit flammable gases (2.12), oxidising liquids categories 1 and 2 (2.13  1 + 2), oxidising solids categories 1 and 2 (2.14 1 + 2), organic peroxides types A to


<a id="echa-ch2-page-27"></a>
**ECHA printed page 27** — [original PDF page 27](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=27)

“4. If, as a result of carrying out steps (a) to (d) of paragraph 3, the registrant concludes that the substance fulfils the criteria for any of the following hazard classes or categories set out in Annex I to Regulation (EC) No 1272/2008:

(a) hazard classes 2.1 to 2.4, 2.6 and 2.7, 2.8 types A and B, 2.9, 2.10, 2.12, 2.13 categories 1 and 2, 2.14 categories 1 and 2, 2.15 types A to F;

(b) hazard classes 3.1 to 3.6, 3.7 adverse effects on sexual function and fertility or on development, 3.8 effects other than narcotic effects, 3.9 and 3.10;

(c) hazard class 4.1;

(d) hazard class 5.1

or is assessed to be a PBT or vPvB, … …”

Hence, if the substance does not fulfil any of the criteria of Article 14(4) (hazard classes, categories or properties) an exposure assessment is not needed and the registrant can directly document the hazard assessment and PBT/vPvB assessment in the chemical safety report without the need to generate an exposure scenario. Furthermore, the CSA and CSR would normally be carried out as part of the preparations for a registration. Exposure scenarios for particular substances on their own or in mixtures will therefore normally only be attached to SDSs after the respective substance has been registered.

Articles 60(7), 62(4)(d) and sections 0.7, 5.1.1 and 5.1.2 of Annex I of REACH, describe chemical safety report and exposure scenario related obligations. These aspects form an integral part of the application for authorisation process. Granted authorisations based on either Article 60(2) or Article 60(4) include consideration of the risk management measures proposed in the exposure scenarios of the authorisation chemical safety report.

Once prepared, the exposure scenario should be attached to SDS, and its attachment would then constitute a revision to the SDS. Where the exposure scenario results in new risk management measures, the SDS must be updated without delay and the revised version provided to former recipients who have received the substance or mixture within the preceding 12 months, in accordance with the provisions of Article 31(9)(a)  of REACH (see also chapter 2.8 above).

2.23 Alternative ways to include26 the Exposure Scenario information into the SDS for substance and mixtures

For the cases described in 2.21 above, Article 31(7) of REACH specifies that the exposure scenario must be placed in an annex to the SDS.

However, the second and third subparagraphs of Article 31(7) further state that:

“Any downstream user shall include relevant exposure scenarios, and use other relevant information, from the safety data sheet supplied to him when compiling his own safety data sheet for identified uses.

Any distributor shall pass on relevant exposure scenarios, and use other relevant information, from the safety data sheet supplied to him when compiling his own safety data sheet for uses for which he

F (2.15 A to F inclusive); (b) acute toxicity (3.1), skin corrosion/irritation (3.2), serious eye damage/eye irritation (3.3) respiratory or skin sensitisation (3.4), germ cell mutagenicity (3.5), carcinogenicity (3.6), [3,7, 3.8 as above], specific target organ toxicity – repeated exposure (3.9), aspiration hazard (3.10); (c) hazardous to the aquatic environment (4.1); (d) hazardous to the ozone layer (5.1).

26 “Include” is used here to mean either attach the exposure scenario (s) as a whole to the SDS (as an annex) and/or integrate information from the exposure scenario into the main body (Sections 1 to 16 inclusive) of the SDS and/or append to the SDS safe use information for the mixture.


<a id="echa-ch2-page-28"></a>
**ECHA printed page 28** — [original PDF page 28](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=28)

has passed on information according to Article 37(2).”

For downstream users who are not required to carry out their own CSA for a particular

(component) substance27 there are therefore alternative options for inclusion of the exposure

scenario information28.

In the case of a mixture containing substances for which an exposure scenario was required, the inclusion of exposure scenario information in the SDS for the mixture must take into account at least those substances present above the thresholds given in Article 14 of REACH.

The result is the following possible cases for inclusion of exposure scenario(s) information (carried out by a manufacturer/importer or by a downstream user) into SDSs:

1. attachment of the actual exposure scenario (s) resulting from a CSA for a substance as such or exposure scenario resulting from the CSA for a substance in a mixture in concentrations above the thresholds given in Article 14. In this case, at least a summary of the relevant key information from the attached exposure scenario must be included into the core sections of the SDS, with a cross-reference to the details in the exposure scenario;

2. integration of exposure scenario information for a substance or resulting from consolidation of various exposure scenarios for substances used in a mixture into the core Sections 1-16 of the SDS;

3. attachment of exposure scenario resulting from the CSA for a special mixture29;

4. (potentially) attachment of exposure scenario resulting from a CSA for a mixture under Article 31(2) of REACH30.

5. append safe use information for the mixture derived from the exposure scenarios of the component substances.

It should be noted that for a component of a mixture for which the downstream user is required to carry out a CSA option 2 above is not available.

It should further be noted that although all of the options above are allowed under the specified conditions, these may not all be equally suitable in practice as a means of forwarding the relevant information – for example further downstream users may prefer to receive forwarded exposure scenarios for component substances in the mixtures that they receive rather than consolidated documentation. In this way, when they then formulate these mixtures into further mixtures the component substances can be reconsidered together with the new components. Option 2 may be more appropriate e.g. when supplying professional end-users. Likewise, it is strongly recommended to use option 2 if the attachment of exposure scenarios for component substances in mixtures would otherwise lead to SDSs of such inordinate length that their recipients further down the supply chain would no longer be able to cope with the

27 These alternative options are only available to such downstream users.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 28 The change in wording from “shall place” in the first paragraph of Article 31(7) with respect to those required both to carry out a CSA/CSR and prepare an exposure scenario to “shall include relevant exposure scenarios” in the second paragraph with respect to downstream users is significant. The latter wording is to be interpreted as allowing (if the SDS compiler so chooses) “inclusion” of the relevant information from received exposure scenarios by methods other than attachment as an Annex to the SDS.

29 See Appendix 2 for more information on “special mixtures”.

30 At present there is no guidance available on how to carry out such a CSA. Such a CSA for a mixture is foreseen by Article 31(2) of REACH for the purposes of generating consolidated information for an SDS.  Neither Article 14 nor Article 37 of REACH generate a requirement for such a CSA to be prepared as part of a registration.


<a id="echa-ch2-page-29"></a>
**ECHA printed page 29** — [original PDF page 29](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=29)

amount of information contained within them.

The actor compiling the SDS should keep in mind that recommendations from exposure scenarios give rise to specific obligations upon downstream users (Article 37(4)). In order for downstream users to be able to recognise such obligations (such as RMMs to be implemented), it is recommended that information originating from exposure scenario(s) – either incorporated in the body of the SDS or appended to the SDS - is indicated as such.

Appendix 1 provides more guidance to downstream users who need to “include” the exposure scenario information for a substance into a SDS.

Detailed guidance on options for downstream users on how to forward downstream information received from supplier(s) on the substance(s) as such or in a mixture(s) is provided in the Guidance for Downstream users31.

Furthermore, a specific network has been established by ECHA and some sector organisations with the aim to develop and provide methodologies and tools to improve effective communication along the supply chain. More information is available on the ENES page of the ECHA website32.

Appendix 1 to this guidance and, in more detail, Appendix 1 to the Guidance for downstream users, provide more information on the roles and obligations of distributors. They play an important role in the communication flow up and down the supply chain.

2.24 Forms of assistance available in the compilation of SDSs

Suppliers may use an external service provider to access the services of competent persons for the compilation of SDSs, but of course it is still the supplier’s responsibility to provide SDSs that comply with the legal requirements.

Parties compiling and issuing SDSs may be supported by relevant software applications. These applications generally have a database function. These databases contain substance lists and libraries of standard phrases. Many software products include options for generating SDSs in several languages. Such software products may also support the management and consistency of information between the registration dossier (including the CSR) and the SDS.

An example of a source of standard phrases is the European Phrase Catalogue, which is available (at no charge) in German and English via https://www.esdscom.eu/english/euphrac- phrases/. Other service providers also offer libraries of standard phrases. The correct use of standard phrases can help to improve quality and comprehensibility, however care should be taken when using these phrases, as the content may not always be sufficiently clear. Software products do not release the supplier from his obligation to have the safety data sheet prepared by a competent person.

Some industry or trade associations offer support (e.g. via their internet homepages) with information regarding their specific sector.

31 Available at:  https://echa.europa.eu/guidance-documents/guidance-on-reach

32 Exchange Network on Exposure Scenarios, see: https://echa.europa.eu/about-us/exchange-network-on-exposure- scenarios


<a id="echa-ch2-page-30"></a>
**ECHA printed page 30** — [original PDF page 30](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=30)

2.25 Selected sources of substance data useful for the compilation of SDSs

A large part of the information necessary in order to compile the SDS should already be available to the supplier, as it will have been necessary to gather it for the purposes of other chemicals control legislation, notably in order to determine e.g. the classification, labelling and packaging requirements according to CLP and according to international transport legislation, and to comply with occupational health and safety legislation.

If the substance is subject to Registration under REACH and the supplier is a member of joint submission or a consortium33, if one exists for that substance, he may have shared access to additional information on the substance.

For downstream users of substances (and all formulators of mixtures), the key source of information is that provided by the supplier in the SDS for the specific (component) substance(s) or mixture(s).

Where it becomes apparent during compilation of the SDS that some data are not readily available to the compiler, there are also publicly available databases with relevant information. These may be consulted either to seek data that is not otherwise available or to check data provided from upstream, which seems inconsistent or implausible, for example:

The ECHA database on registered substances: (https://echa.europa.eu/information-on-chemicals/registered-substances)

This gives a variety of information on the substances which companies manufacture or import: their hazardous properties, their classification and labelling and how to use the substances safely, for example. Information in the database is that provided by companies in their registration dossiers.

The ECHA classification and labelling inventory: (https://echa.europa.eu/information-on-chemicals/cl-inventory-database)

The Classification & Labelling (C&L) Inventory is a database that will contain basic classification and labelling information on notified and registered substances received from manufacturers and importers. It will also contain the list of harmonised classifications (Table 3 of Annex VI to CLP). The Inventory will be established and maintained by ECHA.

GESTIS (http://gestis-en.itrust.de)

This database of the German Berufsgenossenschaften includes more than 7,000 hazardous substances alphabetically by name, with classification, labelling, limit values, measuring methods, information on personal protection equipment, workplace limit values and occupational medicine.

eChemPortal (http://www.echemportal.org/echemportal/)

The eChemPortal is an effort of the Organisation for Economic Co-operation and Development (OECD) in collaboration with the European Commission (EC), the European Chemicals Agency (ECHA), the United States, Canada, Japan, the International Council of Chemical Associations (ICCA), the Business and Industry Advisory Committee (BIAC), the World Health Organization's (WHO) International Program on Chemical Safety (IPCS), the United Nations Environment Programme (UNEP) and environmental non-governmental organisations. eChemPortal provides free public access to

33 Note that participation in a consortium is not mandatory.


<a id="echa-ch2-page-31"></a>
**ECHA printed page 31** — [original PDF page 31](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=31)

information on properties of chemicals (including physical and chemical properties, environmental fate and behaviour, ecotoxicity and toxicity) via simultaneous searching of reports and datasets.

IPCS INCHEM (http://www.inchem.org/)

The International Programme on Chemical Safety (IPCS) INCHEM website gives Rapid access to internationally peer reviewed information on chemicals commonly used throughout the world, which may also occur as contaminants in the environment and food. It consolidates information from a number of intergovernmental organizations whose goal it is to assist in the sound management of chemicals.

TOXNET (http://toxnet.nlm.nih.gov/index.html)

Toxnet is the United States of America’s National Library of Medicine’s toxicology data network. It gives access to databases on toxicology, hazardous chemicals, environmental health, and toxic releases.

Attention should be paid to the potential variation in reliability of information from such sources.

It should be noted that in all cases (including when the information on component substances has been obtained from SDSs of suppliers of these substances – see chapter 2 paragraph 2.2 above) it is the supplier of the SDS that retains responsibility for the accuracy of its content.

2.26 How to compile an SDS for a recovered substance or mixtures containing such a substance

Appendix 3 of this document discusses specific issues relevant to the compilation of SDSs for recovered substances and mixtures. The ECHA Guidance on waste and recovered substances34 contains additional information on issues that are specific to SDSs for recovered substances.

2.27 Testing for the purposes of generation of information for an SDS

The SDS is designed to provide comprehensive information about a substance or mixture for use in workplace chemical control regulatory frameworks (see paragraph 2.1 above). It consolidates this information into one document. The information required to be given in an SDS should either be available (because it is needed, for example, as part of the data set required for a registration under REACH or for classification purposes) or a reason for it not being available should be given in the appropriate subsection of the SDS.

The process of compilation of the SDS may of course reveal that data which is required (for example to correctly classify under CLP) is unavailable.

In such cases, before any testing is initiated, the applicable “driver” legislation for compliance with which data are missing and additional testing is proposed should be consulted. Testing should not be initiated on the basis of a need to “fill-in empty fields” in an SDS.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   34 The Guidance on waste and recovered substances is available at: echa.europa.eu/guidance-documents/guidance- on-reach.


<a id="echa-ch2-page-32"></a>
**ECHA printed page 32** — [original PDF page 32](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=32)

In particular reference should be made to Title III of the REACH Regulation on Data Sharing and Avoidance of Unnecessary Testing and to Articles 7 and 8 of the CLP Regulation on Animal and human testing and Generating new information for substances and mixtures, respectively.

In particular, no animal testing should be initiated solely for the purposes of generating content for an SDS. The provisions of Council Directive 86/609/EEC35and 2010/63/EU36 of the EP and Council must be complied with. There is also no requirement arising directly from Annex II to REACH to generate non-animal test data (including that for physical hazards) solely for the purpose of completing fields of an SDS.

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section]   35 Council Directive 86/609/EEC of 24 November 1986 on the approximation of laws, regulations and administrative provisions of the Member States regarding the protection of animals used for experimental and other scientific purposes, (OJ L358, 18.12.1986 p.1).

[SOURCE PAGE FOOTNOTE — verify association with preceding text/section] 36 Directive 2010/63/EU of the European Parliament and of the Council of 22 September 2010 on the protection of animals used for scientific purposes (OJ L276, 20.10.2010 p33).
