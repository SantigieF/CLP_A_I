---
title: "3. Detailed information \u2014 overview"
document_id: "echa-sds-guidance-v4-2020-ch3intro"
source_version: "4.0 — December 2020"
source_reference: "ECHA-20-H-25-EN"
source_sha256: "2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28"
page_span: "33–33"
authority: "Explanatory ECHA guidance; NOT authoritative legislation"
---

# 3. Detailed information — overview

> **Source and legal status:** ECHA guidance v4.0 (December 2020). This is a historical, non-binding explanation; verify requirements against the legally applicable REACH Annex II and other current legislation.

> **Conversion fidelity:** Source paragraphs are reformatted without intentional substantive paraphrasing. Complex tables, visual layouts, footnotes and equations require checking in the included PDF and marked page images.

**Chapter source:** [Full original ECHA guidance](../original_source/ECHA_SDS_Guidance_v4_2020.pdf)


<a id="echa-ch3intro-page-33"></a>
**ECHA printed page 33** — [original PDF page 33](../original_source/ECHA_SDS_Guidance_v4_2020.pdf#page=33)

> **Layout caution:** Original PDF contains tables, shaded legal text, graphical material or structured examples. Check the original page image before relying on cell relationships, exact symbols or example formatting.

![Original ECHA guidance, printed page 33](../page_images/ECHA_2020_page_033.jpg)

3 Detailed information, section by section

In this chapter of this guidance a quotation of the text relating to the relevant subsection in Part A of Annex II is given before it is further discussed.

It should be noted that although there may be text in Annex II, which precedes the subsections, discussing the content of certain sections as a whole, there is no requirement to insert that text in the actual SDS except in the subsections. However, the title of the sections must be quoted as listed in the regulation – i.e. including the section number as explained above. Thus, for example, the correct heading for Section 10 of an SDS is “SECTION 10: Stability and reactivity”, i.e. including the words “SECTION 10”.

It should further be noted that although the full text of Annex II concerning specific sections and subsections is quoted in full below, other parts of Annex II (e.g. the introductory paragraphs to Part A, all of Part B) are not quoted in full below and neither is the full text of the rest of Commission Regulations (EU) 2015/830 and (EU) 2020/878.

There may be places in the SDS where information will not be completed because of e.g. a data gap, or application can be questioned, etc. However, the SDS must contain an explanation or a justification of why the section has not been completed.
