# Conversion quality and regulatory-use audit

**Source:** *Guidance on the compilation of safety data sheets*, ECHA v4.0 (December 2020), ECHA-20-H-25-EN; DOI 10.2823/77155. 

**Original PDF SHA-256:** `2a4ac00f87544ebc6397e208e13da331a5ebabd6c5ceb5f149e84cb138501c28`

## Automated checks

| Test | Result |
|---|---|
| PDF pages present | 137 |
| Raw page text archives checked against PDF text layer | 137/137 |
| Standalone SDS chapters | 16/16 |
| Source appendices | 4/4 |
| Additional front matter, introductory and general chapters | 4 |
| Visually sensitive pages with page-image copies | 69 |
| Markdown sections represented | 24 |
| Distinct H/P/EUH identifiers in source chapter extract | 30 |
| Identifiers absent from converted master | None detected |
| Broken relative local links | 0 |
| Duplicate master navigation anchors | 0 |

## Regulatory truth safeguards

1. The guidance's own **legal notice on p. 2** states that REACH is the authentic legal reference and ECHA's explanations do not constitute legal advice.
2. This is a **December 2020 guidance edition** and its quoted Annex II text may be outdated for modern SDS audits. The existence of a page or claim in this guidance is **not** sufficient to establish a current legal violation.
3. ECHA distinguishes **legal text quoted as 'Text Annex II'** from its surrounding explanations. The conversion keeps that source label, but does not certify that quoted wording matches today's Annex II.
4. Reflowed PDF text does not preserve full typography for tables, formula notation, particle size indices or footnotes. **Use original PDF page images for layout-sensitive information.** Manual visual review was undertaken for sample pages **50 and 84**; other visual pages are supplied for review, not certified.
5. Page 50 contains a multi-column nanoform example, and page 84 contains a mathematical formula and boxed excerpt. Plain text alone is not a safe basis for copying their mathematical or tabular content.
6. Page-level footnotes can refer to text preceding a new section heading on a shared page; do not assign those notes to a new SDS section without inspection. Identified lower-page footnotes have contextual warnings in Markdown.
7. All original page text layers are saved verbatim under `source_pages/`, enabling manual comparison. They do **not** recover image-only content. The original PDF is included.
8. This package **does not verify post-2020 amendments, national legal requirements, classification data, or specific SDS products**.

## Appropriate use

- Use `SDS_AUDIT_QUICK_REFERENCE.md` to route SDS questions into the relevant 2020 ECHA explanatory chapter.
- Cite exact ECHA **chapter/page** for guidance-derived analytical observations.
- For a **confirmed non-compliance**, establish the correct current legal requirement from primary regulations, with applicability date; ECHA's 2020 guide alone is not sufficient.
- Offer proposed wording only when the product-specific data and legal obligations are already verified.
- If a table, formula, footnote, or figure matters to a finding, inspect the original PDF page before relying on transcription.

## Remaining verification

- No exhaustive cell-by-cell verification of ECHA example tables or formulas has been performed.
- No comprehensive line-by-line equivalence check for the reflowed Markdown has been performed; raw page text, source PDF and page images support subsequent review.
- No legal currency check beyond the **version printed by ECHA** has been performed.

**Automated audit errors:** []
